﻿namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public enum GetCollectionsCommandContentType
    {
        /// <summary>
        /// 
        /// </summary>
        None,

        /// <summary>
        /// 
        /// </summary>
        File,
        
        /// <summary>
        /// 
        /// </summary>
        Folder
    }
}
