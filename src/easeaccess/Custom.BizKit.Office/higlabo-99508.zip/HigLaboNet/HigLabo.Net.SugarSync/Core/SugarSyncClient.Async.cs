﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Xml.Linq;
using System.Threading.Tasks;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public partial class SugarSyncClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="func"></param>
        /// <returns></returns>
        protected Task<T> CreateNewTask<T>(Func<T> func)
        {
            return Task.Factory.StartNew<T>(func);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="func"></param>
        /// <returns></returns>
        protected Task CreateNewTask(Action func)
        {
            return Task.Factory.StartNew(func);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<User> GetUserInfoAsync()
        {
            return CreateNewTask<User>(() => GetUserInfo());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<CollectionContents> GetCollectionsAsync(GetCollectionsCommand command)
        {
            return CreateNewTask<CollectionContents>(() => GetCollections(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Workspace> GetWorkspaceAsync(GetWorkspacesCommand command)
        {
            return CreateNewTask<Workspace>(() => GetWorkspace(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Workspace> UpdateWorkspaceNameAsync(UpdateWorkspaceNameCommand command)
        {
            return CreateNewTask<Workspace>(() => UpdateWorkspaceName(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Folder> GetFolderAsync(GetFoldersCommand command)
        {
            return CreateNewTask<Folder>(() => GetFolder(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task CreateFolderAsync(CreateFoldersCommand command)
        {
            return CreateNewTask(() => CreateFolder(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task DeleteFolderAsync(DeleteFoldersCommand command)
        {
            return CreateNewTask(() => DeleteFolder(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task UpdateFolderNameAsync(UpdateFolderNameCommand command)
        {
            return CreateNewTask(() => UpdateFolderName(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<ReceivedShareCollection> GetReceivedSharesAsync(GetReceivedSharesCommand command)
        {
            return CreateNewTask<ReceivedShareCollection>(() => GetReceivedShares(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<File> GetFileAsync(GetFileCommand command)
        {
            return CreateNewTask<File>(() => GetFile(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task CreateFileAsync(CreateFileCommand command)
        {
            return CreateNewTask(() => CreateFile(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<File> UpdateFileAsync(UpdateFileCommand command)
        {
            return CreateNewTask<File>(() => UpdateFile(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task DeleteFileAsync(DeleteFileCommand command)
        {
            return CreateNewTask(() => DeleteFile(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task CopyFileAsync(CopyFileCommand command)
        {
            return CreateNewTask(() => CopyFile(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Byte[]> GetFileDataAsync(GetFileDataCommand command)
        {
            return CreateNewTask<Byte[]>(() => GetFileData(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task PutFileDataAsync(PutFileDataCommand command)
        {
            return CreateNewTask(() => PutFileData(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        public Task<FileVersions> GetVersionHistoryAsync(GetVersionHistoryCommand command)
        {
            return CreateNewTask<FileVersions>(() => GetVersionHistory(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        public Task<File> CreatePublicLinkAsync(PublicLinkCommand command)
        {
            return CreateNewTask<File>(() => CreatePublicLink(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<File> DestroyPublicLinkAsync(PublicLinkCommand command)
        {
            return CreateNewTask<File>(() => DestroyPublicLink(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Albums> GetAlbumAsync(GetAlbumsCommand command)
        {
            return CreateNewTask<Albums>(() => GetAlbum(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        public Task<CollectionContents> GetAlbumsCollectionContentsAsync(GetAlbumsCollectionCommand command)
        {
            return CreateNewTask<CollectionContents>(() => GetAlbumsCollectionContents(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<Boolean> AuthenticateAsync()
        {
            return CreateNewTask<Boolean>(() => Authenticate());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<String> GetAuthorizationTokenAsync()
        {
            return CreateNewTask<String>(() => GetAuthorizationToken());
        }
    }
}