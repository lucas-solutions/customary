﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class SugarSyncUrl
    {
        /// <summary>
        /// 
        /// </summary>
        public static readonly String Authorization = "https://api.sugarsync.com/authorization";
        /// <summary>
        /// 
        /// </summary>
        public static readonly String User = "https://api.sugarsync.com/user";
    }
}
