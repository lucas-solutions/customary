﻿using System;
using System.Xml.Linq;
using System.Globalization;

namespace HigLabo.Net.Extensions
{
    /// <summary>
    /// 
    /// </summary>
    public static class SugarSyncXmlParserExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static DateTimeOffset? CastElementToDateTimeOffset(this XElement element, String key)
        {
            DateTimeOffset x = DateTimeOffset.MinValue;
            if (element.Element(key) == null) { return null; }
            if (DateTimeOffset.TryParse(element.Element(key).Value, out x) == true)
            {
                return x;
            }
            return null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static DateTimeOffset? CastAttributeToDateTimeOffset(this XElement element, String key)
        {
            DateTimeOffset x = DateTimeOffset.MinValue;
            if (element.Attribute(key) == null) { return null; }
            if (DateTimeOffset.TryParse(element.Attribute(key).Value, out x) == true)
            {
                return x;
            }
            return null;
        }
    }
}
