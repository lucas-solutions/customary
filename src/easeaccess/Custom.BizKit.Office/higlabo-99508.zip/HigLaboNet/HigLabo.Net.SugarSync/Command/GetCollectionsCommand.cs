﻿using System;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class GetCollectionsCommand : SugarSyncCommand
    {
        /// <summary>
        /// 
        /// </summary>
        private static readonly Int32 DefaultStart = 0;
        /// <summary>
        /// 
        /// </summary>
        private static readonly Int32 DefaultMax = 500;

        /// <summary>
        /// 
        /// </summary>
        public GetCollectionsCommandContentType Type { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String Url { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Int32 Start { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Int32 Max { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public GetCollectionsCommand()
        {
            Start = DefaultStart;
            Max = DefaultMax;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override XmlData CreateParameters()
        {
            var d = new XmlData();
            if (Type != GetCollectionsCommandContentType.None)
            {
                d["type"] = Type.ToString().ToLower();
            }
            d["start"] = Start.ToString();
            d["max"] = Max.ToString();
            return d;
        }
    }
}