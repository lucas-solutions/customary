namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateFileCommand : SugarSyncCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string MediaType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override XmlData CreateParameters()
        {
            var d = new XmlData("file");
            d["displayName"] = DisplayName;
            d["mediaType"] = MediaType;
            return d;
        }
    }
}