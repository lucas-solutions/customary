namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class PublicLinkCommand : SugarSyncCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool PublicLink { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public PublicLinkCommand()
        {
            PublicLink = true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override XmlData CreateParameters()
        {
            var d = new XmlData("file");
            var c = new XmlData("publicLink");
            c.Attributes.Add(new XmlAttribute("enabled", PublicLink.ToString().ToLower()));
            d.Child = c;

            return d;
        }
    }
}