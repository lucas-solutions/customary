﻿namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class GetReceivedSharesCommand : SugarSyncCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override XmlData CreateParameters()
        {
            var d = new XmlData();

            return d;
        }
    }
}