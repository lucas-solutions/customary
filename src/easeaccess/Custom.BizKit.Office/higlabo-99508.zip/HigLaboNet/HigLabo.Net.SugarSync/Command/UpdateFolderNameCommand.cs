namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateFolderNameCommand : SugarSyncCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public UpdateFolderNameCommand()
        {
            Url = "";
            DisplayName = "";
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override XmlData CreateParameters()
        {
            var d = new XmlData("folder");
            d["displayName"] = DisplayName;
            return d;
        }
    }
}