using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class PutFileDataCommand : SugarSyncCommand
    {
        private Byte[] _fileData = new Byte[0];
        /// <summary>
        /// 
        /// </summary>
        public string Url { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FolderPath { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FilePath { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string ContentType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string FileName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool StatusInResponse { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public PutFileDataCommand()
        {
            StatusInResponse = false;
            FileName = "";
            ContentType = "application/octet-stream";
            FilePath = "";
            FolderPath = "/";
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override XmlData CreateParameters()
        {
            var d = new XmlData();

            return d;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static String GetBoundaryString()
        {
            return "UpdateFileDataCommand_" + DateTime.Now.ToString("yyyyMMddHHmmss");
        }
#if !SILVERLIGHT && !NETFX_CORE
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filePath"></param>
        public void LoadFileData(String filePath)
        {
            _fileData = System.IO.File.ReadAllBytes(filePath);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileInfo"></param>
        public void LoadFileData(FileInfo fileInfo)
        {
            Byte[] bb;
            using (var r = new BinaryReader(fileInfo.OpenRead(), Encoding.UTF8))
            {
                bb = new Byte[fileInfo.Length];
                r.Read(bb, 0, bb.Length);
            }
            _fileData = bb;
        }
#endif
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        public void LoadFileData(Byte[] data)
        {
            _fileData = data;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Byte[] CreatePostData()
        {
            var boundary = GetBoundaryString();
            return CreatePostData(boundary);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="boundary"></param>
        /// <returns></returns>
        public Byte[] CreatePostData(String boundary)
        {
            HttpBodyMultipartFormData data = new HttpBodyMultipartFormData();
            data.Encoding = Encoding.UTF8;
            data.Boundary = boundary;

            HttpBodyFormData fd = new HttpBodyFormData("file");
            fd.FileName = this.FileName;
            fd.ContentType = this.ContentType;
            fd.ContentTransferEncoding = "binary";
            fd.SetData(this._fileData);
            data.FormDataList.Add(fd);

            return data.CreateBodyData();
        }
    }
}