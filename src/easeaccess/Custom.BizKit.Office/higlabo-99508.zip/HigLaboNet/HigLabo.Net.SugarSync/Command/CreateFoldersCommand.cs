using System;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class CreateFoldersCommand : SugarSyncCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String Url { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String DisplayName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public CreateFoldersCommand()
        {
            DisplayName = String.Empty;
            Url = "";
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override XmlData CreateParameters()
        {
            var d = new XmlData("folder");
            d["displayName"] = DisplayName;
            return d;
        }
    }
}