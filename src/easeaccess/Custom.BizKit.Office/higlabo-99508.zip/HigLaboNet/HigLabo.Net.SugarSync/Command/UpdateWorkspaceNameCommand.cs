﻿namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateWorkspaceNameCommand : SugarSyncCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public string Url { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override XmlData CreateParameters()
        {
            var d = new XmlData("workspace");
            d["displayName"] = DisplayName;
            return d;
        }
    }
}