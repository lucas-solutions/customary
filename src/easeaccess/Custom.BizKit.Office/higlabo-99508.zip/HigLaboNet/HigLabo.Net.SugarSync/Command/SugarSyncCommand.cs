﻿using System;
using System.Linq;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public abstract class SugarSyncCommand
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public XmlData GetXmlData()
        {
            var d = CreateParameters();
            RemoveEmptyEntry(d);
            return d;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private void RemoveEmptyEntry(XmlData data)
        {
            foreach (var key in data.Keys.Where(key => String.IsNullOrEmpty(data[key])).ToList())
            {
                data.Remove(key);
            }
            if (data.Child != null)
            {
                RemoveEmptyEntry(data.Child);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected abstract XmlData CreateParameters();
    }
}
