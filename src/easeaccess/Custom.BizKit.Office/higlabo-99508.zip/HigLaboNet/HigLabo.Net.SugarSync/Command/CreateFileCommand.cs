﻿using System;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class CreateFileCommand : SugarSyncCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String Url { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String DisplayName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String MediaType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public CreateFileCommand()
        {
            MediaType = "";
            DisplayName = "";
            Url = "";
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override XmlData CreateParameters()
        {
            var d = new XmlData("file");
            d["displayName"] = DisplayName;
            d["mediaType"] = MediaType;
            return d;
        }
    }
}