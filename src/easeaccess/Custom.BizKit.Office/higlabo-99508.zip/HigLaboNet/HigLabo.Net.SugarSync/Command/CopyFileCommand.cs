using System;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class CopyFileCommand : SugarSyncCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String Url { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String DisplayName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public String Source { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override XmlData CreateParameters()
        {
            var d = new XmlData("fileCopy");
            d["displayName"] = DisplayName;
            d.Attributes.Add(new XmlAttribute("source", Source));
            return d;   
        }
    }
}