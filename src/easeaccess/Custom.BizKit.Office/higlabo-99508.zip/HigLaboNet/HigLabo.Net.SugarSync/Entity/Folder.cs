﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class Folder : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset TimeCreated { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Parent { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Collections { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Files { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Contents { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Folder(XElement element)
        {
            if (element != null)
            {
                SetProperty(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public override void SetProperty(XElement element)
        {
            var d = this.SetElements(element);
            DisplayName = element.CastElementToString("displayName");
            TimeCreated = element.CastElementToDateTimeOffset("timeCreated") ?? TimeCreated;
            Parent = element.CastElementToString("parent");
            Collections = element.CastElementToString("collections");
            Files = element.CastElementToString("files");
            Contents = element.CastElementToString("contents");
        }
    }
}