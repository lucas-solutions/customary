﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class FileVersion : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public string Ref { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public long Size { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset LastModified { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string MediaType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool PresentOnServer { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FileData { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public FileVersion(XElement element)
        {
            if (element != null)
            {
                SetProperty(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public override void SetProperty(XElement element)
        {
            var d = this.SetElements(element);
            Size = element.CastElementToInt64("size") ?? Size;
            LastModified = element.CastElementToDateTimeOffset("lastModified") ?? LastModified;
            MediaType = element.CastElementToString("mediaType");
            PresentOnServer = element.CastElementToBoolean("presentOnServer") ?? PresentOnServer;
            FileData = element.CastElementToString("fileData");
            Ref= element.CastElementToString("ref");
        } 
    }
}