﻿using System.Collections.Generic;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class Albums : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public string Ref { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Collections { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Files { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public string Contents { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Albums(XElement element)
        {
            if (element != null)
            {
                SetProperty(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public override void SetProperty(XElement element)
        {
            DisplayName = element.CastElementToString("displayName");
            Collections = element.CastElementToString("collections");
            Files = element.CastElementToString("files");
            Contents = element.CastElementToString("contents");
        }
    }
}