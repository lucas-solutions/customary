﻿using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class ReceivedShare : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public string Ref { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string SharedFolder { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public ReceivedSharePerms Perms { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Owner { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public ReceivedShare(XElement element)
        {
            if (element != null)
            {
                SetProperty(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public override void SetProperty(XElement element)
        {
            var d = this.SetElements(element);
            Ref = element.CastElementToString("ref");
            DisplayName = element.CastElementToString("displayName");
            SharedFolder = element.CastElementToString("sharedFolder");
            Perms = new ReceivedSharePerms(element.Element("perms"));
            Owner = element.CastElementToString("owner");
        }
    }
}