﻿namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class Contact
    {
        /// <summary>
        /// 
        /// </summary>
        public string PrimaryEmailAddress { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string NickName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string LastName { get; set; }
    }
}