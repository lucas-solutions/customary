﻿using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class User : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string NickName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Salt { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Quota Quota { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string WorkSpaces { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string SyncFolders { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Deleted { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string MagicBriefcase { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string WebArchive { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string MobilePhotos { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Albums { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string RecentActivities { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ReceivedShares { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string PublicLinks { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public User()
            : this(null)
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public User(XElement element)
        {
            PublicLinks = "";
            ReceivedShares = "";
            RecentActivities = "";
            Albums = "";
            MobilePhotos = "";
            WebArchive = "";
            MagicBriefcase = "";
            Deleted = "";
            SyncFolders = "";
            WorkSpaces = "";
            Quota = null;
            Salt = "";
            NickName = "";
            UserName = "";

            if (element != null)
            {
                SetProperty(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public override void SetProperty(XElement element)
        {
            var d = this.SetElements(element);
            UserName = element.CastElementToString("username");
            NickName = element.CastElementToString("nickname");
            Salt = element.CastElementToString("salt");

            if (element.Element("quota") != null)
            {
                Quota = new Quota(element.Element("quota"));
            }
            WorkSpaces = element.CastElementToString("workspaces");
            SyncFolders = element.CastElementToString("syncfolders");
            Deleted = element.CastElementToString("deleted");
            MagicBriefcase = element.CastElementToString("magicBriefcase");
            WebArchive = element.CastElementToString("webArchive");
            MobilePhotos = element.CastElementToString("mobilePhotos");
            Albums = element.CastElementToString("albums");
            RecentActivities = element.CastElementToString("recentActivities");
            ReceivedShares = element.CastElementToString("receivedShares");
            PublicLinks = element.CastElementToString("publicLinks");
        }
    }
}