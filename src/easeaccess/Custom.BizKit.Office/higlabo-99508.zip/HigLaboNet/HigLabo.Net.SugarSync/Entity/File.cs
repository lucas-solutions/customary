﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class File :ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public string Ref { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public long Size { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset LastModified { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset TimeCreated { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string MediaType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool PresentOnServer { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Parent { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FileData { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string PublicLink { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public File(XElement element)
        {
            if (element != null)
            {
                SetProperty(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public override void SetProperty(XElement element)
        {
            var d = this.SetElements(element);
            Ref = element.CastElementToString("ref");
            DisplayName = element.CastElementToString("displayName");
            Size = element.CastElementToInt64("size") ?? Size;
            LastModified = element.CastElementToDateTimeOffset("lastModified") ?? LastModified;
            TimeCreated = element.CastElementToDateTimeOffset("timeCreated") ?? TimeCreated;
            MediaType = element.CastElementToString("mediaType");
            PresentOnServer = element.CastElementToBoolean("presentOnServer") ?? PresentOnServer;
            Parent = element.CastElementToString("parent");
            FileData = element.CastElementToString("fileData");
            PublicLink = element.CastElementToString("publicLink");
        }
    }
}