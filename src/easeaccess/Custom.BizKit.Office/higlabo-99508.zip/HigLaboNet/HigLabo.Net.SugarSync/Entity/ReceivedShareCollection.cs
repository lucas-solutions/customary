﻿using System.Collections.ObjectModel;
using System.Xml.Linq;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class ReceivedShareCollection : Collection<ReceivedShare>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public ReceivedShareCollection(XElement element)
        {
            if (element != null)
            {
                SetProperty(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public void SetProperty(XElement element)
        {
            foreach (var x in element.Elements("receivedShares"))
            {
                Add(new ReceivedShare(x));
            }
        }
    }
}