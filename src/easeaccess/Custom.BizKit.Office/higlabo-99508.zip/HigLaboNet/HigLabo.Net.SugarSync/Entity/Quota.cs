﻿using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class Quota : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public long Limit { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public long Usage { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Quota()
            : this(null)
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Quota(XElement element)
        {
            Usage = 0;
            Limit = 0;
            if (element != null)
            {
                SetProperty(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public override void SetProperty(XElement element)
        {
            var d = this.SetElements(element);
            Limit = element.CastElementToInt64("limit") ?? Limit;
            Usage = element.CastElementToInt64("usage") ?? Usage;
        }
    }
}