﻿using System.Xml.Linq;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class ReceivedSharePerms : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public bool ReadAllowed { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool WriteAllowed { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public ReceivedSharePerms(XElement element)
        {
            if (element != null)
            {
                SetProperty(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public override void SetProperty(XElement element)
        {
            var d = this.SetElements(element);
            ReadAllowed = element.Element("readAllowed") != null;
            WriteAllowed = element.Element("writeAllowed") != null;
        }
    }
}