﻿using System.Collections.Generic;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class CollectionContents : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public int Start { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int Max { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool HasMore { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public List<Collection> Collections { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        public List<File> Files { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public CollectionContents(XElement element)
        {
            Collections = new List<Collection>();
            Files = new List<File>();

            if (element != null)
            {
                SetProperty(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public override void SetProperty(XElement element)
        {
            var d = this.SetElements(element);
            Start = element.CastAttributeToInt32("start") ?? Start;
            Max = element.CastAttributeToInt32("max") ?? Max;
            HasMore = element.CastAttributeToBoolean("hasmore") ?? HasMore;
            foreach (var x in element.Elements("collection"))
            {
                Collections.Add(new Collection(x));
            }
            foreach (var x in element.Elements("file"))
            {
                Files.Add(new File(x));
            }
        }
    }
}