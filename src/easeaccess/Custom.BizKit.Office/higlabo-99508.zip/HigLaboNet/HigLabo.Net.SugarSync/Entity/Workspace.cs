﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class Workspace : ResponseObject
    {
        private String _dsID = "";
        private Int32 _iconID;

        /// <summary>
        /// 
        /// </summary>
        public string DisplayName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset TimeCreated { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Collections { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Files { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Contents { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Workspace(XElement element)
        {
            Contents = "";
            Files = "";
            Collections = "";
            TimeCreated = DateTimeOffset.MinValue;
            DisplayName = "";

            if (element != null)
            {
                SetProperty(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public override void SetProperty(XElement element)
        {
            var d = this.SetElements(element);
            _dsID = element.CastElementToString("dsid");
            _iconID = element.CastElementToInt32("iconId") ?? _iconID;

            DisplayName = element.CastElementToString("displayName");
            TimeCreated = element.CastElementToDateTimeOffset("timeCreated") ?? TimeCreated;
            Collections = element.CastElementToString("collections");
            Files = element.CastElementToString("files");
            Contents = element.CastElementToString("contents");
        }
    }
}