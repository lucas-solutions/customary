﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class Collection : ResponseObject
    {
        private String _ContentType = "";
        /// <summary>
        /// 
        /// </summary>
        public string DisplayName { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        public string Ref { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        public string Contents { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Collection(XElement element)
        {
            Contents = "";
            Ref = "";
            DisplayName = "";

            if (element != null)
            {
                SetProperty(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        public override void SetProperty(XElement element)
        {
            var d = this.SetElements(element);
            _ContentType = element.CastAttributeToString("type");
            DisplayName = element.CastElementToString("displayName");
            Ref = element.CastElementToString("ref");
            Contents = element.CastElementToString("contents");
        }
    }
}