﻿using System.Xml.Linq;
using System.Collections.ObjectModel;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.SugarSync
{
    /// <summary>
    /// 
    /// </summary>
    public class FileVersions : Collection<FileVersion>
    {
        /// <summary>
        /// 
        /// </summary>
        public int Start { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool HasMore { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int End { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public FileVersions(XElement element)
        {
            Start = element.CastAttributeToInt32("start") ?? Start;
            HasMore = element.CastAttributeToBoolean("hasmore") ?? HasMore;
            End = element.CastAttributeToInt32("end") ?? End;
            foreach (var x in element.Elements("fileVersion"))
            {
                this.Add(new FileVersion(x));
            }
        }
    }
}