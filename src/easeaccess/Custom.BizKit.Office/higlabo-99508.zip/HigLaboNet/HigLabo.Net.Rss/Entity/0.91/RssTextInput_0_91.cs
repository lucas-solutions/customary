using System.Xml.Linq;

namespace HigLabo.Net.Rss
{
    /// <summary>
    /// 
    /// </summary>
    public class RssTextInput_0_91 : RssTextInput
    {
        /// <summary>
        /// 
        /// </summary>
        public RssTextInput_0_91()
        {
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public RssTextInput_0_91(XElement element)
            : base(element)
        {
            
        }
    }
}