﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Rss.Extensions;

namespace HigLabo.Net.Rss
{
    /// <summary>
    /// 
    /// </summary>
    public class RssImage : RssXmlObject
    {
        /// <summary>
        /// 
        /// </summary>
        public string Title { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Url { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Link { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public RssImage()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public RssImage(XElement element)
        {
            if (element != null)
            {
                Parse(element);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        protected void Parse(XElement element)
        {
            Title = element.CastElementToString("title");
            Url = element.CastElementToString("url");
            Link = element.CastElementToString("link");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="version"></param>
        /// <param name="element"></param>
        /// <returns></returns>
        public static RssImage Parse(RssVersion version, XElement element)
        {
            if (element == null) return null;

            if (version == RssVersion.Rss_0_90)
            {
                return new RssImage_0_90(element);
            }
            if (version == RssVersion.Rss_0_91)
            {
                return new RssImage_0_91(element);
            }
            if (version == RssVersion.Rss_0_92)
            {
                return new RssImage_0_92(element);
            }
            if (version == RssVersion.Rss_1_0)
            {
                return new RssImage_1_0(element);                
            }
            if (version == RssVersion.Rss_2_0)
            {
                return new RssImage_2_0(element);
            }
            throw new ArgumentException("version: " + version);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="xmlns"></param>
        /// <returns></returns>
        public override XElement CreateElement(XNamespace xmlns)
        {
            return new XElement(xmlns + "image")
                .AddElement(xmlns + "title", Title)
                .AddElement(xmlns + "url", Url)
                .AddElement(xmlns + "link", Link);
        }
    }
}