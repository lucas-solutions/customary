﻿using System;
using System.Diagnostics;

namespace HigLabo.Net.Rss
{
    /// <summary>
    /// 
    /// </summary>
    [DebuggerDisplay("Rss {Version}")]
    public class RssVersion
    {
        /// <summary>
        /// 
        /// </summary>
        public const string _0_90 = "0.90";
        /// <summary>
        /// 
        /// </summary>
        public const string _0_91 = "0.91";
        /// <summary>
        /// 
        /// </summary>
        public const string _0_92 = "0.92";
        /// <summary>
        /// 
        /// </summary>
        public const string _1_0 = "1.0";
        /// <summary>
        /// 
        /// </summary>
        public const string _2_0 = "2.0";
        private static RssVersion _rss_0_90;
        private static RssVersion _rss_0_91;
        private static RssVersion _rss_0_92;
        private static RssVersion _rss_1_0;
        private static RssVersion _rss_2_0;
        private readonly string _version;
        /// <summary>
        /// 
        /// </summary>
        public string Version
        {
            get { return _version; }
        }
        /// <summary>
        /// 
        /// </summary>
        public static RssVersion Rss_0_90
        {
            get { return _rss_0_90 ?? (_rss_0_90 = new RssVersion(_0_90)); }
        }
        /// <summary>
        /// 
        /// </summary>
        public static RssVersion Rss_0_91
        {
            get { return _rss_0_91 ?? (_rss_0_91 = new RssVersion(_0_91)); }
        }
        /// <summary>
        /// 
        /// </summary>
        public static RssVersion Rss_0_92
        {
            get { return _rss_0_92 ?? (_rss_0_92 = new RssVersion(_0_92)); }
        }
        /// <summary>
        /// 
        /// </summary>
        public static RssVersion Rss_1_0
        {
            get { return _rss_1_0 ?? (_rss_1_0 = new RssVersion(_1_0)); }
        }
        /// <summary>
        /// 
        /// </summary>
        public static RssVersion Rss_2_0
        {
            get { return _rss_2_0 ?? (_rss_2_0 = new RssVersion(_2_0)); }
        }
        private RssVersion(string version)
        {
            _version = version;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="version"></param>
        /// <returns></returns>
        public static RssVersion Parse(string version)
        {
            switch (version)
            {
                case _0_90:
                    return Rss_0_90;
                case _0_91:
                    return Rss_0_91;
                case _0_92:
                    return Rss_0_92;
                case _1_0:
                    return Rss_1_0;
                case _2_0:
                    return Rss_2_0;
            }

            throw new ArgumentException("version: " + version);
        }
    }
}