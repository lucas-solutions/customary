﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HigLabo.Net.Rss.Extensions;

namespace HigLabo.Net.Rss
{
    /// <summary>
    /// 
    /// </summary>
    public class RssFeed
    {
        /// <summary>
        /// 
        /// </summary>
        public RssVersion Version { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public RssChannel Channel { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public RssImage Image { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IList<RssItem> Items { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public RssTextInput TextInput { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public RssFeed()
            : this(null)
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="xml"></param>
        public RssFeed(string xml)
        {
            Items = new List<RssItem>();

            if (!String.IsNullOrEmpty(xml))
            {
                Parse(xml);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="xml"></param>
        /// <returns></returns>
        private void Parse(string xml)
        {
            var root = ParseRootNode(XDocument.Parse(xml));

            Version = ParseVersion(root);
            Channel = ParseChannel(Version, root);
            Image = ParseImage(Version, root);
            Items = ParseItems(Version, root);
            TextInput = ParseTextInput(Version, root);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="doc"></param>
        protected XElement ParseRootNode(XDocument doc)
        {
            return doc.Root;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        protected RssVersion ParseVersion(XElement element)
        {
            element.CastAttributeToString("version");
            var ver = element.Attribute("version");
            if (ver != null)
            {
                //0.91, 0.92, 2.0
                return RssVersion.Parse(ver.Value);
            }

            var ns = element.GetDefaultNamespace();
            if (ns.NamespaceName.Contains("netscape")) return RssVersion.Rss_0_90;
            if (ns.NamespaceName.Contains("purl.org")) return RssVersion.Rss_1_0;

            throw new NotSupportedException();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="version"></param>
        /// <param name="element"></param>
        /// <returns></returns>
        protected RssChannel ParseChannel(RssVersion version, XElement element)
        {
            return RssChannel.Parse(version, element.ElementByNamespace("channel"));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="version"></param>
        /// <param name="element"></param>
        /// <returns></returns>
        protected RssImage ParseImage(RssVersion version, XElement element)
        {
            var image = element.ElementByNamespace("image");
            if (image == null)
            {
                var channel = element.ElementByNamespace("channel");
                if (channel != null)
                {
                    image = channel.ElementByNamespace("image");
                }
            }
            return RssImage.Parse(version, image);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="version"></param>
        /// <param name="element"></param>
        /// <returns></returns>
        protected IList<RssItem> ParseItems(RssVersion version, XElement element)
        {
            var items = element.ElementsByNamespace("item");
            if (!items.Any())
            {
                var channel = element.ElementByNamespace("channel");
                if (channel != null)
                {
                    items = channel.ElementsByNamespace("item");
                }
            }
            return RssItem.Parse(version, items);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="version"></param>
        /// <param name="element"></param>
        /// <returns></returns>
        protected RssTextInput ParseTextInput(RssVersion version, XElement element)
        {
            var image = element.ElementByNamespace("textinput");
            if (image == null)
            {
                var channel = element.ElementByNamespace("channel");
                if (channel != null)
                {
                    image = channel.ElementByNamespace("textinput");
                }
            }
            return RssTextInput.Parse(version, image);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string Write()
        {
            var writer = new RssWriter(this);
            return writer.Write();
        }
    }
}