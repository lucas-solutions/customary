﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using HigLabo.Net.Rss.Extensions;

namespace HigLabo.Net.Rss
{
    /// <summary>
    /// 
    /// </summary>
    public class RssItem : RssXmlObject
    {
        /// <summary>
        /// 
        /// </summary>
        public string Title { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Link { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset? PubDate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset? Date { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public RssItem()
        {
            
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public RssItem(XElement element)
        {
            if (element != null)
            {
                Parse(element);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        protected void Parse(XElement element)
        {
            Title = element.CastElementToString("title");
            Link = element.CastElementToString("link");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pubDate"></param>
        /// <returns></returns>
        public static DateTimeOffset? ParsePubDate(String pubDate)
        {
            DateTimeOffset dtime = DateTimeOffset.MinValue;
            if (DateTimeOffset.TryParse(pubDate, out dtime) == true)
            {
                return dtime;
            }
            else
            {
                String tmp = pubDate;
                tmp = tmp.Substring(0, tmp.Length - 5);
                tmp += "GMT";
                if (DateTimeOffset.TryParse(tmp, out dtime) == true)
                {
                    return dtime;
                }
            }
            return null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static DateTimeOffset? ParseDate(String date)
        {
            DateTimeOffset dtime = DateTimeOffset.MinValue;
            if (DateTimeOffset.TryParse(date, out dtime) == true)
            {
                return dtime;
            }
            else
            {
                String tmp = date;
                tmp = tmp.Substring(0, tmp.Length - 6);
                tmp += "Z";
                if (DateTimeOffset.TryParse(tmp, out dtime) == true)
                {
                    return dtime;
                }
            }
            return null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="version"></param>
        /// <param name="element"></param>
        /// <returns></returns>
        public static IList<RssItem> Parse(RssVersion version, IEnumerable<XElement> element)
        {
            return element.Select(e => Parse(version, e)).ToList();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="version"></param>
        /// <param name="element"></param>
        /// <returns></returns>
        public static RssItem Parse(RssVersion version, XElement element)
        {
            if (element == null) return null;

            if (version == RssVersion.Rss_0_90)
            {
                return new RssItem_0_90(element);
            }
            if (version == RssVersion.Rss_0_91)
            {
                return new RssItem_0_91(element);
            }
            if (version == RssVersion.Rss_0_92)
            {
                return new RssItem_0_92(element);
            }
            if (version == RssVersion.Rss_1_0)
            {
                return new RssItem_1_0(element);                
            }
            if (version == RssVersion.Rss_2_0)
            {
                return new RssItem_2_0(element);
            }
            throw new ArgumentException("version: " + version);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return string.Format("Title: {0}, Link: {1}", Title, Link);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="xmlns"></param>
        /// <returns></returns>
        public override XElement CreateElement(XNamespace xmlns)
        {
            return new XElement(xmlns + "item")
                .AddElement(xmlns + "title", Title)
                .AddElement(xmlns + "link", Link);
        }
    }
}