using System.Xml.Linq;

namespace HigLabo.Net.Rss
{
    /// <summary>
    /// 
    /// </summary>
    public class RssImage_2_0 : RssImage_0_92
    {
        /// <summary>
        /// 
        /// </summary>
        public RssImage_2_0()
        {
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public RssImage_2_0(XElement element)
            : base(element)
        {
            if (element != null)
            {
                Parse(element);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        protected new void Parse(XElement element)
        {
            
        }
    }
}