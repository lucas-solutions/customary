﻿using System;

namespace HigLabo.Net.Rss
{
    /// <summary>
    /// 
    /// </summary>
    public partial class RssClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="xml"></param>
        /// <returns></returns>
        public RssFeed GetRssFeed(string xml)
        {
            return new RssFeed(xml);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="uri"></param>
        /// <returns></returns>
        public RssFeed GetRssFeed(Uri uri)
        {
            var cm = new HttpRequestCommand(uri.ToString());
            var body = this.GetBodyText(cm);

            return new RssFeed(body);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rssFeed"></param>
        /// <returns></returns>
        public string Write(RssFeed rssFeed)
        {
            var writer = new RssWriter(rssFeed);
            return writer.Write();
        }
    }
}