﻿using System.Xml.Linq;

namespace HigLabo.Net.Rss
{
    /// <summary>
    /// 
    /// </summary>
    public abstract class RssXmlObject
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="xmlns"></param>
        /// <returns></returns>
        public abstract XElement CreateElement(XNamespace xmlns);
    }
}