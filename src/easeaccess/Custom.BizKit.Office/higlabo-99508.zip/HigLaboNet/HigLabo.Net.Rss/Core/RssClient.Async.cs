﻿using System;
using System.Threading.Tasks;

namespace HigLabo.Net.Rss
{
    /// <summary>
    /// 
    /// </summary>
    public partial class RssClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="func"></param>
        /// <returns></returns>
        protected new static Task<T> CreateNewTask<T>(Func<T> func)
        {
            return Task.Factory.StartNew<T>(func);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="xml"></param>
        /// <returns></returns>
        public Task<RssFeed> GetRssFeedAsync(string xml)
        {
            return CreateNewTask<RssFeed>(() => GetRssFeed(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="uri"></param>
        /// <returns></returns>
        public Task<RssFeed> GetRssFeedAsync(Uri uri)
        {
            return CreateNewTask<RssFeed>(() => GetRssFeed(uri));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="rssFeed"></param>
        /// <returns></returns>
        public Task<String> WriteAsync(RssFeed rssFeed)
        {
            return CreateNewTask<String>(() => Write(rssFeed));
        }
    }
}