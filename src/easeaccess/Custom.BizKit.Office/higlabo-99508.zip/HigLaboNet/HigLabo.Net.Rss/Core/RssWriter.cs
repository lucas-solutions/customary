﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Rss.Extensions;

namespace HigLabo.Net.Rss
{
    /// <summary>
    /// 
    /// </summary>
    public class RssWriter
    {
        private readonly RssFeed _rssFeed;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="rssFeed"></param>
        public RssWriter(RssFeed rssFeed)
        {
            _rssFeed = rssFeed;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string Write()
        {
            var doc = CreateDocument();
            return String.Format("{0}{1}{2}", doc.Declaration, Environment.NewLine, doc);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected XDocument CreateDocument()
        {
            var doc = new XDocument(new XDeclaration("1.0", "utf-8", null));
            if (_rssFeed.Version == RssVersion.Rss_0_90)
            {
                var ns = RssNamespace._0_90;
                var rdf = RssNamespace.RDF;

                return doc.AddElement(new XElement(rdf + "RDF")
                    .AddAttribute("xmlns", ns)
                    .AddAttribute(XNamespace.Xmlns + "rdf", rdf)
                    .AddXmlObject(ns, _rssFeed.Channel, _rssFeed.Image)
                    .AddXmlObject(ns, _rssFeed.Items)
                    .AddXmlObject(ns, _rssFeed.TextInput));
            }
            if (_rssFeed.Version == RssVersion.Rss_0_91)
            {
                return doc.AddElement(
                    new XElement("rss")
                        .AddAttribute("version", RssVersion._0_91)
                        .AddElement(_rssFeed.Channel.CreateElement("")
                            .AddXmlObject("", _rssFeed.Image)
                            .AddXmlObject("", _rssFeed.Items)
                            .AddXmlObject("", _rssFeed.TextInput)));
            }
            if (_rssFeed.Version == RssVersion.Rss_1_0)
            {
                var ns = RssNamespace._1_0;
                var rdf = RssNamespace.RDF;

                return doc.AddElement(new XElement(rdf + "RDF")
                    .AddAttribute("xmlns", ns)
                    .AddAttribute(XNamespace.Xmlns + "rdf", rdf)
                    .AddXmlObject(ns, _rssFeed.Channel, _rssFeed.Image)
                    .AddXmlObject(ns, _rssFeed.Items)
                    .AddXmlObject(ns, _rssFeed.TextInput));                
            }

            throw new NotImplementedException();
        }
    }
}