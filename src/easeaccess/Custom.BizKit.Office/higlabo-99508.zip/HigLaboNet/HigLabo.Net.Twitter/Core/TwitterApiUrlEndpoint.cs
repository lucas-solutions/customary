﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class TwitterApiUrlEndpoint
    {
        private String _UrlWithoutExtension = "";
        /// <summary>
        /// 
        /// </summary>
        /// <param name="urlWithoutExtension"></param>
        public TwitterApiUrlEndpoint(String urlWithoutExtension)
        {
            _UrlWithoutExtension = urlWithoutExtension;
        }
        /// <summary>
        /// 
        /// </summary>
        public String GetUrl(TwitterApiResponseFormat format)
        {
            switch (format)
            {
                case TwitterApiResponseFormat.Xml: return _UrlWithoutExtension + ".xml";
                case TwitterApiResponseFormat.Json: return _UrlWithoutExtension + ".json";
                default: throw new InvalidOperationException();
            }
        }
    }
}
