﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public enum TwitterApiResponseFormat
    {
        /// <summary>
        /// 
        /// </summary>
        Xml,
        /// <summary>
        /// 
        /// </summary>
        Json,
    }
}
