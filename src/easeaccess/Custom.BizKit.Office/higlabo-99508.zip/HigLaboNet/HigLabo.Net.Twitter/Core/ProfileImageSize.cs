﻿namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public enum ProfileImageSize
    {
        /// <summary>
        /// 
        /// </summary>
        Bigger, 
        /// <summary>
        /// 
        /// </summary>
        Normal,
        /// <summary>
        /// 
        /// </summary>
        Mini,
        /// <summary>
        /// 
        /// </summary>
        Original,
    }
}
