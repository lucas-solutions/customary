﻿using System;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class TwitterApiUrl
    {
        /// <summary>
        /// 
        /// </summary>
        public class Version1
        {
            /// <summary>
            /// 
            /// </summary>
            public class OAuth
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly String RequestToken = "api.twitter.com/oauth/request_token";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String AuthorizeToken = "api.twitter.com/oauth/authorize";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String AccessToken = "api.twitter.com/oauth/access_token";
            }
            /// <summary>
            /// 
            /// </summary>
            public class Statuses
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly TwitterApiUrlEndpoint HomeTimeline = new TwitterApiUrlEndpoint("api.twitter.com/1/statuses/home_timeline");
                /// <summary>
                /// 
                /// </summary>
                public static readonly String MentionsXml = "api.twitter.com/1/statuses/mentions.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String PublicTimelineXml = "api.twitter.com/1/statuses/public_timeline.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String RetweetedByMeXml = "api.twitter.com/1/statuses/retweeted_by_me.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String RetweetedToMeXml = "api.twitter.com/1/statuses/retweeted_to_me.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String RetweetsOfMeXml = "api.twitter.com/1/statuses/retweets_of_me.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String UserTimelineXml = "api.twitter.com/1/statuses/user_timeline.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String RetweetedToUserXml = "api.twitter.com/1/statuses/retweeted_to_user.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String RetweetedByUserXml = "api.twitter.com/1/statuses/retweeted_by_user.xml";
            }
            /// <summary>
            /// 
            /// </summary>
            public class Tweets
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly String RetweetedByFormatXml = "api.twitter.com/1/statuses/{0}/retweeted_by.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String RetweetedByIDsFormatXml = "api.twitter.com/1/statuses/{0}/retweeted_by/ids.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String RetweetsFormatXml = "api.twitter.com/1/statuses/retweets/{0}.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String ShowFormatXml = "api.twitter.com/1/statuses/show/{0}.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String DestroyFormatXml = "api.twitter.com/1/statuses/destroy/{0}.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String RetweetFormatXml = "api.twitter.com/1/statuses/retweet/{0}.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String UpdateFormatXml = "api.twitter.com/1/statuses/update.xml";
            }
            /// <summary>
            /// 
            /// </summary>
            public static readonly String SearchXml = "search.twitter.com/search.xml";
            /// <summary>
            /// 
            /// </summary>
            public class DirectMessages
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly String DirectMessagesXml = "api.twitter.com/1/direct_messages.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String DirectMessagesSentXml = "api.twitter.com/1/direct_messages/sent.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String DestroyFormatXml = "api.twitter.com/1/direct_messages/destroy/{0}.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String NewXml = "api.twitter.com/1/direct_messages/new.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetFormatXml = "api.twitter.com/1/direct_messages/{0}.xml";
            }
            /// <summary>
            /// 
            /// </summary>
            public class Friends
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly String FollowersXml = "api.twitter.com/1/followers/ids.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String FriendsXml = "api.twitter.com/1/friends/ids.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String ExistsFriendshipsXml = "api.twitter.com/1/friendships/exists.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String IncomingXml = "api.twitter.com/1/friendships/incoming.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String OutgoingXml = "api.twitter.com/1/friendships/outgoing.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String ShowXml = "api.twitter.com/1/friendships/show.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String CreateXml = "api.twitter.com/1/friendships/create.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String DestroyXml = "api.twitter.com/1/friendships/destroy.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String LookupXml = "api.twitter.com/1/friendships/lookup.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String UpdateXml = "api.twitter.com/1/friendships/update.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String NoRetweetIDsXml = "api.twitter.com/1/friendships/no_retweet_ids.xml";
            }
            /// <summary>
            /// 
            /// </summary>
            public class Users
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly String LookupXml = "api.twitter.com/1/users/lookup.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String SearchXml = "api.twitter.com/1/users/search.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String ShowXml = "api.twitter.com/1/users/show.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String ContributeesXml = "api.twitter.com/1/users/contributees.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String ContributorsXml = "api.twitter.com/1/users/contributors.xml";
                /// <summary>
                /// 
                /// </summary>
                /// <param name="screenName"></param>
                /// <param name="size"></param>
                /// <returns></returns>
                public static String GetProfileImageUrl(String screenName, ProfileImageSize size)
                {
                    return String.Format("http://api.twitter.com/1/users/profile_image?screen_name={0}&size={1}"
                        , screenName, size).ToLower();
                }
            }
            /// <summary>
            /// 
            /// </summary>
            public class Suggestions
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly String SuggestionsXml = "api.twitter.com/1/users/suggestions.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String SuggestionsSlugXml = "api.twitter.com/1/users/suggestions/{0}.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String SuggestionUsersXml = "api.twitter.com/1/users/suggestions/{0}/members.xml";
            }
            /// <summary>
            /// 
            /// </summary>
            public class Favorites
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetFavoritesXml = "api.twitter.com/1/favorites.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String CreateFavoritesXml = "api.twitter.com/1/favorites/create/{0}.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String DestroyFavoritesXml = "api.twitter.com/1/favorites/destroy/{0}.xml";
            }
            /// <summary>
            /// 
            /// </summary>
            public class Lists
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetAllListsXml = "api.twitter.com/1/lists/all.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetListsStatusesXml = "api.twitter.com/1/lists/statuses.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String DestroyListsMembersXml = "api.twitter.com/1/lists/members/destroy.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetListsMembershipsXml = "api.twitter.com/1/lists/memberships.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetListsSubscribersXml = "api.twitter.com/1/lists/subscribers.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String CreateListsSubscribersXml = "api.twitter.com/1/lists/subscribers/create.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String ShowListsSubscribersXml = "api.twitter.com/1/lists/subscribers/show.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String DestroyListsSubscribersXml = "api.twitter.com/1/lists/subscribers/destroy.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String CreateAllListsMembersXml = "api.twitter.com/1/lists/members/create_all.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String ShowListsMembersXml = "api.twitter.com/1/lists/members/show.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetListsMembersXml = "api.twitter.com/1/lists/members.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String CreateListsMembersXml = "api.twitter.com/1/lists/members/create.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String DestroyListsXml = "api.twitter.com/1/lists/destroy.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String UdateListsXml = "api.twitter.com/1/lists/update.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String CreateListsXml = "api.twitter.com/1/lists/create.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetListsXml = "api.twitter.com/1/lists.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String ShowListsXml = "api.twitter.com/1/lists/show.xml";
            }
            /// <summary>
            /// 
            /// </summary>
            public class Accounts
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetAccountRateLimitStatusXml = "api.twitter.com/1/account/rate_limit_status.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetAccountVerifyCredentialsXml = "api.twitter.com/1/account/verify_credentials.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String EndSessionAccountXml = "api.twitter.com/1/account/end_session.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String UpdateDeliveryDeviceXml = "api.twitter.com/1/account/update_delivery_device.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String UpdateProfileXml = "api.twitter.com/1/account/update_profile.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String UpdateProfileBackgroundImageXml = "api.twitter.com/version/account/update_profile_background_image.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String UpdateProfileColorsXml = "api.twitter.com/1/account/update_profile_colors.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String UpdateProfileImageXml = "api.twitter.com/1/account/update_profile_image.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetTotalsXml = "api.twitter.com/1/account/totals.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetAccountSettingsXml = "api.twitter.com/1/account/settings.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String UpdateAccountSettingXml = "api.twitter.com/1/account/settings.xml";
            }
            /// <summary>
            /// 
            /// </summary>
            public class SavedSearches
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetSavedSearchesXml = "api.twitter.com/1/saved_searches.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetSavedSearchesByIdXml = "api.twitter.com/1/saved_searches/show/{0}.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String CreateSavedSearchesXml = "api.twitter.com/1/saved_searches/create.xml";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String DestroySavedSearchesIdXml = "api.twitter.com/1/saved_searches/destroy/{0}.xml";
            }
            /// <summary>
            /// 
            /// </summary>
            public class LocalTrends
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly String GetTrendsXml = "api.twitter.com/1/trends/{0}.xml";
            }
        }
    }
}
