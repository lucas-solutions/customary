﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Xml.Linq;
using HigLabo.Net;
using System.Threading.Tasks;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public partial class TwitterClient
    {
        #region #Task
        /// <summary>
        /// 
        /// </summary>
        /// <param name="func"></param>
        /// <returns></returns>
        protected Task CreateNewTask(Action func)
        {
            return Task.Factory.StartNew(func);
        }
        #endregion

        #region #Accounts
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetAccountRateLimitStatusAsync(Action<RateLimitStatus> callback)
        {
            return CreateNewTask(() => GetAccountRateLimitStatus(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="includeEntities"></param>
        /// <param name="skipStatus"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetAccountVerifyCredentialsAsync(Boolean includeEntities, Boolean skipStatus, Action<User> callback)
        {
            return CreateNewTask(() => GetAccountVerifyCredentials(includeEntities, skipStatus, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetAccountVerifyCredentialsAsync(GetAccountVerifyCredentialsCommand command, Action<User> callback)
        {
            return CreateNewTask(() => GetAccountVerifyCredentials(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task EndSessionAccountAsync(Action<EndSession> callback)
        {
            return CreateNewTask(() => EndSessionAccount(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="device"></param>
        /// <param name="includeEntities"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task UpdateDeliveryDeviceAsync(String device, Boolean includeEntities, Action<User> callback)
        {
            return CreateNewTask(() => UpdateDeliveryDevice(device, includeEntities, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task UpdateDeliveryDeviceAsync(UpdateDeliveryDeviceCommand command, Action<User> callback)
        {
            return CreateNewTask(() => UpdateDeliveryDevice(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task UpdateProfileAsync(UpdateProfileCommand command, Action<User> callback)
        {
            return CreateNewTask(() => UpdateProfile(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task UpdateProfileBackgroundImageAsync(UpdateProfileBackgroundImageCommand command, Action<User> callback)
        {
            return CreateNewTask(() => UpdateProfileBackgroundImage(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task UpdateProfileBackgroundColorsAsync(UpdateProfileColorsCommand command, Action<User> callback)
        {
            return CreateNewTask(() => UpdateProfileBackgroundColors(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task UpdateProfileImageAsync(UpdateProfileImageCommand command, Action<User> callback)
        {
            return CreateNewTask(() => UpdateProfileImage(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetTotalsAsync(Action<Totals> callback)
        {
            return CreateNewTask(() => GetTotals(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetAccountSettingsAsync(Action<AccountSettings> callback)
        {
            return CreateNewTask(() => GetAccountSettings(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task UpdateAccountSettingsAsync(UpdateAccountSettingsCommand command, Action<AccountSettings> callback)
        {
            return CreateNewTask(() => UpdateAccountSettings(command, callback));
        }
        #endregion

        #region #DirectMessage
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetDirectMessageListAsync(Action<IEnumerable<DirectMessage>> callback)
        {
            return CreateNewTask(() => GetDirectMessageList(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetDirectMessageListAsync(GetDirectMessageListCommand command, Action<IEnumerable<DirectMessage>> callback)
        {
            return CreateNewTask(() => GetDirectMessageList(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetDirectMessageListSentAsync(Action<IEnumerable<DirectMessage>> callback)
        {
            return CreateNewTask(() => GetDirectMessageListSent(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetDirectMessageListSentAsync(GetDirectMessageListSentCommand command, Action<IEnumerable<DirectMessage>> callback)
        {
            return CreateNewTask(() => GetDirectMessageListSent(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroyDirectMessageAsync(String id, Action<DirectMessage> callback)
        {
            return CreateNewTask(() => DestroyDirectMessage(id, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroyDirectMessageAsync(DestroyDirectMessageCommand command, Action<DirectMessage> callback)
        {
            return CreateNewTask(() => DestroyDirectMessage(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="text"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task NewDirectMessageAsync(String userID, String text, Action<DirectMessage> callback)
        {
            return CreateNewTask(() => NewDirectMessage(userID, text, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task NewDirectMessageAsync(NewDirectMessageCommand command, Action<DirectMessage> callback)
        {
            return CreateNewTask(() => NewDirectMessage(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetDirectMessageAsync(String id, Action<DirectMessage> callback)
        {
            return CreateNewTask(() => GetDirectMessage(id, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetDirectMessageAsync(GetDirectMessageCommand command, Action<DirectMessage> callback)
        {
            return CreateNewTask(() => GetDirectMessage(command, callback));
        }
        #endregion

        #region #Favorites
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="page"></param>
        /// <param name="includeEntities"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetFavoritesAsync(Int64 id, Int32 page, Boolean includeEntities, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetFavorites(id, page, includeEntities, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetFavoritesAsync(GetFavoritesCommand command, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetFavorites(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="includeEntities"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task CreateFavoritesAsync(Int64 id, Boolean includeEntities, Action<Status> callback)
        {
            return CreateNewTask(() => CreateFavorites(id, includeEntities, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task CreateFavoritesAsync(CreateFavoritesCommand command, Action<Status> callback)
        {
            return CreateNewTask(() => CreateFavorites(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroyFavoritesAsync(Int64 id, Action<Status> callback)
        {
            return CreateNewTask(() => DestroyFavorites(id, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroyFavoritesAsync(DestroyFavoritesCommand command, Action<Status> callback)
        {
            return CreateNewTask(() => DestroyFavorites(command, callback));

        }
        #endregion

        #region #Friend
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetFollowersAsync(String userID, Action<Friends> callback)
        {
            return CreateNewTask(() => GetFollowers(userID, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetFollowersAsync(GetFriendsCommand command, Action<Friends> callback)
        {
            return CreateNewTask(() => GetFollowers(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetFriendsAsync(String userID, Action<Friends> callback)
        {
            return CreateNewTask(() => GetFriends(userID, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetFriendsAsync(GetFriendsCommand command, Action<Friends> callback)
        {
            return CreateNewTask(() => GetFriends(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID_A"></param>
        /// <param name="userID_B"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task ExistsFriendshipsAsync(Int64 userID_A, Int64 userID_B, Action<Boolean> callback)
        {
            return CreateNewTask(() => ExistsFriendships(userID_A, userID_B, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName_A"></param>
        /// <param name="screenName_B"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task ExistsFriendshipsAsync(String screenName_A, String screenName_B, Action<Boolean> callback)
        {
            return CreateNewTask(() => ExistsFriendships(screenName_A, screenName_B, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task ExistsFriendshipsAsync(ExistsFriendshipsCommand command, Action<Boolean> callback)
        {
            return CreateNewTask(() => ExistsFriendships(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetIncomingFriendsAsync(Action<Friends> callback)
        {
            return CreateNewTask(() => GetIncomingFriends(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetIncomingFriendsAsync(GetPendingFollowFriendsCommand command, Action<Friends> callback)
        {
            return CreateNewTask(() => GetIncomingFriends(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetOutgoingFriendsAsync(Action<Friends> callback)
        {
            return CreateNewTask(() => GetOutgoingFriends(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetOutgoingFriendsAsync(GetPendingFollowFriendsCommand command, Action<Friends> callback)
        {
            return CreateNewTask(() => GetOutgoingFriends(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceID"></param>
        /// <param name="targetID"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task ShowFriendshipsAsync(Int64 sourceID, Int64 targetID, Action<Relationship> callback)
        {
            return CreateNewTask(() => ShowFriendships(sourceID, targetID, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceScreenName"></param>
        /// <param name="targetScreenName"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task ShowFriendshipsAsync(String sourceScreenName, String targetScreenName, Action<Relationship> callback)
        {
            return CreateNewTask(() => ShowFriendships(sourceScreenName, targetScreenName, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task ShowFriendshipsAsync(ShowFriendshipsCommand command, Action<Relationship> callback)
        {
            return CreateNewTask(() => ShowFriendships(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroyFriendshipAsync(Int64 userID, Action<User> callback)
        {
            return CreateNewTask(() => DestroyFriendship(userID, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroyFriendshipAsync(String screenName, Action<User> callback)
        {
            return CreateNewTask(() => DestroyFriendship(screenName, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroyFriendshipAsync(DestroyFriendshipCommand command, Action<User> callback)
        {
            return CreateNewTask(() => DestroyFriendship(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task CreateFriendshipAsync(Int64 userID, Action<User> callback)
        {
            return CreateNewTask(() => CreateFriendship(userID, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task CreateFriendshipAsync(String screenName, Action<User> callback)
        {
            return CreateNewTask(() => CreateFriendship(screenName, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task CreateFriendshipAsync(CreateFriendshipCommand command, Action<User> callback)
        {
            return CreateNewTask(() => CreateFriendship(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task UpdateFriendshipAsync(UpdateFriendshipCommand command, Action<Relationship> callback)
        {
            return CreateNewTask(() => UpdateFriendship(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetNoRetweetIDsAsync(Action<IEnumerable<Int64>> callback)
        {
            return CreateNewTask(() => GetNoRetweetIDs(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetNoRetweetIDsAsync(GetNoRetweetIDsCommand command, Action<IEnumerable<Int64>> callback)
        {
            return CreateNewTask(() => GetNoRetweetIDs(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task LookupFriendshipsAsync(Int64[] values, Action<IEnumerable<Friendship>> callback)
        {
            return CreateNewTask(() => LookupFriendships(values, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task LookupFriendshipsAsync(String[] values, Action<IEnumerable<Friendship>> callback)
        {
            return CreateNewTask(() => LookupFriendships(values, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task LookupFriendshipsAsync(LookupFriendshipsCommand command, Action<IEnumerable<Friendship>> callback)
        {
            return CreateNewTask(() => LookupFriendships(command, callback));
        }
        #endregion

        #region #Lists
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="screenName"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetAllListsAsync(Int64 userID, String screenName, Action<IEnumerable<List>> callback)
        {
            return CreateNewTask(() => GetAllLists(userID, screenName, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetAllListsAsync(GetAllListsCommand command, Action<IEnumerable<List>> callback)
        {
            return CreateNewTask(() => GetAllLists(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetListsStatusesAsync(Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetListsStatuses(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetListsStatusesAsync(GetListsStatusesCommand command, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetListsStatuses(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroyListMembersAsync(Action<User> callback)
        {
            return CreateNewTask(() => DestroyListMembers(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroyListMembersAsync(DestroyListsMembersCommand command, Action<User> callback)
        {
            return CreateNewTask(() => DestroyListMembers(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetListsMembershipsAsync(GetListsMembershipsCommand command, Action<IEnumerable<List>> callback)
        {
            return CreateNewTask(() => GetListsMemberships(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetListsSubscribersAsync(Action<Friends> callback)
        {
            return CreateNewTask(() => GetListsSubscribers(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetListsSubscribersAsync(GetListsSubscribersCommand command, Action<Friends> callback)
        {
            return CreateNewTask(() => GetListsSubscribers(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task CreateListsSubscribersAsync(CreateListsSubscribersCommand command, Action<User> callback)
        {
            return CreateNewTask(() => CreateListsSubscribers(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task ShowListsSubscribersAsync(Action<Friends> callback)
        {
            return CreateNewTask(() => ShowListsSubscribers(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task ShowListsSubscribersAsync(DestroyListsMembersCommand command, Action<Friends> callback)
        {
            return CreateNewTask(() => ShowListsSubscribers(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroyListsSubscribersAsync(DestroyListsSubscribersCommand command, Action<User> callback)
        {
            return CreateNewTask(() => DestroyListsSubscribers(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task CreateAllListsMembersAsync(Int64[] values, Action<IEnumerable<Friendship>> callback)
        {
            return CreateNewTask(() => CreateAllListsMembers(values, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task CreateAllListsMembersAsync(String[] values, Action<IEnumerable<Friendship>> callback)
        {
            return CreateNewTask(() => CreateAllListsMembers(values, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task CreateAllListsMembersAsync(CreateAllListsMembersCommand command, Action<IEnumerable<Friendship>> callback)
        {
            return CreateNewTask(() => CreateAllListsMembers(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task ShowListsMembersAsync(Action<Friends> callback)
        {
            return CreateNewTask(() => ShowListsMembers(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task ShowListsMembersAsync(ShowListsMembersCommand command, Action<Friends> callback)
        {
            return CreateNewTask(() => ShowListsMembers(command, callback));
        }
        #endregion

        #region #LocalTrends
        /// <summary>
        /// 
        /// </summary>
        /// <param name="woeID"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetTrendsAsync(Int32 woeID, Action<Trends> callback)
        {
            return CreateNewTask(() => GetTrends(woeID, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetTrendsAsync(GetTrendsCommand command, Action<Trends> callback)
        {
            return CreateNewTask(() => GetTrends(command, callback));
        }
        #endregion

        #region #SavedSearches
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetSavedSearchesAsync(Int64 id, Action<SavedSearch> callback)
        {
            return CreateNewTask(() => GetSavedSearches(id, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetSavedSearchesAsync(Action<IEnumerable<SavedSearch>> callback)
        {
            return CreateNewTask(() => GetSavedSearches(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task CreateSavedSearchesAsync(String query, Action<SavedSearch> callback)
        {
            return CreateNewTask(() => CreateSavedSearches(query, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task CreateSavedSearchesAsync(CreateSavedSearchesCommand command, Action<SavedSearch> callback)
        {
            return CreateNewTask(() => CreateSavedSearches(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroySavedSearchesAsync(Int64 id, Action<SavedSearch> callback)
        {
            return CreateNewTask(() => DestroySavedSearches(id, callback));
        }
        #endregion

        #region #Search
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task SearchAsync(String query, Action<SearchResult> callback)
        {
            return CreateNewTask(() => Search(query, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task SearchAsync(SearchCommand command, Action<SearchResult> callback)
        {
            return CreateNewTask(() => Search(command, callback));
        }
        #endregion

        #region #Suggestions
        /// <summary>
        /// 
        /// </summary>
        /// <param name="language"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetSuggestionsAsync(String language, Action<IEnumerable<Suggestion>> callback)
        {
            return CreateNewTask(() => GetSuggestions(language, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetSuggestionsAsync(GetSuggestionsCommand command, Action<IEnumerable<Suggestion>> callback)
        {
            return CreateNewTask(() => GetSuggestions(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="slug"></param>
        /// <param name="language"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetSuggetstionsSlugAsync(String slug, String language, Action<Suggestion> callback)
        {
            return CreateNewTask(() => GetSuggetstionsSlug(slug, language, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetSuggetstionsSlugAsync(GetSuggestionsSlugCommand command, Action<Suggestion> callback)
        {
            return CreateNewTask(() => GetSuggetstionsSlug(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="slug"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetSuggestionUsersAsync(String slug, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => GetSuggestionUsers(slug, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetSuggestionUsersAsync(GetSuggestionUsersCommand command, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => GetSuggestionUsers(command, callback));
        }
        #endregion

        #region #Timeline
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetHomeTimelineAsync(Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetHomeTimeline(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetHomeTimelineAsync(GetHomeTimelineCommand command, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetHomeTimeline(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetMentionsAsync(Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetMentions(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetMentionsAsync(GetMentionsCommand command, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetMentions(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetPublicTimelineAsync(Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetPublicTimeline(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetPublicTimelineAsync(GetPublicTimelineCommand command, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetPublicTimeline(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetedByMeAsync(Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetRetweetedByMe(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetedByMeAsync(GetTimelineRetweetMeCommand command, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetRetweetedByMe(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetedToMeAsync(Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetRetweetedToMe(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetedToMeAsync(GetTimelineRetweetMeCommand command, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetRetweetedToMe(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetsOfMeAsync(Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetRetweetsOfMe(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetsOfMeAsync(GetTimelineRetweetMeCommand command, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetRetweetsOfMe(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetUserTimelineAsync(Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetUserTimeline(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetUserTimelineAsync(GetUserTimelineCommand command, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetUserTimeline(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetedToUserAsync(Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetRetweetedToUser(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetedToUserAsync(GetTimelineRetweetUserCommand command, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetRetweetedToUser(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetedByUserAsync(Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetRetweetedByUser(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetedByUserAsync(GetTimelineRetweetUserCommand command, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetRetweetedByUser(command, callback));
        }
        #endregion

        #region #Tweet
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetedByAsync(Int64 id, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => GetRetweetedBy(id, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetedByAsync(GetUserRetweetByCommand command, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => GetRetweetedBy(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetedByIDsAsync(Int64 id, Action<IEnumerable<String>> callback)
        {
            return CreateNewTask(() => GetRetweetedByIDs(id, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetedByIDsAsync(GetUserRetweetByIDsCommand command, Action<IEnumerable<String>> callback)
        {
            return CreateNewTask(() => GetRetweetedByIDs(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetsAsync(Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetRetweets(callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetRetweetsAsync(GetRetweetsCommand command, Action<IEnumerable<Status>> callback)
        {
            return CreateNewTask(() => GetRetweets(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetStatusAsync(String id, Action<Status> callback)
        {
            return CreateNewTask(() => GetStatus(id, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task GetStatusAsync(GetStatusCommand command, Action<Status> callback)
        {
            return CreateNewTask(() => GetStatus(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroyStatusAsync(Int64 id, Action<Status> callback)
        {
            return CreateNewTask(() => DestroyStatus(id, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task DestroyStatusAsync(GetStatusCommand command, Action<Status> callback)
        {
            return CreateNewTask(() => DestroyStatus(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task RetweetStatusAsync(Int64 id, Action<Status> callback)
        {
            return CreateNewTask(() => RetweetStatus(id, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task RetweetStatusAsync(GetStatusCommand command, Action<Status> callback)
        {
            return CreateNewTask(() => RetweetStatus(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="tweetText"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task UpdateStatusAsync(String tweetText, Action<Status> callback)
        {
            return CreateNewTask(() => UpdateStatus(tweetText, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        public Task UpdateStatusAsync(UpdateStatusCommand command, Action<Status> callback)
        {
            return CreateNewTask(() => UpdateStatus(command, callback));
        }
        #endregion

        #region #User
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="callback"></param>
        public Task LookupUsersAsync(Int64[] values, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => LookupUsers(values, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="callback"></param>
        public Task LookupUsersAsync(String[] values, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => LookupUsers(values, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public Task LookupUsersAsync(LookupUserCommand command, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => LookupUsers(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="callback"></param>
        public Task SearchUsersAsync(String query, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => SearchUsers(query, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public Task SearchUsersAsync(SearchUserCommand command, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => SearchUsers(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public Task ShowUserAsync(Int64 id, Action<User> callback)
        {
            return CreateNewTask(() => ShowUser(id, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <param name="callback"></param>
        public Task ShowUserAsync(String screenName, Action<User> callback)
        {
            return CreateNewTask(() => ShowUser(screenName, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public Task ShowUserAsync(ShowUserCommand command, Action<User> callback)
        {
            return CreateNewTask(() => ShowUser(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public Task GetContributeesAsync(Int64 id, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => GetContributees(id, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <param name="callback"></param>
        public Task GetContributeesAsync(String screenName, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => GetContributees(screenName, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public Task GetContributeesAsync(GetContributeesCommand command, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => GetContributees(command, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public Task GetContributorsAsync(Int64 id, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => GetContributors(id, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <param name="callback"></param>
        public Task GetContributorsAsync(String screenName, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => GetContributors(screenName, callback));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public Task GetContributorsAsync(GetContributorsCommand command, Action<IEnumerable<User>> callback)
        {
            return CreateNewTask(() => GetContributors(command, callback));
        }
        #endregion
    }
}
