﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<DirectMessage> GetDirectMessageList()
        {
            return this.GetDirectMessageList(null as GetDirectMessageListCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<DirectMessage> GetDirectMessageList(GetDirectMessageListCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.DirectMessages.DirectMessagesXml, command);
            return from d in XElement.Parse(xml).Descendants("direct_message") select new DirectMessage(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<DirectMessage> GetDirectMessageListSent()
        {
            return this.GetDirectMessageListSent(null as GetDirectMessageListCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<DirectMessage> GetDirectMessageListSent(GetDirectMessageListSentCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.DirectMessages.DirectMessagesSentXml, command);
            return from d in XElement.Parse(xml).Descendants("direct_message") select new DirectMessage(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public DirectMessage DestroyDirectMessage(String id)
        {
            String xml = this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.DirectMessages.DestroyFormatXml, id));
            XElement x = XElement.Parse(xml);
            return new DirectMessage(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public DirectMessage DestroyDirectMessage(DestroyDirectMessageCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.DirectMessages.DestroyFormatXml, command.ID), command);
            XElement x = XElement.Parse(xml);
            return new DirectMessage(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="text"></param>
        /// <returns></returns>
        public DirectMessage NewDirectMessage(String userID, String text)
        {
            var cm = new NewDirectMessageCommand();
            cm.UserID = userID;
            cm.Text = text;
            return this.NewDirectMessage(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public DirectMessage NewDirectMessage(NewDirectMessageCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.DirectMessages.NewXml, command);
            XElement x = XElement.Parse(xml);
            return new DirectMessage(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public DirectMessage GetDirectMessage(String id)
        {
            return this.GetDirectMessage(new GetDirectMessageCommand() { ID = id });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public DirectMessage GetDirectMessage(GetDirectMessageCommand command)
        {
            String xml = this.GetXml(String.Format(TwitterApiUrl.Version1.DirectMessages.GetFormatXml, command.ID), command);
            XElement x = XElement.Parse(xml);
            return new DirectMessage(x);
        }
    }
}
