﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public Friends GetFollowers(String userID)
        {
            var cm = new GetFriendsCommand();
            cm.UserID = userID;
            return this.GetFollowers(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Friends GetFollowers(GetFriendsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Friends.FollowersXml, command);
            var x = XElement.Parse(xml);
            return new Friends(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public Friends GetFriends(String userID)
        {
            var cm = new GetFriendsCommand();
            cm.UserID = userID;
            return this.GetFriends(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Friends GetFriends(GetFriendsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Friends.FriendsXml, command);
            var x = XElement.Parse(xml);
            return new Friends(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID_A"></param>
        /// <param name="userID_B"></param>
        /// <returns></returns>
        public Boolean ExistsFriendships(Int64 userID_A, Int64 userID_B)
        {
            var cm = new ExistsFriendshipsCommand();
            cm.UserID_A = userID_A;
            cm.UserID_B = userID_B;
            return this.ExistsFriendships(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName_A"></param>
        /// <param name="screenName_B"></param>
        /// <returns></returns>
        public Boolean ExistsFriendships(String screenName_A, String screenName_B)
        {
            var cm = new ExistsFriendshipsCommand();
            cm.ScreenName_A = screenName_A;
            cm.ScreenName_B = screenName_B;
            return this.ExistsFriendships(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Boolean ExistsFriendships(ExistsFriendshipsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Friends.ExistsFriendshipsXml, command);
            var x = XElement.Parse(xml);
            return x.Value == "true";
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Friends GetIncomingFriends()
        {
            return this.GetIncomingFriends(null as GetPendingFollowFriendsCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Friends GetIncomingFriends(GetPendingFollowFriendsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Friends.IncomingXml, command);
            var x = XElement.Parse(xml);
            return new Friends(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Friends GetOutgoingFriends()
        {
            return this.GetOutgoingFriends(null as GetPendingFollowFriendsCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Friends GetOutgoingFriends(GetPendingFollowFriendsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Friends.OutgoingXml, command);
            var x = XElement.Parse(xml);
            return new Friends(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceID"></param>
        /// <param name="targetID"></param>
        /// <returns></returns>
        public Relationship ShowFriendships(Int64 sourceID, Int64 targetID)
        {
            var cm = new ShowFriendshipsCommand();
            cm.SourceID = sourceID;
            cm.TargetID = targetID;
            return this.ShowFriendships(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceScreenName"></param>
        /// <param name="targetScreenName"></param>
        /// <returns></returns>
        public Relationship ShowFriendships(String sourceScreenName, String targetScreenName)
        {
            var cm = new ShowFriendshipsCommand();
            cm.SourceScreenName = sourceScreenName;
            cm.TargetScreenName = targetScreenName;
            return this.ShowFriendships(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Relationship ShowFriendships(ShowFriendshipsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Friends.ShowXml, command);
            var x = XElement.Parse(xml);
            return new Relationship(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public User DestroyFriendship(Int64 userID)
        {
            var cm = new DestroyFriendshipCommand();
            cm.UserID = userID;
            return this.DestroyFriendship(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <returns></returns>
        public User DestroyFriendship(String screenName)
        {
            var cm = new DestroyFriendshipCommand();
            cm.ScreenName = screenName;
            return this.DestroyFriendship(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User DestroyFriendship(DestroyFriendshipCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Friends.DestroyXml, command);
            XElement x = XElement.Parse(xml);
            return new User(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public User CreateFriendship(Int64 userID)
        {
            var cm = new CreateFriendshipCommand();
            cm.UserID = userID;
            return this.CreateFriendship(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <returns></returns>
        public User CreateFriendship(String screenName)
        {
            var cm = new CreateFriendshipCommand();
            cm.ScreenName = screenName;
            return this.CreateFriendship(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User CreateFriendship(CreateFriendshipCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Friends.CreateXml, command);
            XElement x = XElement.Parse(xml);
            return new User(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Relationship UpdateFriendship(UpdateFriendshipCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Friends.UpdateXml, command);
            XElement x = XElement.Parse(xml);
            return new Relationship(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Int64> GetNoRetweetIDs()
        {
            return this.GetNoRetweetIDs(null as GetNoRetweetIDsCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Int64> GetNoRetweetIDs(GetNoRetweetIDsCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Get, TwitterApiUrl.Version1.Friends.NoRetweetIDsXml, command);
            return XElement.Parse(xml).Descendants("id").Select(el => Int64.Parse(el.Value));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <returns></returns>
        public IEnumerable<Friendship> LookupFriendships(params Int64[] values)
        {
            StringBuilder sb = new StringBuilder(256);
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append(values[i]);
                if (i < values.Length - 1)
                {
                    sb.Append(",");
                }
            }
            var cm = new LookupFriendshipsCommand();
            cm.UserID = sb.ToString();
            return this.LookupFriendships(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <returns></returns>
        public IEnumerable<Friendship> LookupFriendships(params String[] values)
        {
            StringBuilder sb = new StringBuilder(256);
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append(values[i]);
                if (i < values.Length - 1)
                {
                    sb.Append(",");
                }
            }
            var cm = new LookupFriendshipsCommand();
            cm.ScreenName = sb.ToString();
            return this.LookupFriendships(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Friendship> LookupFriendships(LookupFriendshipsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Friends.LookupXml, command);
            return from x in XElement.Parse(xml).Descendants("relationship") select new Friendship(x);
        }
    }
}
