﻿using System;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public RateLimitStatus GetAccountRateLimitStatus()
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Accounts.GetAccountRateLimitStatusXml);
            return new RateLimitStatus(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="includeEntities"></param>
        /// <param name="skipStatus"></param>
        /// <returns></returns>
        public User GetAccountVerifyCredentials(Boolean includeEntities, Boolean skipStatus)
        {
            var command = new GetAccountVerifyCredentialsCommand();
            command.IncludeEntities = includeEntities;
            command.SkipStatus = skipStatus;
            return GetAccountVerifyCredentials(command);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User GetAccountVerifyCredentials(GetAccountVerifyCredentialsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Accounts.GetAccountVerifyCredentialsXml, command);
            return new User(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public EndSession EndSessionAccount()
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.EndSessionAccountXml);
            return new EndSession(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="device"></param>
        /// <param name="includeEntities"></param>
        /// <returns></returns>
        public User UpdateDeliveryDevice(String device, Boolean includeEntities)
        {
            var command = new UpdateDeliveryDeviceCommand();
            command.Device = device;
            command.IncludeEntities = includeEntities;
            return UpdateDeliveryDevice(command);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User UpdateDeliveryDevice(UpdateDeliveryDeviceCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.UpdateDeliveryDeviceXml, command);
            return new User(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User UpdateProfile(UpdateProfileCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.UpdateProfileXml, command);
            return new User(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public User UpdateProfileBackgroundImage()
        {
            return UpdateProfileBackgroundImage(null);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User UpdateProfileBackgroundImage(UpdateProfileBackgroundImageCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.UpdateProfileBackgroundImageXml, command);
            return new User(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public User UpdateProfileBackgroundColors()
        {
            return UpdateProfileBackgroundColors(null);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User UpdateProfileBackgroundColors(UpdateProfileColorsCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.UpdateProfileColorsXml, command);
            return new User(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public User UpdateProfileImage()
        {
            return UpdateProfileImage(null);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User UpdateProfileImage(UpdateProfileImageCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.UpdateProfileImageXml, command);
            return new User(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Totals GetTotals()
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Accounts.GetTotalsXml);
            return new Totals(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public AccountSettings GetAccountSettings()
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Accounts.GetAccountSettingsXml);
            return new AccountSettings(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public AccountSettings UpdateAccountSettings(UpdateAccountSettingsCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.UpdateAccountSettingXml, command);
            return new AccountSettings(XElement.Parse(xml));
        }
    }
}
