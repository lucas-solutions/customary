﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="language"></param>
        /// <returns></returns>
        public IEnumerable<Suggestion> GetSuggestions(String language)
        {
            var cm = new GetSuggestionsCommand();
            cm.Lang = language;
            return this.GetSuggestions(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Suggestion> GetSuggestions(GetSuggestionsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Suggestions.SuggestionsXml, command);
            return from x in XElement.Parse(xml).Descendants("category") select new Suggestion(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="slug"></param>
        /// <param name="language"></param>
        /// <returns></returns>
        public Suggestion GetSuggetstionsSlug(String slug, String language)
        {
            var cm = new GetSuggestionsSlugCommand();
            cm.Slug = slug;
            cm.Lang = language;
            return this.GetSuggetstionsSlug(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Suggestion GetSuggetstionsSlug(GetSuggestionsSlugCommand command)
        {
            String xml = this.GetXml(String.Format(TwitterApiUrl.Version1.Suggestions.SuggestionsSlugXml, command.Slug), command);
            return new Suggestion(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="slug"></param>
        /// <returns></returns>
        public IEnumerable<User> GetSuggestionUsers(String slug)
        {
            var cm = new GetSuggestionUsersCommand();
            cm.Slug = slug;
            return this.GetSuggestionUsers(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<User> GetSuggestionUsers(GetSuggestionUsersCommand command)
        {
            String xml = this.GetXml(String.Format(TwitterApiUrl.Version1.Suggestions.SuggestionUsersXml, command.Slug), command);
            return from x in XElement.Parse(xml).Descendants("user") select new User(x);
        }
    }
}
