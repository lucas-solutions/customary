﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<SavedSearch> GetSavedSearches()
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.SavedSearches.GetSavedSearchesXml);
            return from x in XElement.Parse(xml).Descendants("saved_search") select new SavedSearch(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public SavedSearch GetSavedSearchesById(Int64 id)
        {
            String xml = this.GetXml(String.Format(TwitterApiUrl.Version1.SavedSearches.GetSavedSearchesByIdXml, id));
            return new SavedSearch(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public SavedSearch CreateSavedSearches(String query)
        {
            CreateSavedSearchesCommand command = new CreateSavedSearchesCommand();
            command.Query = query;
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.SavedSearches.CreateSavedSearchesXml, command);
            return new SavedSearch(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public SavedSearch DestroySavedSearches(Int64 id)
        {
            String xml = this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.SavedSearches.DestroySavedSearchesIdXml, id));
            return new SavedSearch(XElement.Parse(xml));
        }

    }
}
