﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="page"></param>
        /// <param name="includeEntities"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetFavorites(Int64 id, Int32 page, Boolean includeEntities)
        {
            var cm = new GetFavoritesCommand();
            cm.ID = id;
            cm.Page = page;
            cm.IncludeEntities = includeEntities;
            return this.GetFavorites(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetFavorites(GetFavoritesCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Favorites.GetFavoritesXml, command);
            return from x in XElement.Parse(xml).Descendants("status") select new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="includeEntities"></param>
        /// <returns></returns>
        public Status CreateFavorites(Int64 id, Boolean includeEntities)
        {
            var cm = new CreateFavoritesCommand();
            cm.ID = id;
            cm.IncludeEntities = includeEntities;
            return this.CreateFavorites(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Status CreateFavorites(CreateFavoritesCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.Favorites.CreateFavoritesXml, command.ID), command);
            return new Status(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Status DestroyFavorites(Int64 id)
        {
            var cm = new DestroyFavoritesCommand();
            cm.ID = id;
            return this.DestroyFavorites(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Status DestroyFavorites(DestroyFavoritesCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.Favorites.DestroyFavoritesXml, command.ID), command);
            return new Status(XElement.Parse(xml));
        }
    }
}
