﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Status> GetHomeTimeline()
        {
            return this.GetHomeTimeline(null as GetHomeTimelineCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetHomeTimeline(GetHomeTimelineCommand command)
        {
            List<Status> l = new List<Status>();
            String text = this.GetXml(TwitterApiUrl.Version1.Statuses.HomeTimeline.GetUrl(this.Format), command);
            return CreateResponseObjectList<Status>(text, "status");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Status> GetMentions()
        {
            return this.GetMentions(null as GetMentionsCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetMentions(GetMentionsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Statuses.MentionsXml, command);
            return from x in XElement.Parse(xml).Descendants("status") select new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Status> GetPublicTimeline()
        {
            return this.GetPublicTimeline(null as GetPublicTimelineCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetPublicTimeline(GetPublicTimelineCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Statuses.PublicTimelineXml, command);
            return from x in XElement.Parse(xml).Descendants("status") select new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Status> GetRetweetedByMe()
        {
            return this.GetRetweetedByMe(null as GetTimelineRetweetMeCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetRetweetedByMe(GetTimelineRetweetMeCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Statuses.RetweetedByMeXml, command);
            return from x in XElement.Parse(xml).Descendants("status") select new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Status> GetRetweetedToMe()
        {
            return this.GetRetweetedToMe(null as GetTimelineRetweetMeCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetRetweetedToMe(GetTimelineRetweetMeCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Statuses.RetweetedToMeXml, command);
            return from x in XElement.Parse(xml).Descendants("status") select new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Status> GetRetweetsOfMe()
        {
            return this.GetRetweetsOfMe(null as GetTimelineRetweetMeCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetRetweetsOfMe(GetTimelineRetweetMeCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Statuses.RetweetsOfMeXml, command);
            return from x in XElement.Parse(xml).Descendants("status") select new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Status> GetUserTimeline()
        {
            return this.GetUserTimeline(null as GetUserTimelineCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetUserTimeline(GetUserTimelineCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Statuses.UserTimelineXml, command);
            return from x in XElement.Parse(xml).Descendants("status") select new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Status> GetRetweetedToUser()
        {
            return this.GetRetweetedToUser(null as GetTimelineRetweetUserCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetRetweetedToUser(GetTimelineRetweetUserCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Statuses.RetweetedToUserXml, command);
            return from x in XElement.Parse(xml).Descendants("status") select new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Status> GetRetweetedByUser()
        {
            return this.GetRetweetedByUser(null as GetTimelineRetweetUserCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetRetweetedByUser(GetTimelineRetweetUserCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Statuses.RetweetedByUserXml, command);
            return from x in XElement.Parse(xml).Descendants("status") select new Status(x);
        }
    }
}
