﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<User> GetRetweetedBy(Int64 id)
        {
            var cm = new GetUserRetweetByCommand();
            cm.ID = id.ToString();
            return this.GetRetweetedBy(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<User> GetRetweetedBy(GetUserRetweetByCommand command)
        {
            String xml = this.GetXml(String.Format(TwitterApiUrl.Version1.Tweets.RetweetedByFormatXml, command.ID), command);
            return from user in XElement.Parse(xml).Descendants("user") select new User(user);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<String> GetRetweetedByIDs(Int64 id)
        {
            var cm = new GetUserRetweetByIDsCommand();
            cm.ID = id.ToString();
            return this.GetRetweetedByIDs(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<String> GetRetweetedByIDs(GetUserRetweetByIDsCommand command)
        {
            String xml = this.GetXml(String.Format(TwitterApiUrl.Version1.Tweets.RetweetedByIDsFormatXml, command.ID), command);
            return from user in XElement.Parse(xml).Descendants("id") select user.Value;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Status> GetRetweets()
        {
            return this.GetRetweets(null as GetRetweetsCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetRetweets(GetRetweetsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Tweets.RetweetsFormatXml, command);
            return from x in XElement.Parse(xml).Descendants("status") select new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Status GetStatus(String id)
        {
            return this.GetStatus(new GetStatusCommand() { ID = id });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Status GetStatus(GetStatusCommand command)
        {
            String xml = this.GetXml(String.Format(TwitterApiUrl.Version1.Tweets.ShowFormatXml, command.ID), command);
            XElement x = XElement.Parse(xml);
            return new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Status DestroyStatus(Int64 id)
        {
            String xml = this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.Tweets.DestroyFormatXml, id));
            XElement x = XElement.Parse(xml);
            return new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Status DestroyStatus(GetStatusCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.Tweets.DestroyFormatXml, command.ID), command);
            XElement x = XElement.Parse(xml);
            return new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Status RetweetStatus(Int64 id)
        {
            String xml = this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.Tweets.RetweetFormatXml, id));
            XElement x = XElement.Parse(xml);
            return new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Status RetweetStatus(GetStatusCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.Tweets.RetweetFormatXml, command.ID), command);
            XElement x = XElement.Parse(xml);
            return new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="tweetText"></param>
        /// <returns></returns>
        public Status UpdateStatus(String tweetText)
        {
            var cm = new UpdateStatusCommand();
            cm.Status = tweetText;
            return this.UpdateStatus(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Status UpdateStatus(UpdateStatusCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Tweets.UpdateFormatXml, command);
            XElement x = XElement.Parse(xml);
            return new Status(x);
        }

    }
}
