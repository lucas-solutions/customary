﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <returns></returns>
        public IEnumerable<User> LookupUsers(params Int64[] values)
        {
            StringBuilder sb = new StringBuilder(256);
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append(values[i]);
                if (i < values.Length - 1)
                {
                    sb.Append(",");
                }
            }
            var cm = new LookupUserCommand();
            cm.UserID = sb.ToString();
            return this.LookupUsers(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <returns></returns>
        public IEnumerable<User> LookupUsers(params String[] values)
        {
            StringBuilder sb = new StringBuilder(256);
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append(values[i]);
                if (i < values.Length - 1)
                {
                    sb.Append(",");
                }
            }
            var cm = new LookupUserCommand();
            cm.ScreenName = sb.ToString();
            return this.LookupUsers(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<User> LookupUsers(LookupUserCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Users.LookupXml, command);
            return from x in XElement.Parse(xml).Descendants("user") select new User(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public IEnumerable<User> SearchUsers(String query)
        {
            return this.SearchUsers(new SearchUserCommand() { Query = query });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<User> SearchUsers(SearchUserCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Users.SearchXml, command);
            return from x in XElement.Parse(xml).Descendants("user") select new User(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public User ShowUser(Int64 id)
        {
            return this.ShowUser(new ShowUserCommand() { UserID = id });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <returns></returns>
        public User ShowUser(String screenName)
        {
            return this.ShowUser(new ShowUserCommand() { ScreenName = screenName });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User ShowUser(ShowUserCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Users.ShowXml, command);
            XElement x = XElement.Parse(xml);
            return new User(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<User> GetContributees(Int64 id)
        {
            return this.GetContributees(new GetContributeesCommand() { UserID = id });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <returns></returns>
        public IEnumerable<User> GetContributees(String screenName)
        {
            return this.GetContributees(new GetContributeesCommand() { ScreenName = screenName });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<User> GetContributees(GetContributeesCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Users.ContributeesXml, command);
            return from x in XElement.Parse(xml).Descendants("user") select new User(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IEnumerable<User> GetContributors(Int64 id)
        {
            return this.GetContributors(new GetContributorsCommand() { UserID = id });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <returns></returns>
        public IEnumerable<User> GetContributors(String screenName)
        {
            return this.GetContributors(new GetContributorsCommand() { ScreenName = screenName });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<User> GetContributors(GetContributorsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Users.ContributorsXml, command);
            return from x in XElement.Parse(xml).Descendants("user") select new User(x);
        }
    }
}
