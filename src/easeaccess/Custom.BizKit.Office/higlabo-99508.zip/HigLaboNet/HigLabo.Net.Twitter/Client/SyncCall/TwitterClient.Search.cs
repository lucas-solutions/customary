﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Xml.Linq;
using HigLabo.Net;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public SearchResult Search(String query)
        {
            return this.Search(new SearchCommand() { Query = query });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public SearchResult Search(SearchCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.SearchXml, command);
            XElement x = XElement.Parse(xml);
            return new SearchResult(x);
        }
    }
}
