﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="woeID"></param>
        /// <returns></returns>
        public Trends GetTrends(Int32 woeID)
        {
            GetTrendsCommand command = new GetTrendsCommand();
            command.WoeID = woeID;
            return GetTrends(command);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Trends GetTrends(GetTrendsCommand command)
        {
            String xml = this.GetXml(String.Format(TwitterApiUrl.Version1.LocalTrends.GetTrendsXml, command.WoeID), command);
            return new Trends(XElement.Parse(xml).Element("trends"));
        }

    }
}
