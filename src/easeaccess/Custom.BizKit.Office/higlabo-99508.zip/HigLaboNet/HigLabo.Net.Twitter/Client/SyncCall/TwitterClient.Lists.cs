﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IEnumerable<List> GetAllLists()
        {
            return this.GetAllLists(null);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<List> GetAllLists(GetAllListsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.GetAllListsXml, command);
            return from x in XElement.Parse(xml).Descendants("list") select new List(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Status> GetListsStatuses(GetListsStatusesCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.GetListsStatusesXml, command);
            return from x in XElement.Parse(xml).Descendants("status") select new Status(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User DestroyListMembers(DestroyListsMembersCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Lists.DestroyListsMembersXml, command);
            return new User(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<List> GetListsMemberships(GetListsMembershipsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.GetListsMembershipsXml, command);
            return from x in XElement.Parse(xml).Descendants("list") select new List(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Friends GetListsSubscribers()
        {
            return this.GetListsSubscribers(null as GetListsSubscribersCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Friends GetListsSubscribers(GetListsSubscribersCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.GetListsSubscribersXml, command);
            var x = XElement.Parse(xml);
            return new Friends(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User CreateListsSubscribers(CreateListsSubscribersCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Lists.CreateListsSubscribersXml, command);
            return new User(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Friends ShowListsSubscribers(ShowListsSubscribers command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.ShowListsSubscribersXml, command);
            var x = XElement.Parse(xml);
            return new Friends(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User DestroyListsSubscribers(DestroyListsSubscribersCommand command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Lists.DestroyListsSubscribersXml, command);
            return new User(XElement.Parse(xml));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <returns></returns>
        public IEnumerable<Friendship> CreateAllListsMembers(params Int64[] values)
        {
            StringBuilder sb = new StringBuilder(256);
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append(values[i]);
                if (i < values.Length - 1)
                {
                    sb.Append(",");
                }
            }
            var cm = new CreateAllListsMembersCommand();
            cm.UserID = sb.ToString();
            return this.CreateAllListsMembers(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <returns></returns>
        public IEnumerable<Friendship> CreateAllListsMembers(params String[] values)
        {
            StringBuilder sb = new StringBuilder(256);
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append(values[i]);
                if (i < values.Length - 1)
                {
                    sb.Append(",");
                }
            }
            var cm = new CreateAllListsMembersCommand();
            cm.ScreenName = sb.ToString();
            return this.CreateAllListsMembers(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<Friendship> CreateAllListsMembers(CreateAllListsMembersCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.CreateAllListsMembersXml, command);
            return from x in XElement.Parse(xml).Descendants("relationship") select new Friendship(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Friends ShowListsMembers(ShowListsMembersCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.ShowListsMembersXml, command);
            var x = XElement.Parse(xml);
            return new Friends(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<User> GetListsMembers(GetListsMembersCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.GetListsMembersXml, command);
            return from x in XElement.Parse(xml).Descendants("user") select new User(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public User CreateListsMembers(CreateListsMembersCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.CreateListsMembersXml, command);
            var x = XElement.Parse(xml);
            return new User(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public List DestroyLists(DestroyListsCommnad command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.DestroyListsXml, command);
            var x = XElement.Parse(xml);
            return new List(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public List UpdateLists(UpdateListsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.UdateListsXml, command);
            var x = XElement.Parse(xml);
            return new List(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public List CreateLists(CreateListsCommnad command)
        {
            String xml = this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Lists.CreateListsXml, command);
            var x = XElement.Parse(xml);
            return new List(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IEnumerable<List> GetLists(GetListsCommand command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.GetListsXml, command);
            return from x in XElement.Parse(xml).Descendants("lists") select new List(x);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public List ShowLists(ShowListsCommnad command)
        {
            String xml = this.GetXml(TwitterApiUrl.Version1.Lists.ShowListsXml, command);
            var x = XElement.Parse(xml);
            return new List(x);
        }
    }
}
