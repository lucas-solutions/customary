﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Xml.Linq;
using HigLabo.Net;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="callback"></param>
        public void Search(String query, Action<SearchResult> callback)
        {
            this.Search(new SearchCommand() { Query = query }, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void Search(SearchCommand command, Action<SearchResult> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.SearchXml, command, xml => callback(new SearchResult(XElement.Parse(xml))));
        }
    }
}
