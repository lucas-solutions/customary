﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetDirectMessageList(Action<IEnumerable<DirectMessage>> callback)
        {
            this.GetDirectMessageList(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetDirectMessageList(GetDirectMessageListCommand command, Action<IEnumerable<DirectMessage>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.DirectMessages.DirectMessagesXml, command
                , xml =>callback(from d in XElement.Parse(xml).Descendants("direct_message") select new DirectMessage(d)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetDirectMessageListSent(Action<IEnumerable<DirectMessage>> callback)
        {
            this.GetDirectMessageListSent(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetDirectMessageListSent(GetDirectMessageListSentCommand command, Action<IEnumerable<DirectMessage>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.DirectMessages.DirectMessagesSentXml, command
                , xml => callback(from d in XElement.Parse(xml).Descendants("direct_message") select new DirectMessage(d)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void DestroyDirectMessage(String id, Action<DirectMessage> callback)
        {
            this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.DirectMessages.DestroyFormatXml, id)
                , xml => callback(new DirectMessage(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void DestroyDirectMessage(DestroyDirectMessageCommand command, Action<DirectMessage> callback)
        {
            this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.DirectMessages.DestroyFormatXml, command.ID), command
                , xml => callback(new DirectMessage(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="text"></param>
        /// <param name="callback"></param>
        public void NewDirectMessage(String userID, String text, Action<DirectMessage> callback)
        {
            var cm = new NewDirectMessageCommand();
            cm.UserID = userID;
            cm.Text = text;
            this.NewDirectMessage(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void NewDirectMessage(NewDirectMessageCommand command, Action<DirectMessage> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.DirectMessages.NewXml, command
                , xml => callback(new DirectMessage(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetDirectMessage(String id, Action<DirectMessage> callback)
        {
            this.GetDirectMessage(new GetDirectMessageCommand() { ID = id }, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetDirectMessage(GetDirectMessageCommand command, Action<DirectMessage> callback)
        {
            this.GetXml(String.Format(TwitterApiUrl.Version1.DirectMessages.GetFormatXml, command.ID), command
                , xml => callback(new DirectMessage(XElement.Parse(xml))));
        }
    }
}
