﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="screenName"></param>
        /// <param name="callback"></param>
        public void GetAllLists(Int64 userID, String screenName, Action<IEnumerable<List>> callback)
        {
            var cm = new GetAllListsCommand();
            cm.UserID = userID;
            cm.ScreenName = screenName;
            this.GetAllLists(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetAllLists(GetAllListsCommand command, Action<IEnumerable<List>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Lists.GetAllListsXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("list") select new List(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetListsStatuses(Action<IEnumerable<Status>> callback)
        {
            this.GetListsStatuses(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetListsStatuses(GetListsStatusesCommand command, Action<IEnumerable<Status>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Lists.GetListsStatusesXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("status") select new Status(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void DestroyListMembers(Action<User> callback)
        {
            this.DestroyListMembers(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void DestroyListMembers(DestroyListsMembersCommand command, Action<User> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Lists.DestroyListsMembersXml, command
                , xml => callback(new User(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetListsMemberships(GetListsMembershipsCommand command, Action<IEnumerable<List>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Lists.GetAllListsXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("list") select new List(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetListsSubscribers(Action<Friends> callback)
        {
            this.GetListsSubscribers(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetListsSubscribers(GetListsSubscribersCommand command, Action<Friends> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Lists.GetListsSubscribersXml, command
                , xml => callback(new Friends(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void CreateListsSubscribers(CreateListsSubscribersCommand command, Action<User> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Lists.CreateListsSubscribersXml, command
                , xml => callback(new User(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void ShowListsSubscribers(Action<Friends> callback)
        {
            this.ShowListsSubscribers(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void ShowListsSubscribers(DestroyListsMembersCommand command, Action<Friends> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Lists.ShowListsSubscribersXml, command
                , xml => callback(new Friends(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void DestroyListsSubscribers(DestroyListsSubscribersCommand command, Action<User> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Lists.DestroyListsSubscribersXml, command
                , xml => callback(new User(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="callback"></param>
        public void CreateAllListsMembers(Int64[] values, Action<IEnumerable<Friendship>> callback)
        {
            StringBuilder sb = new StringBuilder(256);
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append(values[i]);
                if (i < values.Length - 1)
                {
                    sb.Append(",");
                }
            }
            var cm = new CreateAllListsMembersCommand();
            cm.UserID = sb.ToString();
            this.CreateAllListsMembers(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="callback"></param>
        public void CreateAllListsMembers(String[] values, Action<IEnumerable<Friendship>> callback)
        {
            StringBuilder sb = new StringBuilder(256);
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append(values[i]);
                if (i < values.Length - 1)
                {
                    sb.Append(",");
                }
            }
            var cm = new CreateAllListsMembersCommand();
            cm.ScreenName = sb.ToString();
            this.CreateAllListsMembers(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void CreateAllListsMembers(CreateAllListsMembersCommand command, Action<IEnumerable<Friendship>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Lists.CreateAllListsMembersXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("relationship") select new Friendship(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void ShowListsMembers(Action<Friends> callback)
        {
            this.ShowListsMembers(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void ShowListsMembers(ShowListsMembersCommand command, Action<Friends> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Lists.ShowListsMembersXml, command
                , xml => callback(new Friends(XElement.Parse(xml))));
        }
    }
}
