﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="callback"></param>
        public void GetFollowers(String userID, Action<Friends> callback)
        {
            var cm = new GetFriendsCommand();
            cm.UserID = userID;
            this.GetFollowers(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetFollowers(GetFriendsCommand command, Action<Friends> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Friends.FollowersXml, command
                , xml => callback(new Friends(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="callback"></param>
        public void GetFriends(String userID, Action<Friends> callback)
        {
            var cm = new GetFriendsCommand();
            cm.UserID = userID;
            this.GetFriends(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetFriends(GetFriendsCommand command, Action<Friends> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Friends.FriendsXml, command
                , xml => callback(new Friends(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID_A"></param>
        /// <param name="userID_B"></param>
        /// <param name="callback"></param>
        public void ExistsFriendships(Int64 userID_A, Int64 userID_B, Action<Boolean> callback)
        {
            var cm = new ExistsFriendshipsCommand();
            cm.UserID_A = userID_A;
            cm.UserID_B = userID_B;
            this.ExistsFriendships(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName_A"></param>
        /// <param name="screenName_B"></param>
        /// <param name="callback"></param>
        public void ExistsFriendships(String screenName_A, String screenName_B, Action<Boolean> callback)
        {
            var cm = new ExistsFriendshipsCommand();
            cm.ScreenName_A = screenName_A;
            cm.ScreenName_B = screenName_B;
            this.ExistsFriendships(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void ExistsFriendships(ExistsFriendshipsCommand command, Action<Boolean> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Friends.ExistsFriendshipsXml, command
                , xml => callback(XElement.Parse(xml).Value.ToLower() == "true"));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetIncomingFriends(Action<Friends> callback)
        {
            this.GetIncomingFriends(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetIncomingFriends(GetPendingFollowFriendsCommand command, Action<Friends> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Friends.IncomingXml, command
                , xml  => callback(new Friends(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetOutgoingFriends(Action<Friends> callback)
        {
            this.GetOutgoingFriends(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetOutgoingFriends(GetPendingFollowFriendsCommand command, Action<Friends> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Friends.OutgoingXml, command
                , xml => callback(new Friends(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceID"></param>
        /// <param name="targetID"></param>
        /// <param name="callback"></param>
        public void ShowFriendships(Int64 sourceID, Int64 targetID, Action<Relationship> callback)
        {
            var cm = new ShowFriendshipsCommand();
            cm.SourceID = sourceID;
            cm.TargetID = targetID;
            this.ShowFriendships(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sourceScreenName"></param>
        /// <param name="targetScreenName"></param>
        /// <param name="callback"></param>
        public void ShowFriendships(String sourceScreenName, String targetScreenName, Action<Relationship> callback)
        {
            var cm = new ShowFriendshipsCommand();
            cm.SourceScreenName = sourceScreenName;
            cm.TargetScreenName = targetScreenName;
            this.ShowFriendships(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void ShowFriendships(ShowFriendshipsCommand command, Action<Relationship> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Friends.ShowXml, command
                , xml => callback(new Relationship(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="callback"></param>
        public void DestroyFriendship(Int64 userID, Action<User> callback)
        {
            var cm = new DestroyFriendshipCommand();
            cm.UserID = userID;
            this.DestroyFriendship(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <param name="callback"></param>
        public void DestroyFriendship(String screenName, Action<User> callback)
        {
            var cm = new DestroyFriendshipCommand();
            cm.ScreenName = screenName;
            this.DestroyFriendship(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void DestroyFriendship(DestroyFriendshipCommand command, Action<User> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Friends.DestroyXml, command
                , xml => callback(new User(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="callback"></param>
        public void CreateFriendship(Int64 userID, Action<User> callback)
        {
            var cm = new CreateFriendshipCommand();
            cm.UserID = userID;
            this.CreateFriendship(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <param name="callback"></param>
        public void CreateFriendship(String screenName, Action<User> callback)
        {
            var cm = new CreateFriendshipCommand();
            cm.ScreenName = screenName;
            this.CreateFriendship(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void CreateFriendship(CreateFriendshipCommand command, Action<User> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Friends.CreateXml, command
                , xml => callback(new User(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UpdateFriendship(UpdateFriendshipCommand command, Action< Relationship> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Friends.UpdateXml, command
                , xml => callback(new Relationship(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetNoRetweetIDs(Action<IEnumerable<Int64>> callback)
        {
            this.GetNoRetweetIDs(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetNoRetweetIDs(GetNoRetweetIDsCommand command, Action<IEnumerable<Int64>> callback)
        {
            this.GetXml(HttpMethodName.Get, TwitterApiUrl.Version1.Friends.NoRetweetIDsXml, command
                , xml => callback(XElement.Parse(xml).Descendants("id").Select(el => Int64.Parse(el.Value))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="callback"></param>
        public void LookupFriendships(Int64[] values, Action<IEnumerable<Friendship>> callback)
        {
            StringBuilder sb = new StringBuilder(256);
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append(values[i]);
                if (i < values.Length - 1)
                {
                    sb.Append(",");
                }
            }
            var cm = new LookupFriendshipsCommand();
            cm.UserID = sb.ToString();
            this.LookupFriendships(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="callback"></param>
        public void LookupFriendships(String[] values, Action<IEnumerable<Friendship>> callback)
        {
            StringBuilder sb = new StringBuilder(256);
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append(values[i]);
                if (i < values.Length - 1)
                {
                    sb.Append(",");
                }
            }
            var cm = new LookupFriendshipsCommand();
            cm.ScreenName = sb.ToString();
            this.LookupFriendships(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void LookupFriendships(LookupFriendshipsCommand command, Action<IEnumerable<Friendship>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Friends.LookupXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("relationship") select new Friendship(x)));
        }
    }
}
