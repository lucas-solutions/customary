﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="language"></param>
        /// <param name="callback"></param>
        public void GetSuggestions(String language, Action<IEnumerable<Suggestion>> callback)
        {
            var cm = new GetSuggestionsCommand();
            cm.Lang = language;
            this.GetSuggestions(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetSuggestions(GetSuggestionsCommand command, Action<IEnumerable<Suggestion>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Suggestions.SuggestionsXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("category") select new Suggestion(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="slug"></param>
        /// <param name="language"></param>
        /// <param name="callback"></param>
        public void GetSuggetstionsSlug(String slug, String language, Action<Suggestion> callback)
        {
            var cm = new GetSuggestionsSlugCommand();
            cm.Slug = slug;
            cm.Lang = language;
            this.GetSuggetstionsSlug(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetSuggetstionsSlug(GetSuggestionsSlugCommand command, Action<Suggestion> callback)
        {
            this.GetXml(String.Format(TwitterApiUrl.Version1.Suggestions.SuggestionsSlugXml, command.Slug), command
                , xml => callback(new Suggestion(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="slug"></param>
        /// <param name="callback"></param>
        public void GetSuggestionUsers(String slug, Action<IEnumerable<User>> callback)
        {
            var cm = new GetSuggestionUsersCommand();
            cm.Slug = slug;
            this.GetSuggestionUsers(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="calback"></param>
        public void GetSuggestionUsers(GetSuggestionUsersCommand command, Action<IEnumerable<User>> calback)
        {
            this.GetXml(String.Format(TwitterApiUrl.Version1.Suggestions.SuggestionUsersXml, command.Slug), command
                , xml => calback(from x in XElement.Parse(xml).Descendants("user") select new User(x)));
        }
    }
}
