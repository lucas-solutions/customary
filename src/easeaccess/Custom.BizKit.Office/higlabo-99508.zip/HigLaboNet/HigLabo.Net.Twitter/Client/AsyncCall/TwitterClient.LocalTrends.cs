﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="woeID"></param>
        /// <param name="callback"></param>
        public void GetTrends(Int32 woeID, Action<Trends> callback)
        {
            GetTrendsCommand command = new GetTrendsCommand();
            command.WoeID = woeID;
            this.GetTrends(command, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetTrends(GetTrendsCommand command, Action<Trends> callback)
        {
            this.GetXml(String.Format(TwitterApiUrl.Version1.LocalTrends.GetTrendsXml, command.WoeID), command
                , xml => callback(new Trends(XElement.Parse(xml).Element("trends"))));
        }
    }
}
