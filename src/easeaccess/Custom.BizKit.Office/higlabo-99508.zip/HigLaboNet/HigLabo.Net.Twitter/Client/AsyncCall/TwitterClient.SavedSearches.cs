﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetSavedSearches(Int64 id, Action<SavedSearch> callback)
        {
            this.GetXml(String.Format(TwitterApiUrl.Version1.SavedSearches.GetSavedSearchesByIdXml, id)
                , xml => callback(new SavedSearch(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetSavedSearches(Action<IEnumerable<SavedSearch>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.SavedSearches.GetSavedSearchesXml
                , xml => callback(from x in XElement.Parse(xml).Descendants("saved_search") select new SavedSearch(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="callback"></param>
        public void CreateSavedSearches(String query, Action<SavedSearch> callback)
        {
            CreateSavedSearchesCommand command = new CreateSavedSearchesCommand();
            command.Query = query;
            this.CreateSavedSearches(command, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void CreateSavedSearches(CreateSavedSearchesCommand command, Action<SavedSearch> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.SavedSearches.CreateSavedSearchesXml, command
                , xml => callback(new SavedSearch(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void DestroySavedSearches(Int64 id, Action<SavedSearch> callback)
        {
            this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.SavedSearches.DestroySavedSearchesIdXml, id)
                , xml => callback(new SavedSearch(XElement.Parse(xml))));
        }
    }
}
