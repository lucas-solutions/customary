﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="callback"></param>
        public void LookupUsers(Int64[] values, Action<IEnumerable<User>> callback)
        {
            StringBuilder sb = new StringBuilder(256);
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append(values[i]);
                if (i < values.Length - 1)
                {
                    sb.Append(",");
                }
            }
            var cm = new LookupUserCommand();
            cm.UserID = sb.ToString();
            this.LookupUsers(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="values"></param>
        /// <param name="callback"></param>
        public void LookupUsers(String[] values, Action<IEnumerable<User>> callback)
        {
            StringBuilder sb = new StringBuilder(256);
            for (int i = 0; i < values.Length; i++)
            {
                sb.Append(values[i]);
                if (i < values.Length - 1)
                {
                    sb.Append(",");
                }
            }
            var cm = new LookupUserCommand();
            cm.ScreenName = sb.ToString();
            this.LookupUsers(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void LookupUsers(LookupUserCommand command, Action<IEnumerable<User>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Users.LookupXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("user") select new User(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="callback"></param>
        public void SearchUsers(String query, Action<IEnumerable<User>> callback)
        {
            this.SearchUsers(new SearchUserCommand() { Query = query }, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void SearchUsers(SearchUserCommand command, Action<IEnumerable<User>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Users.SearchXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("user") select new User(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void ShowUser(Int64 id, Action<User> callback)
        {
            this.ShowUser(new ShowUserCommand() { UserID = id }, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <param name="callback"></param>
        public void ShowUser(String screenName, Action<User> callback)
        {
            this.ShowUser(new ShowUserCommand() { ScreenName = screenName }, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void ShowUser(ShowUserCommand command, Action<User> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Users.ShowXml, command
                , xml => callback(new User(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetContributees(Int64 id, Action<IEnumerable<User>> callback)
        {
            this.GetContributees(new GetContributeesCommand() { UserID = id }, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <param name="callback"></param>
        public void GetContributees(String screenName, Action<IEnumerable<User>> callback)
        {
            this.GetContributees(new GetContributeesCommand() { ScreenName = screenName }, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetContributees(GetContributeesCommand command, Action<IEnumerable<User>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Users.ContributeesXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("user") select new User(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetContributors(Int64 id, Action<IEnumerable<User>> callback)
        {
            this.GetContributors(new GetContributorsCommand() { UserID = id }, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="screenName"></param>
        /// <param name="callback"></param>
        public void GetContributors(String screenName, Action<IEnumerable<User>> callback)
        {
            this.GetContributors(new GetContributorsCommand() { ScreenName = screenName }, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetContributors(GetContributorsCommand command, Action<IEnumerable<User>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Users.ContributorsXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("user") select new User(x)));
        }
    }
}
