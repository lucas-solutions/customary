﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="page"></param>
        /// <param name="includeEntities"></param>
        /// <param name="callback"></param>
        public void GetFavorites(Int64 id, Int32 page, Boolean includeEntities, Action<IEnumerable<Status>> callback)
        {
            var cm = new GetFavoritesCommand();
            cm.ID = id;
            cm.Page = page;
            cm.IncludeEntities = includeEntities;
            this.GetFavorites(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetFavorites(GetFavoritesCommand command, Action<IEnumerable<Status>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Favorites.GetFavoritesXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("status") select new Status(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="includeEntities"></param>
        /// <param name="callback"></param>
        public void CreateFavorites(Int64 id, Boolean includeEntities, Action<Status> callback)
        {
            var cm = new CreateFavoritesCommand();
            cm.ID = id;
            cm.IncludeEntities = includeEntities;
            this.CreateFavorites(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void CreateFavorites(CreateFavoritesCommand command, Action<Status> callback)
        {
            this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.Favorites.CreateFavoritesXml, command.ID), command
                , xml => callback(new Status(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void DestroyFavorites(Int64 id, Action<Status> callback)
        {
            var cm = new DestroyFavoritesCommand();
            cm.ID = id;
            this.DestroyFavorites(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void DestroyFavorites(DestroyFavoritesCommand command, Action<Status> callback)
        {
            this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.Favorites.DestroyFavoritesXml, command.ID), command
                , xml => callback(new Status(XElement.Parse(xml))));
        }
    }
}
