﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetRetweetedBy(Int64 id, Action<IEnumerable<User>> callback)
        {
            var cm = new GetUserRetweetByCommand();
            cm.ID = id.ToString();
            this.GetRetweetedBy(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetRetweetedBy(GetUserRetweetByCommand command, Action<IEnumerable<User>> callback)
        {
            this.GetXml(String.Format(TwitterApiUrl.Version1.Tweets.RetweetedByFormatXml, command.ID), command
                , xml => callback(from user in XElement.Parse(xml).Descendants("user") select new User(user)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetRetweetedByIDs(Int64 id, Action<IEnumerable<String>> callback)
        {
            var cm = new GetUserRetweetByIDsCommand();
            cm.ID = id.ToString();
            this.GetRetweetedByIDs(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetRetweetedByIDs(GetUserRetweetByIDsCommand command, Action<IEnumerable<String>> callback)
        {
            this.GetXml(String.Format(TwitterApiUrl.Version1.Tweets.RetweetedByIDsFormatXml, command.ID), command
                , xml => callback(from user in XElement.Parse(xml).Descendants("id") select user.Value));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetRetweets(Action<IEnumerable<Status>> callback)
        {
            this.GetRetweets(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetRetweets(GetRetweetsCommand command, Action<IEnumerable<Status>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Tweets.RetweetsFormatXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("status") select new Status(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetStatus(String id, Action<Status> callback)
        {
            this.GetStatus(new GetStatusCommand() { ID = id }, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetStatus(GetStatusCommand command, Action<Status> callback)
        {
            this.GetXml(String.Format(TwitterApiUrl.Version1.Tweets.ShowFormatXml, command.ID), command
                , xml => callback(new Status(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void DestroyStatus(Int64 id, Action<Status> callback)
        {
            this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.Tweets.DestroyFormatXml, id)
                , xml => callback(new Status(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void DestroyStatus(GetStatusCommand command, Action<Status> callback)
        {
            this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.Tweets.DestroyFormatXml, command.ID), command
                , xml => callback(new Status(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void RetweetStatus(Int64 id, Action<Status> callback)
        {
            this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.Tweets.RetweetFormatXml, id)
                , xml => callback(new Status(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void RetweetStatus(GetStatusCommand command, Action<Status> callback)
        {
            this.GetXml(HttpMethodName.Post, String.Format(TwitterApiUrl.Version1.Tweets.RetweetFormatXml, command.ID), command
                , xml => callback(new Status(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="tweetText"></param>
        /// <param name="callback"></param>
        public void UpdateStatus(String tweetText, Action<Status> callback)
        {
            var cm = new UpdateStatusCommand();
            cm.Status = tweetText;
            this.UpdateStatus(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UpdateStatus(UpdateStatusCommand command, Action<Status> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Tweets.UpdateFormatXml, command
                , xml => callback(new Status(XElement.Parse(xml))));
        }
    }
}
