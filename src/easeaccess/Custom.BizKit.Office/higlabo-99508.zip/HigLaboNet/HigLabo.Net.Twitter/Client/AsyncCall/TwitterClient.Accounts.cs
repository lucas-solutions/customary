﻿using System;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetAccountRateLimitStatus(Action<RateLimitStatus> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Accounts.GetAccountRateLimitStatusXml, xml => callback(new RateLimitStatus(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="includeEntities"></param>
        /// <param name="skipStatus"></param>
        /// <param name="callback"></param>
        public void GetAccountVerifyCredentials(Boolean includeEntities, Boolean skipStatus, Action<User> callback)
        {
            var command = new GetAccountVerifyCredentialsCommand();
            command.IncludeEntities = includeEntities;
            command.SkipStatus = skipStatus;
            this.GetAccountVerifyCredentials(command, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetAccountVerifyCredentials(GetAccountVerifyCredentialsCommand command, Action<User> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Accounts.GetAccountVerifyCredentialsXml, command
                , xml => callback(new User(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void EndSessionAccount(Action<EndSession> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.EndSessionAccountXml
                , xml => callback(new EndSession(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="device"></param>
        /// <param name="includeEntities"></param>
        /// <param name="callback"></param>
        public void UpdateDeliveryDevice(String device, Boolean includeEntities, Action<User> callback)
        {
            var command = new UpdateDeliveryDeviceCommand();
            command.Device = device;
            command.IncludeEntities = includeEntities;
            UpdateDeliveryDevice(command, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UpdateDeliveryDevice(UpdateDeliveryDeviceCommand command, Action<User> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.UpdateDeliveryDeviceXml, command
                , xml => callback(new User(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UpdateProfile(UpdateProfileCommand command, Action<User> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.UpdateProfileXml, command
                , xml => callback(new User(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UpdateProfileBackgroundImage(UpdateProfileBackgroundImageCommand command, Action<User> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.UpdateProfileBackgroundImageXml, command
                , xml => callback(new User(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UpdateProfileBackgroundColors(UpdateProfileColorsCommand command, Action<User> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.UpdateProfileColorsXml, command
                , xml => callback(new User(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UpdateProfileImage(UpdateProfileImageCommand command, Action<User> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.UpdateProfileImageXml, command
                , xml => callback(new User(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetTotals(Action<Totals> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Accounts.GetTotalsXml, xml => callback(new Totals(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetAccountSettings(Action<AccountSettings> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Accounts.GetAccountSettingsXml, xml =>  callback(new AccountSettings(XElement.Parse(xml))));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UpdateAccountSettings(UpdateAccountSettingsCommand command, Action<AccountSettings> callback)
        {
            this.GetXml(HttpMethodName.Post, TwitterApiUrl.Version1.Accounts.UpdateAccountSettingXml, command
                , xml => callback(new AccountSettings(XElement.Parse(xml))));
        }
    }
}
