﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace HigLabo.Net.Twitter
{
    public partial class TwitterClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetHomeTimeline(Action<IEnumerable<Status>> callback)
        {
            this.GetHomeTimeline(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetHomeTimeline(GetHomeTimelineCommand command, Action<IEnumerable<Status>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Statuses.HomeTimeline.GetUrl(this.Format), command
                , text => callback(this.CreateResponseObjectList<Status>(text, "status")));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetMentions(Action<IEnumerable<Status>> callback)
        {
            this.GetMentions(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetMentions(GetMentionsCommand command, Action<IEnumerable<Status>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Statuses.MentionsXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("status") select new Status(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetPublicTimeline(Action<IEnumerable<Status>> callback)
        {
            this.GetPublicTimeline(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetPublicTimeline(GetPublicTimelineCommand command, Action<IEnumerable<Status>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Statuses.PublicTimelineXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("status") select new Status(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetRetweetedByMe(Action<IEnumerable<Status>> callback)
        {
            this.GetRetweetedByMe(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetRetweetedByMe(GetTimelineRetweetMeCommand command, Action<IEnumerable<Status>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Statuses.RetweetedByMeXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("status") select new Status(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetRetweetedToMe(Action<IEnumerable<Status>> callback)
        {
            this.GetRetweetedToMe(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetRetweetedToMe(GetTimelineRetweetMeCommand command, Action<IEnumerable<Status>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Statuses.RetweetedToMeXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("status") select new Status(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetRetweetsOfMe(Action<IEnumerable<Status>> callback)
        {
            this.GetRetweetsOfMe(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetRetweetsOfMe(GetTimelineRetweetMeCommand command, Action<IEnumerable<Status>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Statuses.RetweetsOfMeXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("status") select new Status(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetUserTimeline(Action<IEnumerable<Status>> callback)
        {
            this.GetUserTimeline(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetUserTimeline(GetUserTimelineCommand command, Action<IEnumerable<Status>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Statuses.UserTimelineXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("status") select new Status(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetRetweetedToUser(Action<IEnumerable<Status>> callback)
        {
            this.GetRetweetedToUser(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetRetweetedToUser(GetTimelineRetweetUserCommand command, Action<IEnumerable<Status>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Statuses.RetweetedToUserXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("status") select new Status(x)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetRetweetedByUser(Action<IEnumerable<Status>> callback)
        {
            this.GetRetweetedByUser(null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetRetweetedByUser(GetTimelineRetweetUserCommand command, Action<IEnumerable<Status>> callback)
        {
            this.GetXml(TwitterApiUrl.Version1.Statuses.RetweetedByUserXml, command
                , xml => callback(from x in XElement.Parse(xml).Descendants("status") select new Status(x)));
        }
    }
}
