﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Xml.Linq;
using HigLabo.Net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public partial class TwitterClient : OAuthClient
    {
        /// <summary>
        /// 
        /// </summary>
        public HttpProtocolType Protocol { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public TwitterApiResponseFormat Format { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String AccessToken { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String AccessTokenSecret { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="accessToken"></param>
        /// <param name="accessTokenSecret"></param>
        public TwitterClient(String consumerKey, String consumerSecret, String accessToken, String accessTokenSecret)
            : base(consumerKey, consumerSecret
                , "https://" + TwitterApiUrl.Version1.OAuth.RequestToken
                , "https://" + TwitterApiUrl.Version1.OAuth.AuthorizeToken
                , "https://" + TwitterApiUrl.Version1.OAuth.AccessToken)
        {
            this.Mode = OAuthMode.Header;
            this.Protocol = HttpProtocolType.Http;
            this.Format = TwitterApiResponseFormat.Xml;
            this.AccessToken = accessToken;
            this.AccessTokenSecret = accessTokenSecret;
        }
        private void GetXml(String url, Action<String> callback)
        {
            this.GetXml(HttpMethodName.Get, url, null, callback);
        }
        private void GetXml(HttpMethodName methodName, String url, Action<String> callback)
        {
            this.GetXml(methodName, url, null, callback);
        }
        private void GetXml(String url, TwitterCommand command, Action<String> callback)
        {
            this.GetXml(HttpMethodName.Get, url, command, callback);
        }
        private void GetXml(HttpMethodName methodName, String url, TwitterCommand command, Action<String> callback)
        {
            String u = this.Protocol.ToString().ToLower() + "://" + url;
            IDictionary<String, String> d = new Dictionary<string, string>();

            if (methodName == HttpMethodName.Put ||
                methodName == HttpMethodName.Delete)
            { throw new ArgumentException(); }

            if (command != null)
            {
                d = command.GetParameters();
            }
            this.GetResponse(methodName, u, this.AccessToken, this.AccessTokenSecret, d, res => callback(res.BodyText));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="text"></param>
        /// <param name="xElementKey"></param>
        /// <returns></returns>
        protected List<T> CreateResponseObjectList<T>(String text, String xElementKey)
            where T : ResponseObject, new ()
        {
            List<T> l = new List<T>();
            T rs;

            switch (this.Format)
            {
                case TwitterApiResponseFormat.Xml:
                    foreach (var x in XElement.Parse(text).Descendants(xElementKey))
                    {
                        rs = new T();
                        rs.SetProperty(x);
                        l.Add(rs);
                    }
                    return l;
                case TwitterApiResponseFormat.Json:
                    foreach (var s in CreateJsonTextList(text))
                    {
                        rs = new T();
                        rs.SetProperty(s);
                        l.Add(rs);
                    }
                    return l;
                default: throw new InvalidOperationException();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static List<String> CreateJsonTextList(Dictionary<String, Object> data, String key)
        {
            if (data.ContainsKey(key) == false) { return new List<String>(); }
            var c = data[key] as JContainer;
            if (c == null) { return new List<string>(); }
            return CreateJsonTextList(c);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        /// <returns></returns>
        public static List<String> CreateJsonTextList(String jsonText)
        {
            JContainer jc = JsonConvert.DeserializeObject(jsonText) as JContainer;
            if (jc == null) { return new List<string>(); }
            return CreateJsonTextList(jc);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="container"></param>
        /// <returns></returns>
        public static List<String> CreateJsonTextList(JContainer container)
        {
            List<String> l = new List<string>();

            foreach (Object o in container)
            {
                l.Add(o.ToString());
            }
            return l;
        }
    }
}
