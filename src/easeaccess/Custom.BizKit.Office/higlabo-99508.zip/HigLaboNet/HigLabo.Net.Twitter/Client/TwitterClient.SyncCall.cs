﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Xml.Linq;
using HigLabo.Net;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public partial class TwitterClient
    {
        private String GetXml(String url)
        {
            return this.GetXml(HttpMethodName.Get, url, new TwitterEmptyCommand());
        }
        private String GetXml(String url, TwitterCommand command)
        {
            return this.GetXml(HttpMethodName.Get, url, command);
        }
        private String GetXml(HttpMethodName methodName, String url)
        {
            return this.GetXml(methodName, url, new TwitterEmptyCommand());
        }
        private String GetXml(HttpMethodName methodName, String url, TwitterCommand command)
        {
            OAuthClient cl = this;
            String u = this.Protocol.ToString().ToLower() + "://" + url;
            IDictionary<String, String> d = new Dictionary<string, string>();

            if (methodName == HttpMethodName.Put ||
                methodName == HttpMethodName.Delete)
            { throw new ArgumentException(); }

            if (command != null)
            {
                d = command.GetParameters();
            }
            var res = cl.GetResponse(methodName, u, this.AccessToken, this.AccessTokenSecret, d);
            if (res.StatusCode != HttpStatusCode.OK)
            {
                throw new HttpResponseException(res);
            }
            return res.BodyText;
        }
    }
}
