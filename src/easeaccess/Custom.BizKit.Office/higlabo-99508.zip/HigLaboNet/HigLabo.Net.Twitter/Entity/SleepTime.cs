﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class SleepTime : ResponseObject
    {
        private Int32? _EndTime = null;
        private Boolean _Enabled = false;
        private Int32? _StartTime = null;

        /// <summary>
        /// 
        /// </summary>
        public Int32? EndTime
        {
            get { return _EndTime; }
            set { _EndTime = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public bool Enabled
        {
            get { return _Enabled; }
            set { _Enabled = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32? StartTime
        {
            get { return _StartTime; }
            set { _StartTime = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public SleepTime() { }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public SleepTime(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public SleepTime(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.EndTime = element.CastElementToInt32("sleep_time");
            this.StartTime = element.CastElementToInt32("start_time");
            this.Enabled = element.CastElementToBoolean("enabled") ?? this.Enabled;
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.EndTime = d.ToInt32("sleep_time") ;
            this.StartTime = d.ToInt32("start_time") ;
            this.Enabled = d.ToBoolean("enabled") ?? this.Enabled;
        }

    }
}
