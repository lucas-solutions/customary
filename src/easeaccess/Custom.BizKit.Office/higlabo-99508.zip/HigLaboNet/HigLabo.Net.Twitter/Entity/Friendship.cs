﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using Newtonsoft.Json.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class Friendship : ResponseObject
    {
        private Int64 _ID = 0;
        private String _IDStr = "";
        private String _Name = "";
        private String _ScreenName = "";
        private Boolean _Following = false;
        private Boolean _FollowedBy = false;
        private Boolean _FollowingRequest = false;
        /// <summary>
        /// 
        /// </summary>
        public Int64 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String IDStr
        {
            get { return _IDStr; }
            set { _IDStr = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ScreenName
        {
            get { return _ScreenName; }
            set { _ScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean Following
        {
            get { return _Following; }
            set { _Following = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean FollowedBy
        {
            get { return _FollowedBy; }
            set { _FollowedBy = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean FollowingRequest
        {
            get { return _FollowingRequest; }
            set { _FollowingRequest = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Friendship()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Friendship(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Friendship(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.ID = element.CastElementToInt64("id") ?? this.ID;
            this.Name = element.CastElementToString("name");
            this.ScreenName = element.CastElementToString("screen_name");
            this.IDStr = element.CastElementToString("id_str");

            foreach (var x in element.Descendants("connection"))
            {
                if (x.Value == "following")
                {
                    this.Following = true;
                }
                if (x.Value == "followed_by")
                {
                    this.FollowedBy = true;
                }
                if (x.Value == "following_requested")
                {
                    this.FollowingRequest = true;
                }
            }
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            object objOut = null;

            this.ID = d.ToInt64("id") ?? this.ID;
            this.Name = d.ToString("name");
            this.ScreenName = d.ToString("screen_name");
            this.IDStr = d.ToString("id_str");

            d.TryGetValue("ids", out objOut);
            JContainer val = (JContainer)objOut;

            for (int i = 0; i < val.Count(); i++)
            {
                if (val.ElementAt(i).ToString() == "following")
                {
                    this.Following = true;
                }
                if (val.ElementAt(i).ToString() == "followed_by")
                {
                    this.FollowedBy = true;
                }
                if (val.ElementAt(i).ToString() == "following_requested")
                {
                    this.FollowingRequest = true;
                }
            }            
        }
    }
}
