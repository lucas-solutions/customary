﻿using System.Xml.Linq;
using System.Collections.Generic;
using System;
using HigLabo.Net.Extensions;


namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class Relationship : ResponseObject
    {
        private FriendSource _Source = null;
        private FriendTarget _Target = null;
        /// <summary>
        /// 
        /// </summary>
        public FriendSource Source
        {
            get { return _Source; }
        }
        /// <summary>
        /// 
        /// </summary>
        public FriendTarget Target
        {
            get { return _Target; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Relationship(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Relationship(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            var d = this.SetElements(element);
            this._Target = new FriendTarget(element.Element("target"));
            this._Source = new FriendSource(element.Element("source"));
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this._Target = new FriendTarget(d.ToString("target"));
            this._Source = new FriendSource(d.ToString("source"));
        }
    }
}
