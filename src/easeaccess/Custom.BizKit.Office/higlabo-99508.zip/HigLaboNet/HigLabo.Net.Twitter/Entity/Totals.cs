﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class Totals : ResponseObject
    {
        private Int32 _Friends = 0;
        private Int32 _Updates = 0;
        private Int32 _Followers = 0;
        private Int32 _Favorites = 0;

        /// <summary>
        /// 
        /// </summary>
        public Int32 Friends
        {
            get { return _Friends; }
            set { _Friends = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Updates
        {
            get { return _Updates; }
            set { _Updates = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Followers
        {
            get { return _Followers; }
            set { _Followers = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Favorites
        {
            get { return _Favorites; }
            set { _Favorites = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public Totals()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Totals(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Totals(XElement element)
        {
            SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.Friends = element.CastElementToInt32("friends") ?? this.Friends;
            this.Updates = element.CastElementToInt32("updates") ?? this.Updates;
            this.Followers = element.CastElementToInt32("followers") ?? this.Followers;
            this.Favorites = element.CastElementToInt32("favorites") ?? this.Favorites;
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.Friends = d.ToInt32("friends") ?? this.Friends;
            this.Updates = d.ToInt32("updates") ?? this.Updates;
            this.Followers = d.ToInt32("followers") ?? this.Followers;
            this.Favorites = d.ToInt32("favorites") ?? this.Favorites;
        }
    }
}
