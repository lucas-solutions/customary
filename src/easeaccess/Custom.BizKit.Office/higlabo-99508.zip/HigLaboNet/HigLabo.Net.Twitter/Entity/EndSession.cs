﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class EndSession : ResponseObject
    {
        private String _Request = null;
        private String _Error = null;
        /// <summary>
        /// 
        /// </summary>
        public string Request
        {
            get { return _Request; }
            set { _Request = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Error
        {
            get { return _Error; }
            set { _Error = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public EndSession()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public EndSession(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public EndSession(XElement element)
        {
            SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.Request = element.CastElementToString("request");
            this.Error = element.CastElementToString("error");
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.Request = d.ToString("request");
            this.Error = d.ToString("error");
        }
    }
}
