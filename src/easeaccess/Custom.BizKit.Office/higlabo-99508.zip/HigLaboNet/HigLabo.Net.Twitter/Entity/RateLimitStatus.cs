﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class RateLimitStatus : ResponseObject
    {
        private Int32 _RemainingHits = 0;
        private Int64 _ResetTimeInSeconds;
        private Int32 _HourlyLimit = 0;
        private DateTimeOffset _ResetTime = DateTimeOffset.Now;
        private Photos _Photos = null;
        /// <summary>
        /// 
        /// </summary>
        public Int32 RemainingHits
        {
            get { return _RemainingHits; }
            set { _RemainingHits = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int64 ResetTimeInSeconds
        {
            get { return _ResetTimeInSeconds; }
            set { _ResetTimeInSeconds = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 HourlyLimit
        {
            get { return _HourlyLimit; }
            set { _HourlyLimit = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset ResetTime
        {
            get { return _ResetTime; }
            set { _ResetTime = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Photos Photos
        {
            get { return _Photos; }
            set { _Photos = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public RateLimitStatus()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public RateLimitStatus(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public RateLimitStatus(XElement element)
        {
            SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.RemainingHits = element.CastElementToInt32("remaining_hits") ?? this.RemainingHits;
            this.ResetTimeInSeconds = element.CastElementToInt64("reset_time_in_seconds") ?? this.ResetTimeInSeconds;
            this.HourlyLimit = element.CastElementToInt32("hourly_limit") ?? this.HourlyLimit;
            this.ResetTime = element.CastElementToDateTimeOffset("reset_time") ?? this.ResetTime;
            this.Photos = new Photos(element.Element("photos"));
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.RemainingHits = d.ToInt32("remaining_hits") ?? this.RemainingHits;
            this.ResetTimeInSeconds = d.ToInt64("reset_time_in_seconds") ?? this.ResetTimeInSeconds;
            this.HourlyLimit = d.ToInt32("hourly_limit") ?? this.HourlyLimit;
            this.ResetTime = d.ToDateTimeOffset("reset_time") ?? this.ResetTime;
            this.Photos = new Photos(d.ToString("photos"));
        }
    }
}
