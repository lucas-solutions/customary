﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class AccountSettings : ResponseObject
    {
        private SleepTime _SleepTime = null;
        private String _Language = null;
        private Boolean _AlwaysUseHttps = false;
        private Boolean _DiscoverableByEmail = false;
        private Boolean _GeoEnabled = false;
        private TrendLocation _TrendLocation = null;
        private TimeZone _TimeZone = null;
        /// <summary>
        /// 
        /// </summary>
        public SleepTime SleepTime
        {
            get { return _SleepTime; }
            set { _SleepTime = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Language
        {
            get { return _Language; }
            set { _Language = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public bool AlwaysUseHttps
        {
            get { return _AlwaysUseHttps; }
            set { _AlwaysUseHttps = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public bool GeoEnabled
        {
            get { return _GeoEnabled; }
            set { _GeoEnabled = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public TrendLocation TrendLocation
        {
            get { return _TrendLocation; }
            set { _TrendLocation = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public TimeZone TimeZone
        {
            get { return _TimeZone; }
            set { _TimeZone = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean DiscoverableByEmail
        {
            get { return _DiscoverableByEmail; }
            set { _DiscoverableByEmail = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public AccountSettings() { }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public AccountSettings(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public AccountSettings(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.SleepTime = new SleepTime(element.Element("sleep_time"));
            //###
            if (element.Element("trend_location") != null)
                this.TrendLocation = new TrendLocation(element.Element("trend_location"));
            if (element.Element("time_zone") != null)
                this.TimeZone = new TimeZone(element.Element("time_zone"));
            this.Language = element.CastElementToString("language");
            this.AlwaysUseHttps = element.CastElementToBoolean("always_use_https") ?? this.AlwaysUseHttps;
            this.DiscoverableByEmail = element.CastElementToBoolean("discoverable_by_email") ?? this.DiscoverableByEmail;
            this.GeoEnabled = element.CastElementToBoolean("geo_enabled") ?? this.GeoEnabled;
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.SleepTime = new SleepTime(d.ToString("sleep_time"));
            this.TrendLocation = new TrendLocation(d.ToString("trend_location"));
            this.TimeZone = new TimeZone(d.ToString("time_zone"));
            this.Language = d.ToString("language");
            this.AlwaysUseHttps = d.ToBoolean("always_use_https") ?? this.AlwaysUseHttps;
            this.DiscoverableByEmail = d.ToBoolean("discoverable_by_email") ?? this.DiscoverableByEmail;
            this.GeoEnabled = d.ToBoolean("geo_enabled") ?? this.GeoEnabled;
        }
    }
}
