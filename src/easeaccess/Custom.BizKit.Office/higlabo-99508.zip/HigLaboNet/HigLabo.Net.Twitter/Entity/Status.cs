﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class Status : ResponseObject 
    {
        private DateTimeOffset _CreatedAt = DateTimeOffset.Now;
        private Coordinate _Coordinates = null;
        private Boolean _Favorited = false;
        private Boolean _Truncated = false;
        private String _Url = "";
        private String _Text = "";
        private String _Annotations = "";
        private String _Contributors = "";
        private String _ID = "";
        private String _Geo = "";
        private String _InReplyToUserID = "";
        private User _User = null;
        private Place _Place = null;
        private String _InReplyToScreenName = "";
        private String _Source = "";
        private String _InReplyToStatusID = "";
        private Int32 _RetweetCount = 0;
        private Status _RetweetedStatus = null;
        private Boolean _Retweeted = false;
        private Entities _Entities = null;
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset CreatedAt
        {
            get { return _CreatedAt; }
            set { _CreatedAt = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Coordinate Coordinates
        {
            get { return _Coordinates; }
            set { _Coordinates = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean Favorited
        {
            get { return _Favorited; }
            set { _Favorited = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean Truncated
        {
            get { return _Truncated; }
            set { _Truncated = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Url
        {
            get { return _Url; }
            set { _Url = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Text
        {
            get { return _Text; }
            set { _Text = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Annotations
        {
            get { return _Annotations; }
            set { _Annotations = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Contributors
        {
            get { return _Contributors; }
            set { _Contributors = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Geo
        {
            get { return _Geo; }
            set { _Geo = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String InReplyToUserID
        {
            get { return _InReplyToUserID; }
            set { _InReplyToUserID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public User User
        {
            get { return _User; }
            set { _User = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Place Place
        {
            get { return _Place; }
            set { _Place = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String InReplyToScreenName
        {
            get { return _InReplyToScreenName; }
            set { _InReplyToScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Source
        {
            get { return _Source; }
            set { _Source = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String InReplyToStatusID
        {
            get { return _InReplyToStatusID; }
            set { _InReplyToStatusID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 RetweetCount
        {
            get { return _RetweetCount; }
            set { _RetweetCount = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean Retweeted
        {
            get { return _Retweeted; }
            set { _Retweeted = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Status RetweetedStatus
        {
            get { return _RetweetedStatus; }
            set { _RetweetedStatus = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Entities Entities
        {
            get { return _Entities; }
            set { _Entities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Status()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Status(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Status(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            var d = this.SetElements(element);
            this.CreatedAt = element.CastElementToDateTimeOffset("created_at") ?? this.CreatedAt;
            this.ID = element.CastElementToString("id");
            this.Url = element.CastElementToString("url");
            this.Text = element.CastElementToString("text");
            this.Favorited = element.CastElementToBoolean("favorited") ?? this.Favorited;
            this.Truncated = element.CastElementToBoolean("truncated") ?? this.Truncated;
            this.Source = element.CastElementToString("source");
            this.InReplyToScreenName = element.CastElementToString("in_reply_to_screen_name");
            this.InReplyToStatusID = element.CastElementToString("in_reply_to_status_id");
            this.InReplyToUserID = element.CastElementToString("in_reply_to_user_id");
            this.RetweetCount = element.CastElementToInt32("retweet_count") ?? this.RetweetCount;
            this.Retweeted = element.CastElementToBoolean("retweeted") ?? this.Retweeted;

            XElement retweeted_status = element.Element("retweeted_status");
            if (retweeted_status != null)
            {
                this.RetweetedStatus = new Status(retweeted_status);
            }
            XElement entities = element.Element("entities");
            if (entities != null)
            {
                this.Entities = new Entities(entities);
            }
            XElement user = element.Descendants("user").FirstOrDefault();
            if (user != null)
            {
                this.User = new User(user);
            }
            XElement coordinates = element.Descendants("coordinates").FirstOrDefault();
            if (coordinates != null)
            {
                this.Coordinates = null;
            }
            XElement place = element.Descendants("place").FirstOrDefault();
            if (place != null)
            {
                this.Place = new Place(place);
            }
            XElement contributors = element.Descendants("contributors").FirstOrDefault();
            if (contributors != null)
            {
                this.Contributors = null;
            }
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.CreatedAt = d.ToDateTimeOffset("created_at") ?? this.CreatedAt;
            this.ID = d.ToString("id");
            this.Url = d.ToString("url");
            this.Text = d.ToString("text");
            this.Favorited = d.ToBoolean("favorited") ?? this.Favorited;
            this.Truncated = d.ToBoolean("truncated") ?? this.Truncated;
            this.Source = d.ToString("source");
            this.InReplyToScreenName = d.ToString("in_reply_to_screen_name");
            this.InReplyToStatusID = d.ToString("in_reply_to_status_id");
            this.InReplyToUserID = d.ToString("in_reply_to_user_id");
            this.RetweetCount = d.ToInt32("retweet_count") ?? this.RetweetCount;
            this.Retweeted = d.ToBoolean("retweeted") ?? this.Retweeted;
            //Implement other..
            String retweeted_status = d.ToString("retweeted_status");
            if (!String.IsNullOrEmpty(retweeted_status))
            {
                this.RetweetedStatus = new Status(retweeted_status);
            }
            String entities = d.ToString("entities");
            if (!String.IsNullOrEmpty(entities))
            {
                this.Entities = new Entities(entities);
            }
            String user = d.ToString("user");
            if (user != null)
            {
                this.User = new User(user);
            }
            String coordinates = d.ToString("coordinates");
            if (!String.IsNullOrEmpty(coordinates))
            {
                this.Coordinates = null;
            }
            String place = d.ToString("place");
            if (!String.IsNullOrEmpty(place))
            {
                this.Place = new Place(place);
            }
            this.Contributors = d.ToString("contributors");            
        }
    }
}
