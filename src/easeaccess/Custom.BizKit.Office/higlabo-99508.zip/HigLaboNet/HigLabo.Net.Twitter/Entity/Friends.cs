﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using Newtonsoft.Json.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class Friends : ResponseObject
    {
        private Int32 _PreviousCursor = 0;
        private String _PreviousCursorStr = "";
        private Int32 _NextCursor = 0;
        private String _NextCursorStr = "";
        private List<String> _IDs = new List<string>();
        /// <summary>
        /// 
        /// </summary>
        public Int32 PreviousCursor
        {
            get { return _PreviousCursor; }
            set { _PreviousCursor = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String PreviousCursorStr
        {
            get { return _PreviousCursorStr; }
            set { _PreviousCursorStr = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 NextCursor
        {
            get { return _NextCursor; }
            set { _NextCursor = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String NextCursorStr
        {
            get { return _NextCursorStr; }
            set { _NextCursorStr = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public ICollection<String> IDs
        {
            get { return _IDs; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Friends()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Friends(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Friends(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.PreviousCursor = element.CastElementToInt32("previous_cursor") ?? this.PreviousCursor;
            this.PreviousCursorStr = element.CastElementToString("previous_cursor_str");
            this.NextCursor = element.CastElementToInt32("next_cursor") ?? this.NextCursor;
            this.NextCursorStr = element.CastElementToString("next_cursor_str");

            foreach (var x in element.Elements("ids"))
            {
                this._IDs.Add(x.Value);
            }
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            object objOut = null;
            this.PreviousCursor = d.ToInt32("previous_cursor") ?? this.PreviousCursor;
            this.PreviousCursorStr = d.ToString("previous_cursor_str");
            this.NextCursor = d.ToInt32("next_cursor") ?? this.NextCursor;
            this.NextCursorStr = d.ToString("next_cursor_str");
            d.TryGetValue("ids", out objOut);
            JContainer val = (JContainer)objOut;
            for (int i = 0; i < val.Count(); i++)
            {
                _IDs.Add(val.ElementAt(i).ToString());
            }
        }
    }
}
