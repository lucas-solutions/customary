﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;



namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class Place : ResponseObject
    {
        private String _Name = "";
        private String _CountryCode = "";
        private String _Country = "";
        private String _Url = "";
        private String _ID = "";
        private BoundingBox _BoundingBox = null;
        private String _FullName = "";
        private String _PlaceType = "";
        /// <summary>
        /// 
        /// </summary>
        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String CountryCode
        {
            get { return _CountryCode; }
            set { _CountryCode = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Country
        {
            get { return _Country; }
            set { _Country = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Url
        {
            get { return _Url; }
            set { _Url = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String FullName
        {
            get { return _FullName; }
            set { _FullName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String PlaceType
        {
            get { return _PlaceType; }
            set { _PlaceType = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Place()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Place(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Place(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.Name = element.CastElementToString("name");
            this.CountryCode = element.CastElementToString("country_code");
            this.Country = element.CastElementToString("country");
            this.Url = element.CastElementToString("url");
            this.ID = element.CastElementToString("id");
            this.FullName = element.CastElementToString("full_name");
            this.PlaceType = element.CastElementToString("place_type");

            if (element.Element("bounding_box") != null)
            {
                this._BoundingBox = new BoundingBox(element.Element("bounding_box"));
            }
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;            

            this.Name = d.ToString("name");
            this.CountryCode = d.ToString("country_code");
            this.Country = d.ToString("country");
            this.Url = d.ToString("url");
            this.ID = d.ToString("id");
            this.FullName = d.ToString("full_name");
            this.PlaceType = d.ToString("place_type");            

            if (!String.IsNullOrEmpty(d.ToString("bounding_box")))
            {
                this._BoundingBox = new BoundingBox(d.ToString("bounding_box"));
            }
        }
    }
}
