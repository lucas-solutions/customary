﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class DirectMessage : ResponseObject
    {
        private DateTimeOffset _CreatedAt = DateTimeOffset.Now;
        private String _Text = "";
        private String _ID = "";
        private String _SenderID = "";
        private String _RecipientID = "";
        private String _SenderScreenName = "";
        private String _RecipientScreenName = "";
        private User _SenderUser = null;
        private User _RecipientUser = null;
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset CreatedAt
        {
            get { return _CreatedAt; }
            set { _CreatedAt = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Text
        {
            get { return _Text; }
            set { _Text = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String SenderID
        {
            get { return _SenderID; }
            set { _SenderID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String RecipientID
        {
            get { return _RecipientID; }
            set { _RecipientID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String SenderScreenName
        {
            get { return _SenderScreenName; }
            set { _SenderScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String RecipientScreenName
        {
            get { return _RecipientScreenName; }
            set { _RecipientScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public User SenderUser
        {
            get { return _SenderUser; }
            set { _SenderUser = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public User RecipientUser
        {
            get { return _RecipientUser; }
            set { _RecipientUser = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DirectMessage()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public DirectMessage(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public DirectMessage(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.CreatedAt = element.CastElementToDateTimeOffset("created_at") ?? this.CreatedAt;
            this.ID = element.CastElementToString("id");
            this.SenderID = element.CastElementToString("sender_id");
            this.RecipientID = element.CastElementToString("recipient_id");
            this.Text = element.CastElementToString("text");
            this.SenderScreenName = element.CastElementToString("sender_screen_name");
            this.RecipientScreenName = element.CastElementToString("recipient_screen_name");

            this.SenderUser = new User(element.Element("sender"));
            this.RecipientUser = new User(element.Element("recipient"));
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.CreatedAt = d.ToDateTimeOffset("created_at") ?? this.CreatedAt;
            this.ID = d.ToString("id");
            this.SenderID = d.ToString("sender_id");
            this.RecipientID = d.ToString("recipient_id");
            this.Text = d.ToString("text");
            this.SenderScreenName = d.ToString("sender_screen_name");
            this.RecipientScreenName = d.ToString("recipient_screen_name");

            this.SenderUser = new User(d.ToString("sender"));
            this.RecipientUser = new User(d.ToString("recipient"));
        }
    }
}
