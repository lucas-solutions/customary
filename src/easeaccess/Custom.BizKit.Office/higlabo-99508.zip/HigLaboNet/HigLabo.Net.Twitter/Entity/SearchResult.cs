﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using Newtonsoft.Json.Linq;
using System.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class SearchResult : ResponseObject
    {
        private String _MaxID = "";
        private List<SearchStatus> _Statuses = new List<SearchStatus>();
        /// <summary>
        /// 
        /// </summary>
        public String MaxID
        {
            get { return _MaxID; }
            set { _MaxID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public ICollection<SearchStatus> Statuses
        {
            get { return _Statuses; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public SearchResult(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public SearchResult(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.MaxID = element.CastElementToString("max_id");
            
            foreach (var r in element.Descendants("results"))
            {
                _Statuses.Add(new SearchStatus(r));
            }
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            object objOut = null;

            d.TryGetValue("results", out objOut);
            JContainer val = (JContainer)objOut;
            for (int i = 0; i < val.Count(); i++)
            {
                _Statuses.Add(new SearchStatus(val.ElementAt(i).ToString()));
            }
        }
    }
}
