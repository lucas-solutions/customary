﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class Trend : ResponseObject
    {
        private String _Name = null;
        private String _Url = null;
        private String _Query = null;

        /// <summary>
        /// 
        /// </summary>
        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Url
        {
            get { return _Url; }
            set { _Url = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Query
        {
            get { return _Query; }
            set { _Query = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public Trend() { }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Trend(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Trend(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.Name = element.Value;
            this.Url = element.Attribute("url").Value;
            this.Query = element.Attribute("query").Value;
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.Name = d.ToString("name");
            this.Url = d.ToString("url");
            this.Query = d.ToString("query");
        }
    }
}
