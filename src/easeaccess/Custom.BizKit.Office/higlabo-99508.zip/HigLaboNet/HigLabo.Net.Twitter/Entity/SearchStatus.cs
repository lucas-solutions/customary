﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class SearchStatus : Status
    {
        private String _ToUserID = "";
        private String _FromUserID = "";
        private String _ToUserIDStr = "";
        private String _FromUserIDStr = "";
        private String _IsoLanguageCode = "";
        private SearchResultType _ResultType = SearchResultType.Mixed;
        private String _SinceID = "";
        private String _SinceIDStr = "";
        private String _MaxIDStr = "";
        private String _RefreshUrl = "";
        private String _NextPage = "";
        private Int32 _Page = 0;
        private Int32 _ResultPerPage = 0;
        private Double _CompletedIn = 0;
        private String _Query = "";
        /// <summary>
        /// 
        /// </summary>
        public String ToUserID
        {
            get { return _ToUserID; }
            set { _ToUserID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String FromUserID
        {
            get { return _FromUserID; }
            set { _FromUserID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ToUserIDStr
        {
            get { return _ToUserIDStr; }
            set { _ToUserIDStr = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String FromUserIDStr
        {
            get { return _FromUserIDStr; }
            set { _FromUserIDStr = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String IsoLanguageCode
        {
            get { return _IsoLanguageCode; }
            set { _IsoLanguageCode = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public SearchResultType ResultType
        {
            get { return _ResultType; }
            set { _ResultType = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String SinceID
        {
            get { return _SinceID; }
            set { _SinceID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String SinceIDStr
        {
            get { return _SinceIDStr; }
            set { _SinceIDStr = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String MaxIDStr
        {
            get { return _MaxIDStr; }
            set { _MaxIDStr = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String RefreshUrl
        {
            get { return _RefreshUrl; }
            set { _RefreshUrl = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String NextPage
        {
            get { return _NextPage; }
            set { _NextPage = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Page
        {
            get { return _Page; }
            set { _Page = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 ResultPerPage
        {
            get { return _ResultPerPage; }
            set { _ResultPerPage = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Double CompletedIn
        {
            get { return _CompletedIn; }
            set { _CompletedIn = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Query
        {
            get { return _Query; }
            set { _Query = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public SearchStatus()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public SearchStatus(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public SearchStatus(XElement element)
            : base(element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.ToUserID = element.CastElementToString("to_user_id");
            this.FromUserID = element.CastElementToString("from_user_id");
            this.ToUserIDStr = element.CastElementToString("to_user_id_str");
            this.FromUserIDStr = element.CastElementToString("from_user_id_str");
            this.IsoLanguageCode = element.CastElementToString("iso_language_code");

            XElement metadata = element.Element("metadata");
            if (metadata != null)
            {
                //WP7 does not support Enum.TryParse method.
                switch (metadata.CastElementToString("result_type").ToLower())
                {
                    case "mixed": this.ResultType = SearchResultType.Mixed; break;
                    case "recent": this.ResultType = SearchResultType.Recent; break;
                    case "popular": this.ResultType = SearchResultType.Popular; break;
                }
            }
            this.SinceID = element.CastElementToString("since_id");
            this.SinceIDStr = element.CastElementToString("since_id_str");
            this.MaxIDStr = element.CastElementToString("max_id_str");
            this.RefreshUrl = element.CastElementToString("refresh_url");
            this.NextPage = element.CastElementToString("next_page");
            this.Page = element.CastElementToInt32("page") ?? this.Page;
            this.ResultPerPage = element.CastElementToInt32("result_per_page") ?? this.ResultPerPage;
            this.CompletedIn = element.CastElementToInt32("completed_in") ?? this.CompletedIn;
            this.Query = element.CastElementToString("query");
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;            

            this.ToUserID = d.ToString("to_user_id");
            this.FromUserID = d.ToString("from_user_id");
            this.ToUserIDStr = d.ToString("to_user_id_str");
            this.FromUserIDStr = d.ToString("from_user_id_str");
            this.IsoLanguageCode = d.ToString("iso_language_code");                         
            
            Dictionary<String,Object> metadata = this.SetData(d.ToString("metadata"));
            
            if (metadata != null)
            {                
                switch (metadata.ToString("result_type"))
                {
                    case "mixed": this.ResultType = SearchResultType.Mixed; break;
                    case "recent": this.ResultType = SearchResultType.Recent; break;
                    case "popular": this.ResultType = SearchResultType.Popular; break;
                }
            }
            this.SinceID = d.ToString("since_id");
            this.SinceIDStr = d.ToString("since_id_str");
            this.MaxIDStr = d.ToString("max_id_str");
            this.RefreshUrl = d.ToString("refresh_url");
            this.NextPage = d.ToString("next_page");
            this.Page = d.ToInt32("page") ?? this.Page;
            this.ResultPerPage = d.ToInt32("result_per_page") ?? this.ResultPerPage;
            this.CompletedIn = d.ToInt32("completed_in") ?? this.CompletedIn;
            this.Query = d.ToString("query");
        }

    }
}
