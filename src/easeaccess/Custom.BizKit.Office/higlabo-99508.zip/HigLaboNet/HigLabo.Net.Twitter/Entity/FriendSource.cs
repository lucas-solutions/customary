﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class FriendSource : FriendTarget
    {
        private Boolean _AllReplies = false;
        private Boolean _Blocking = false;
        private Boolean _NotificationsEnabled = false;
        private Boolean _CanDirectMessage = false;
        private Boolean _WantRetweets = false;
        private Boolean _MarkedSpam = false;
        /// <summary>
        /// 
        /// </summary>
        public Boolean AllReplies
        {
            get { return _AllReplies; }
            set { _AllReplies = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean Blocking
        {
            get { return _Blocking; }
            set { _Blocking = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean NotificationsEnabled
        {
            get { return _NotificationsEnabled; }
            set { _NotificationsEnabled = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean CanDirectMessage
        {
            get { return _CanDirectMessage; }
            set { _CanDirectMessage = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean WantRetweets
        {
            get { return _WantRetweets; }
            set { _WantRetweets = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean MarkedSpam
        {
            get { return _MarkedSpam; }
            set { _MarkedSpam = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public FriendSource(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public FriendSource(XElement element)
            : base(element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.AllReplies = element.CastElementToBoolean("all_replies") ?? this.AllReplies;
            this.Blocking = element.CastElementToBoolean("blocking") ?? this.Blocking;
            this.NotificationsEnabled = element.CastElementToBoolean("notifications_enabled") ?? this.NotificationsEnabled;
            this.CanDirectMessage = element.CastElementToBoolean("can_dm") ?? this.CanDirectMessage;
            this.WantRetweets = element.CastElementToBoolean("want_retweets") ?? this.CanDirectMessage;
            this.MarkedSpam = element.CastElementToBoolean("marked_spam") ?? this.CanDirectMessage;
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.AllReplies = d.ToBoolean("all_replies") ?? this.AllReplies;
            this.Blocking = d.ToBoolean("blocking") ?? this.Blocking;
            this.NotificationsEnabled = d.ToBoolean("notifications_enabled") ?? this.NotificationsEnabled;
            this.CanDirectMessage = d.ToBoolean("can_dm") ?? this.CanDirectMessage;
            this.WantRetweets = d.ToBoolean("want_retweets") ?? this.CanDirectMessage;
            this.MarkedSpam = d.ToBoolean("marked_spam") ?? this.CanDirectMessage;
        }
    }
}
