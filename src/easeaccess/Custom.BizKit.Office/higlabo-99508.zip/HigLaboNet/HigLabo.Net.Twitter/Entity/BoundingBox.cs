﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using Newtonsoft.Json.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class BoundingBox : ResponseObject
    {
        private List<Coordinate> _Coordinates = new List<Coordinate>();
        private String _Type = "";
        /// <summary>
        /// 
        /// </summary>
        public ICollection<Coordinate> Coordinates
        {
            get { return _Coordinates; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Type
        {
            get { return _Type; }
            set { _Type = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public BoundingBox()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public BoundingBox(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public BoundingBox(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.Type = element.CastElementToString("type");
            var x = element.Element("coordinates");            

        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            object objOut = null;
            Double la = 0;
            Double lo = 0;

            this.Type = d.ToString("type");
            d.TryGetValue("coordinates", out objOut);
            JContainer val = (JContainer)objOut;            
            
            for (int i = 0; i < val.Count(); i++)
            {
                var v1 = val.ElementAt(i);
                for (int j = 0; j < v1.Count(); j++)
                {
                    var v2 = v1.ElementAt(j);
                    lo = Double.Parse(v2.ElementAt(0).ToString());
                    la = Double.Parse(v2.ElementAt(1).ToString());
                    this._Coordinates.Add(new Coordinate(la, lo));
                }                
            }
        }
    }
}
