﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using Newtonsoft.Json.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class Suggestion : ResponseObject
    {
        private String _Name = null;
        private String _Slug = null;
        private Int32 _Size = 0;
        private List<User> _Users = null;
        /// <summary>
        /// 
        /// </summary>
        public String Name
        {
            get { return this._Name; }
            set { this._Name = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Slug
        {
            get { return this._Slug; }
            set { this._Slug = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Size
        {
            get { return this._Size; }
            set { this._Size = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<User> Users
        {
            get { return this._Users; }
            set { this._Users = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Suggestion()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Suggestion(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Suggestion(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.Name = element.CastElementToString("name");
            this.Slug = element.CastElementToString("slug");
            this.Size = element.CastElementToInt32("size") ?? this.Size;
            this.Users = (from x in element.Descendants("user") select new User(x)).ToList();
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            object objOut = null;
            
            this.Name = d.ToString("name");
            this.Slug = d.ToString("slug");
            this.Size = d.ToInt32("size") ?? this.Size;
            
            d.TryGetValue("user", out objOut);
            JContainer val = (JContainer)objOut;
            for (int i = 0; i < val.Count(); i++)
            {
                Users.Add(new User(val.ElementAt(i).ToString()));
            }
        }
    }
}
