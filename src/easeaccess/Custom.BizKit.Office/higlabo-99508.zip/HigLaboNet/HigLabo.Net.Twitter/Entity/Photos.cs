﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class Photos : ResponseObject
    {
        private Int32 _RemainingHits = 0;
        private Int64 _ResetTimeInSeconds;
        private Int32 _DailyLimit = 0;
        private DateTimeOffset _ResetTime = DateTimeOffset.Now;
        /// <summary>
        /// 
        /// </summary>
        public Int32 RemainingHits
        {
            get { return _RemainingHits; }
            set { _RemainingHits = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int64 ResetTimeInSeconds
        {
            get { return _ResetTimeInSeconds; }
            set { _ResetTimeInSeconds = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 DailyLimit
        {
            get { return _DailyLimit; }
            set { _DailyLimit = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset ResetTime
        {
            get { return _ResetTime; }
            set { _ResetTime = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Photos()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Photos(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Photos(XElement element)
        {
            SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.RemainingHits = element.CastElementToInt32("remaining_hits") ?? this.RemainingHits;
            this.ResetTimeInSeconds = element.CastElementToInt64("reset_time_in_seconds") ?? this.ResetTimeInSeconds;
            this.DailyLimit = element.CastElementToInt32("hourly_limit") ?? this.DailyLimit;
            this.ResetTime = element.CastElementToDateTimeOffset("reset_time") ?? this.ResetTime;
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.RemainingHits = d.ToInt32("remaining_hits") ?? this.RemainingHits;
            this.ResetTimeInSeconds = d.ToInt64("reset_time_in_seconds") ?? this.ResetTimeInSeconds;
            this.DailyLimit = d.ToInt32("daily_limit") ?? this.DailyLimit;
            this.ResetTime = d.ToDateTimeOffset("reset_time") ?? this.ResetTime;
        }
    }
}
