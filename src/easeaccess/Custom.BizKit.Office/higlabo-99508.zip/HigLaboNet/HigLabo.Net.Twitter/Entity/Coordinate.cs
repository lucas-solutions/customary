﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class Coordinate : ResponseObject
    {
        private Double _Latitude = 0;
        private Double _Longitude = 0;
        /// <summary>
        /// 
        /// </summary>
        public Double Latitude
        {
            get { return _Latitude; }
            set { _Latitude = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Double Longitude
        {
            get { return _Longitude; }
            set { _Longitude = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Coordinate()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="latitude"></param>
        /// <param name="longitude"></param>
        public Coordinate(Double latitude, Double longitude)
        {
            _Latitude = latitude;
            _Longitude = longitude;
        }
    }
}
