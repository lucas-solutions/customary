﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class FriendTarget : ResponseObject
    {
        private String _ScreenName = "";
        private Boolean _FollowedBy = false;
        private Boolean _Following = false;
        private String _IDStr = "";
        private Int64 _ID = 0;
        /// <summary>
        /// 
        /// </summary>
        public String ScreenName
        {
            get { return _ScreenName; }
            set { _ScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean FollowedBy
        {
            get { return _FollowedBy; }
            set { _FollowedBy = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean Following
        {
            get { return _Following; }
            set { _Following = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String IDStr
        {
            get { return _IDStr; }
            set { _IDStr = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int64 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public FriendTarget()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public FriendTarget(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public FriendTarget(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.ScreenName = element.CastElementToString("screen_name");
            this.FollowedBy = element.CastElementToBoolean("followed_by") ?? this.FollowedBy;
            this.Following = element.CastElementToBoolean("following") ?? this.Following;
            this.ID = element.CastElementToInt64("id") ?? this.ID;
            this.IDStr = element.CastElementToString("id_str");
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.ScreenName = d.ToString("screen_name");
            this.FollowedBy = d.ToBoolean("followed_by") ?? this.FollowedBy;
            this.Following = d.ToBoolean("following") ?? this.Following;
            this.ID = d.ToInt64("id") ?? this.ID;
            this.IDStr = d.ToString("id_str");
        }
    }
}
