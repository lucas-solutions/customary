﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class Entities : ResponseObject
    {
        private List<Place> _Places = new List<Place>();
        private List<UserMention> _UserMentions = new List<UserMention>();
        private List<Url> _Urls = new List<Url>();
        private List<HashTag> _HashTags = new List<HashTag>();
        /// <summary>
        /// 
        /// </summary>
        public List<Place> Places
        {
            get { return _Places; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<UserMention> UserMentions
        {
            get { return _UserMentions; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<Url> Urls
        {
            get { return _Urls; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<HashTag> HashTags
        {
            get { return _HashTags; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Entities(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Entities(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            foreach (var r in element.Descendants("places"))
            {
                _Places.Add(new Place(r));
            }
            foreach (var r in element.Descendants("user_mention"))
            {
                _UserMentions.Add(new UserMention(r));
            }
            foreach (var r in element.Descendants("urls").FirstOrDefault().Elements("url"))
            {
                _Urls.Add(new Url(r));
            }
            foreach (var r in element.Descendants("hashtag"))
            {
                _HashTags.Add(new HashTag(r));
            }
        }
        private void SetProperty(Dictionary<String, Object> data)
        {

            var d = data;
            object objOut = null;                        
            
            d.TryGetValue("urls", out objOut);
            JContainer val = (JContainer)objOut;
            for (int i = 0; i < val.Count(); i++)
            {
                _Urls.Add(new Url(val.ElementAt(i).ToString()));
            }

            d.TryGetValue("hashtags", out objOut);
            val = (JContainer)objOut;
            for (int i = 0; i < val.Count(); i++)
            {
                _HashTags.Add(new HashTag(val.ElementAt(i).ToString()));
            }

            d.TryGetValue("user_mentions", out objOut);
            val = (JContainer)objOut;
            for (int i = 0; i < val.Count(); i++)
            {
                _UserMentions.Add(new UserMention(val.ElementAt(i).ToString()));
            }

            d.TryGetValue("places", out objOut);
            if (objOut != null)
            {
                val = (JContainer)objOut;
                for (int i = 0; i < val.Count(); i++)
                {
                    _Places.Add(new Place(val.ElementAt(i).ToString()));
                }           
            }            
        }
    }
}
