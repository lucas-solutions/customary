﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using Newtonsoft.Json.Linq;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class List : ResponseObject
    {
        private String _Slug = null;
        private String _Name = null;
        private String _Uri = null;
        private Int32 _SubscriberCount = 0;
        private String _IDStr = null;
        private Int32 _MemberCount = 0;
        private String _Mode = null;
        private Int64 _ID = 0;
        private String _FullName = null;
        private String _Description = null;
        private List<User> _Users = new List<User>();
        /// <summary>
        /// 
        /// </summary>
        public String Slug
        {
            get { return this._Slug; }
            set { this._Slug = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Name
        {
            get { return this._Name; }
            set { this._Name = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Uri
        {
            get { return _Uri; }
            set { _Uri = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 SubscriberCount
        {
            get { return _SubscriberCount; }
            set { _SubscriberCount = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String IdStr
        {
            get { return _IDStr; }
            set { _IDStr = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 MemberCount
        {
            get { return _MemberCount; }
            set { _MemberCount = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Mode
        {
            get { return _Mode; }
            set { _Mode = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int64 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String FullName
        {
            get { return _FullName; }
            set { _FullName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Description
        {
            get { return _Description; }
            set { _Description = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<User> Users
        {
            get { return this._Users; }
            set { this._Users = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public List(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public List(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.Slug = element.CastElementToString("slug");
            this.Name = element.CastElementToString("name");
            this.Uri = element.CastElementToString("uri");
            this.SubscriberCount = element.CastElementToInt32("subscriber_count") ?? this.SubscriberCount;
            this.IdStr = element.CastElementToString("id_str");
            this.MemberCount = element.CastElementToInt32("member_count") ?? this.MemberCount;
            this.Mode = element.CastElementToString("mode");
            this.ID = element.CastElementToInt64("id") ?? this.ID;
            this.FullName = element.CastElementToString("full_name");
            this.Description = element.CastElementToString("description");

            this.Users = (from x in element.Descendants("user") select new User(x)).ToList();
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;            

            this.Slug = d.ToString("slug");
            this.Name = d.ToString("name");
            this.Uri = d.ToString("uri");
            this.SubscriberCount = d.ToInt32("subscriber_count") ?? this.SubscriberCount;
            this.IdStr = d.ToString("id_str");
            this.MemberCount = d.ToInt32("member_count") ?? this.MemberCount;
            this.Mode = d.ToString("mode");
            this.ID = d.ToInt64("id") ?? this.ID;
            this.FullName = d.ToString("full_name");
            this.Description = d.ToString("description");
            var u = new User(d.ToString("user"));
            this._Users.Add(u);
           
            //d.TryGetValue("user", out objOut);
            
            //JContainer val = (JContainer)objOut;
            //for (int i = 0; i < val.Count(); i++)
            //{
            //    _Users.Add(new User(val.ElementAt(i).ToString()));
            //}                      
        }

    }
}
