﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class TimeZone : ResponseObject
    {
        private String _Name = null;
        private String _TzinfoName = null;
        private Int32 _UtcOffset = 0;

        /// <summary>
        /// 
        /// </summary>
        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String TzinfoName
        {
            get { return _TzinfoName; }
            set { _TzinfoName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 UtcOffset
        {
            get { return _UtcOffset; }
            set { _UtcOffset = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public TimeZone() { }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public TimeZone(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public TimeZone(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.Name = element.CastElementToString("name");
            this.TzinfoName = element.CastElementToString("tzinfo_name");
            this.UtcOffset = element.CastElementToInt32("utc_offset") ?? this.UtcOffset;
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.Name = d.ToString("name");
            this.TzinfoName = d.ToString("tzinfo_name");
            this.UtcOffset = d.ToInt32("utc_offset") ?? this.UtcOffset;
        }
    }
}
