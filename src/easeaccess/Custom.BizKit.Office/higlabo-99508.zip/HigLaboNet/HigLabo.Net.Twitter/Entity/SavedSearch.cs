﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class SavedSearch : ResponseObject
    {
        private String _Name = null;
        private String _Postion = null;
        private DateTimeOffset _CreatedAt = DateTimeOffset.Now;
        private Int64 _ID = 0;
        private String _Query = null;

        /// <summary>
        /// 
        /// </summary>
        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Postion
        {
            get { return _Postion; }
            set { _Postion = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset CreatedAt
        {
            get { return _CreatedAt; }
            set { _CreatedAt = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int64 ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Query
        {
            get { return _Query; }
            set { _Query = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        public SavedSearch() { }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public SavedSearch(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public SavedSearch(XElement element)
        {
            SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.Name = element.CastElementToString("name");
            this.Postion = element.CastElementToString("position");
            this.CreatedAt = element.CastElementToDateTimeOffset("created_at") ?? this.CreatedAt;
            this.ID = element.CastElementToInt64("id") ?? this.ID;
            this.Query = element.CastElementToString("query");
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.Name = d.ToString("name");
            this.Postion = d.ToString("position");
            this.CreatedAt = d.ToDateTimeOffset("created_at") ?? this.CreatedAt;
            this.ID = d.ToInt64("id") ?? this.ID;
            this.Query = d.ToString("query");
        }
    }
}
