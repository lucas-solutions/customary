﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GeoCode : ResponseObject
    {
        private Double _Latitude = 0;
        private Double _Longitude = 0;
        private String _Radius = "";
        /// <summary>
        /// 
        /// </summary>
        public Double Latitude
        {
            get { return _Latitude; }
            set { _Latitude = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Double Longitude
        {
            get { return _Longitude; }
            set { _Longitude = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Radius
        {
            get { return _Radius; }
            set { _Radius = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public GeoCode()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="latitude"></param>
        /// <param name="longitude"></param>
        /// <param name="radius"></param>
        public GeoCode(Double latitude, Double longitude, String radius)
        {
            _Latitude = latitude;
            _Longitude = longitude;
            _Radius = radius;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return String.Format("{0},{1},{2}", this.Latitude, this.Longitude, this.Radius);
        }
    }
}
