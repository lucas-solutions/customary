﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class HashTag : ResponseObject
    {
        private Int32 _Start = 0;
        private Int32 _End = 0;
        private String _Text = "";
        /// <summary>
        /// 
        /// </summary>
        public Int32 Start
        {
            get { return _Start; }
            set { _Start = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 End
        {
            get { return _End; }
            set { _End = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Text
        {
            get { return _Text; }
            set { _Text = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public HashTag(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public HashTag(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(string jsonText)
        {
            var d = this.SetData(jsonText);
            this.SetProperty(d);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public override void SetProperty(XElement element)
        {
            this.SetElements(element);
            this.Start = Int32.Parse(element.Attribute("start").Value);
            this.End = Int32.Parse(element.Attribute("end").Value);
            this.Text = element.CastElementToString("text");
        }
        private void SetProperty(Dictionary<String, Object> data)
        {
            var d = data;
            this.Start = d.ToInt32("start")??this.Start;
            this.End = d.ToInt32("end")?? this.End;            
            this.Text = d.ToString("text");
        }
    }
}
