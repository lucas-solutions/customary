﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetTrendsCommand : TwitterCommand
    {
        private Int32 _WoeID = 0;
        /// <summary>
        /// 
        /// </summary>
        public Int32 WoeID
        {
            get { return this._WoeID; }
            set { this._WoeID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<String, String> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["woeid"] = this.WoeID.ToString();

            return d;
        }
    }
}
