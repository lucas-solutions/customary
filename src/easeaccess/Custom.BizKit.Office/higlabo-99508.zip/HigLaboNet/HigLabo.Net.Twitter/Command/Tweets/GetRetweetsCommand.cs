﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetRetweetsCommand : TwitterCommand
    {
        private static Int32 MaxCount = 100;
        private Int32 _Count = 20;
        private String _ID = "";
        private Boolean _TrimUser = true;
        private Boolean _IncludeEntities = false;
        /// <summary>
        /// 
        /// </summary>
        public Int32 Count
        {
            get { return _Count; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException();
                }
                if (value > MaxCount)
                {
                    _Count = MaxCount;
                }
                _Count = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ID
        {
            get { return _ID; }
            set { _ID= value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean TrimUser
        {
            get { return _TrimUser; }
            set { _TrimUser = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["count"] = this.Count.ToString();
            d["id"] = this.ID;
            d["trim_user"] = this.TrimUser.ToString().ToLower();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            return d;
        }
    }
}
