﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateStatusCommand : TwitterCommand
    {
        private String _Status = "";
        private String _InReplyToStatusID = "";
        private Double? _Latitude = null;
        private Double? _Longitude = null;
        private String _PlaceID = "";
        private Boolean _DisplayCoordinates = true;
        private Boolean _TrimUser = true;
        private Boolean _IncludeEntities = false;
        /// <summary>
        /// 
        /// </summary>
        public String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String InReplyToStatusID
        {
            get { return _InReplyToStatusID; }
            set { _InReplyToStatusID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Double? Latitude
        {
            get { return _Latitude; }
            set { _Latitude = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Double? Longitude
        {
            get { return _Longitude; }
            set { _Longitude = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String PlaceID
        {
            get { return _PlaceID; }
            set { _PlaceID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean DisplayCoordinates
        {
            get { return _DisplayCoordinates; }
            set { _DisplayCoordinates = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean TrimUser
        {
            get { return _TrimUser; }
            set { _TrimUser = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["status"] = this.Status.ToString();
            d["in_reply_to_status_id"] = this.InReplyToStatusID.ToString();
            d["lat"] = this.Latitude.ToString();
            d["long"] = this.Longitude.ToString();
            d["place_id"] = this.PlaceID;
            d["display_coordinates"] = this.DisplayCoordinates.ToString().ToLower();
            d["trim_user"] = this.TrimUser.ToString().ToLower();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            return d;
        }
    }
}
