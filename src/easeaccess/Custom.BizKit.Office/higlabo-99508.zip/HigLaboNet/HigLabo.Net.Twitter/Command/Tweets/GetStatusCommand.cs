﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetStatusCommand : TwitterCommand
    {
        private String _ID = "";
        private Boolean _TrimUser = true;
        private Boolean _IncludeEntities = false;
        /// <summary>
        /// 
        /// </summary>
        public String ID
        {
            get { return _ID; }
            set { _ID= value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean TrimUser
        {
            get { return _TrimUser; }
            set { _TrimUser = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["id"] = this.ID;
            d["trim_user"] = this.TrimUser.ToString().ToLower();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            return d;
        }
    }
}
