﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetUserRetweetByCommand : TwitterCommand
    {
        private static readonly Int32 MaxCount = 100;
        private Int32 _Count = 20;
        private String _ID = "";
        private Int32 _Page = 1;
        /// <summary>
        /// 
        /// </summary>
        public Int32 Count
        {
            get { return _Count; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException();
                }
                if (value > MaxCount)
                {
                    _Count = MaxCount;
                }
                _Count = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ID
        {
            get { return _ID; }
            set { _ID= value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Page
        {
            get { return _Page; }
            set { _Page = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["count"] = this.Count.ToString();
            d["id"] = this.ID;
            d["page"] = this.Page.ToString();
            return d;
        }
    }
}
