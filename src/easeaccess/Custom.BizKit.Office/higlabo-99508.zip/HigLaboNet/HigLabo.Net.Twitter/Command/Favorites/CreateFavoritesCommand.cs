﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class CreateFavoritesCommand : TwitterCommand
    {
        private Int64 _ID = 0;
        private Boolean _IncludeEntities = false;
        /// <summary>
        /// 
        /// </summary>
        public Int64 ID
        {
            get { return this._ID; }
            set { this._ID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return this._IncludeEntities; }
            set { this._IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["id"] = this.ID.ToString();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            return d;
        }
    }
}
