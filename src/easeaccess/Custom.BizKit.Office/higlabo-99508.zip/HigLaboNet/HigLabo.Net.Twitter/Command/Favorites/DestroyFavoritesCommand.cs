﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class DestroyFavoritesCommand : TwitterCommand
    {
        private Int64 _ID = 0;
        /// <summary>
        /// 
        /// </summary>
        public Int64 ID
        {
            get { return this._ID; }
            set { this._ID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["id"] = this.ID.ToString();
            return d;
        }
    }
}
