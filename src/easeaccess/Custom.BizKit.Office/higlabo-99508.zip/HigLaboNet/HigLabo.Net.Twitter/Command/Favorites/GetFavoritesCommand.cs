﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetFavoritesCommand:TwitterCommand
    {
        private Int64 _ID = 0;
        private Int32 _Page = 0;
        private Boolean _IncludeEntities = false;
        /// <summary>
        /// 
        /// </summary>
        public Int64 ID
        {
            get { return this._ID; }
            set { this._ID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Page
        {
            get { return this._Page; }
            set { this._Page = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return this._IncludeEntities; }
            set { this._IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["id"] = this.ID.ToString();
            d["page"] = this.Page.ToString();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower(); ;
            return d;
        }

    }
}
