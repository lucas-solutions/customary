﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetTimelineCommand : TwitterCommand
    {
        private static readonly Int32 MaxCount = 200;
        private Int32 _Count = 20;
        private String _SinceID = "";
        private String _MaxID = "";
        private Int32 _Page = 1;
        private Boolean _TrimUser = true;
        private Boolean _IncludeRetweet = false;
        private Boolean _IncludeEntities = false;
        private Boolean _ContributorDetails = false;
        /// <summary>
        /// 
        /// </summary>
        public Int32 Count
        {
            get { return _Count; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException();
                }
                if (value > MaxCount)
                {
                    _Count = MaxCount;
                }
                _Count = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public String SinceID
        {
            get { return _SinceID; }
            set { _SinceID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String MaxID
        {
            get { return _MaxID; }
            set { _MaxID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Page
        {
            get { return _Page; }
            set { _Page = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean TrimUser
        {
            get { return _TrimUser; }
            set { _TrimUser = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeRetweet
        {
            get { return _IncludeRetweet; }
            set { _IncludeRetweet = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean ContributorDetails
        {
            get { return _ContributorDetails; }
            set { _ContributorDetails = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public GetTimelineCommand()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["count"] = this.Count.ToString();
            d["since_id"] = this.SinceID;
            d["max_id"] = this.MaxID;
            d["page"] = this.Page.ToString();
            d["trim_user"] = this.TrimUser.ToString().ToLower();
            d["include_rts"] = this.IncludeRetweet.ToString().ToLower();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            d["contributor_details"] = this.ContributorDetails.ToString().ToLower();
            return d;
        }
    }
}
