﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetHomeTimelineCommand : GetTimelineCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public GetHomeTimelineCommand()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["count"] = this.Count.ToString();
            d["since_id"] = this.SinceID;
            d["max_id"] = this.MaxID;
            d["page"] = this.Page.ToString();
            d["trim_user"] = this.TrimUser.ToString().ToLower();
            d["include_rts"] = this.IncludeRetweet.ToString().ToLower();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            d["contributor_details"] = this.ContributorDetails.ToString().ToLower();
            return d;
        }
    }
}
