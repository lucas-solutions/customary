﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetTimelineRetweetUserCommand : TwitterCommand
    {
        private static readonly Int32 MaxCount = 100;
        private String _ScreenName = "";
        private Int32 _Count = 20;
        private String _SinceID = "";
        private String _MaxID = "";
        private Int32 _Page = 1;
        private Boolean _TrimUser = true;
        private Boolean _IncludeEntities = false;
        /// <summary>
        /// 
        /// </summary>
        public String ScreenName
        {
            get { return _ScreenName; }
            set { _ScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Count
        {
            get { return _Count; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException();
                }
                if (value > MaxCount)
                {
                    _Count = MaxCount;
                }
                _Count = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public String SinceID
        {
            get { return _SinceID; }
            set { _SinceID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String MaxID
        {
            get { return _MaxID; }
            set { _MaxID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Page
        {
            get { return _Page; }
            set { _Page = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean TrimUser
        {
            get { return _TrimUser; }
            set { _TrimUser = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// /</summary>
        public GetTimelineRetweetUserCommand()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["count"] = this.Count.ToString();
            d["since_id"] = this.SinceID;
            d["max_id"] = this.MaxID;
            d["page"] = this.Page.ToString();
            d["trim_user"] = this.TrimUser.ToString().ToLower();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            return d;
        }
    }
}
