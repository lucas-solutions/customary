﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetUserTimelineCommand : GetTimelineCommand
    {
        private String _UserID = "";
        private String _ScreenName = "";
        private Boolean _ExcludeReplies = false;
        /// <summary>
        /// 
        /// </summary>
        public String UserID
        {
            get { return _UserID; }
            set { _UserID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ScreenName
        {
            get { return _ScreenName; }
            set { _ScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean ExcludeReplies
        {
            get { return _ExcludeReplies; }
            set { _ExcludeReplies = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public GetUserTimelineCommand()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["user_id"] = this.UserID.ToString();
            d["screen_name"] = this.ScreenName.ToString();
            d["count"] = this.Count.ToString();
            d["since_id"] = this.SinceID;
            d["max_id"] = this.MaxID;
            d["page"] = this.Page.ToString();
            d["trim_user"] = this.TrimUser.ToString().ToLower();
            d["include_rts"] = this.IncludeRetweet.ToString().ToLower();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            d["exclude_replies"] = this.ExcludeReplies.ToString().ToLower();
            d["contributor_details"] = this.ContributorDetails.ToString().ToLower();
            return d;
        }
    }
}
