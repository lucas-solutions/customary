﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class LookupFriendshipsCommand : TwitterCommand
    {
        private String _UserID = "";
        private String _ScreenName = "";
        /// <summary>
        /// 
        /// </summary>
        public String ScreenName
        {
            get { return _ScreenName; }
            set { _ScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String UserID
        {
            get { return _UserID; }
            set { _UserID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["screen_name"] = this.ScreenName;
            d["user_id"] = this.UserID;
            return d;
        }
    }
}
