﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class ShowFriendshipsCommand : TwitterCommand
    {
        private Int64 _SourceID = 0;
        private Int64 _TargetID = 0;
        private String _SourceScreenName = "";
        private String _TargetScreenName = "";
        /// <summary>
        /// 
        /// </summary>
        public Int64 SourceID
        {
            get { return _SourceID; }
            set { _SourceID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int64 TargetID
        {
            get { return _TargetID; }
            set { _TargetID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String SourceScreenName
        {
            get { return _SourceScreenName; }
            set { _SourceScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String TargetScreenName
        {
            get { return _TargetScreenName; }
            set { _TargetScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["source_id"] = this.SourceID.ToString();
            d["target_id"] = this.TargetID.ToString();
            d["source_screen_name"] = this.SourceScreenName;
            d["target_screen_name"] = this.TargetScreenName;
            return d;
        }
    }
}
