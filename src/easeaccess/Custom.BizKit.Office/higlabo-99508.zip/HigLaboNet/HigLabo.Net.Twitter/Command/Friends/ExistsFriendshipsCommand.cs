﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class ExistsFriendshipsCommand : TwitterCommand
    {
        private Int64 _UserID_A = 0;
        private Int64 _UserID_B = 0;
        private String _ScreenName_A = "";
        private String _ScreenName_B = "";
        /// <summary>
        /// 
        /// </summary>
        public Int64 UserID_A
        {
            get { return _UserID_A; }
            set { _UserID_A = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int64 UserID_B
        {
            get { return _UserID_B; }
            set { _UserID_B = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ScreenName_A
        {
            get { return _ScreenName_A; }
            set { _ScreenName_A = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ScreenName_B
        {
            get { return _ScreenName_B; }
            set { _ScreenName_B = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["user_id_a"] = this.UserID_A.ToString();
            d["user_id_b"] = this.UserID_B.ToString();
            d["screen_name_a"] = this.ScreenName_A;
            d["screen_name_b"] = this.ScreenName_B;
            return d;
        }
    }
}
