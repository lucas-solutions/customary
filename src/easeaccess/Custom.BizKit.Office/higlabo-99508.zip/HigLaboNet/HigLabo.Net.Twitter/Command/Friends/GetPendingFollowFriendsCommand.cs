﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetPendingFollowFriendsCommand : TwitterCommand
    {
        private String _Cursor = "";
        private String _StringifyIDs = "";
        /// <summary>
        /// 
        /// </summary>
        public String Cursor
        {
            get { return _Cursor; }
            set { _Cursor = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String StringifyIDs
        {
            get { return _StringifyIDs; }
            set { _StringifyIDs = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["cursor"] = this.Cursor;
            d["stringify_ids"] = this.StringifyIDs;
            return d;
        }
    }
}
