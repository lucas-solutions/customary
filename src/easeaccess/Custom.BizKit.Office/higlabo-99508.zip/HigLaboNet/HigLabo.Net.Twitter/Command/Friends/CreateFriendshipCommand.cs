﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class CreateFriendshipCommand : TwitterCommand
    {
        private Int64 _UserID = 0;
        private String _ScreenName = "";
        private Boolean _Follow = false;
        /// <summary>
        /// 
        /// </summary>
        public String ScreenName
        {
            get { return _ScreenName; }
            set { _ScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int64 UserID
        {
            get { return _UserID; }
            set { _UserID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean Follow
        {
            get { return _Follow; }
            set { _Follow = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["screen_name"] = this.ScreenName;
            d["user_id"] = this.UserID.ToString();
            d["follow"] = this.Follow.ToString().ToLower();
            return d;
        }
    }
}
