﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateProfileCommand : TwitterCommand
    {
        private String _Name = null;
        private String _Url = null;
        private String _Location = null;
        private String _Description = null;
        private Boolean _IncludeEntities = false;
        private Boolean _SkipStatus = false;
        /// <summary>
        /// 
        /// </summary>
        public String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Url
        {
            get { return _Url; }
            set { _Url = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Location
        {
            get { return _Location; }
            set { _Location = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Description
        {
            get { return _Description; }
            set { _Description = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean SkipStatus
        {
            get { return _SkipStatus; }
            set { _SkipStatus = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<String, String> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["name"] = this.Name;
            d["url"] = this.Url;
            d["location"] = this.Location;
            d["description"] = this.Description;
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            d["skip_status"] = this.SkipStatus.ToString().ToLower();
            return d;
        }
    }
}
