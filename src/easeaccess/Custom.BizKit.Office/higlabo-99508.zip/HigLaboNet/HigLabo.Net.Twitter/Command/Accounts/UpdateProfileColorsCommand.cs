﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateProfileColorsCommand : TwitterCommand
    {
        private String _Color = null;
        private String _LinkColor = null;
        private String _SidebarBorderColor = null;
        private String _SidebarFillColor = null;
        private String _TextColor = null;
        private Boolean _IncludeEntities = false;
        private Boolean _SkipStatus = false;

        /// <summary>
        /// 
        /// </summary>
        public String Color
        {
            get { return _Color; }
            set { _Color = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String LinkColor
        {
            get { return _LinkColor; }
            set { _LinkColor = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String SidebarBorderColor
        {
            get { return _SidebarBorderColor; }
            set { _SidebarBorderColor = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String SidebarFillColor
        {
            get { return _SidebarFillColor; }
            set { _SidebarFillColor = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String TextColor
        {
            get { return _TextColor; }
            set { _TextColor = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean SkipStatus
        {
            get { return _SkipStatus; }
            set { _SkipStatus = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<String, String> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["profile_background_color"] = this.Color;
            d["profile_link_color"] = this.LinkColor;
            d["profile_sidebar_border_color"] = this.SidebarBorderColor;
            d["profile_sidebar_fill_color"] = this.SidebarFillColor;
            d["profile_text_color"] = this.TextColor;
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            d["skip_status"] = this.SkipStatus.ToString().ToLower();
            return d;
        }
    }
}
