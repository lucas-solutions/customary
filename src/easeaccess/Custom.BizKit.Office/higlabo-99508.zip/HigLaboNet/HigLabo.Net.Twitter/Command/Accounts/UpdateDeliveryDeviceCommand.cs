﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateDeliveryDeviceCommand : TwitterCommand
    {
        private String _Device = null;
        private Boolean _IncludeEntities = false;

        /// <summary>
        /// 
        /// </summary>
        public String Device
        {
            get { return _Device; }
            set { _Device = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["device"] = this.Device;
            d["include_entites"] = this.IncludeEntities.ToString().ToLower();
            return d;
        }
    }
}
