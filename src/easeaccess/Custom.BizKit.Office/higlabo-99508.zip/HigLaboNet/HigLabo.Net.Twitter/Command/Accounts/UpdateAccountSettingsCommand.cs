﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateAccountSettingsCommand : TwitterCommand
    {
        private Int32 _TrendLocationWoeID = 0;
        private Boolean _SleepTimeEnabled = false;
        private Int32 _StartSleepTime = 0;
        private Int32 _EndSleepTime = 0;
        private String _TimeZone = null;
        private String _Lang = null;
        /// <summary>
        /// 
        /// </summary>
        public int TrendLocationWoeId
        {
            get { return _TrendLocationWoeID; }
            set { _TrendLocationWoeID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public bool SleepTimeEnabled
        {
            get { return _SleepTimeEnabled; }
            set { _SleepTimeEnabled = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 StartSleepTime
        {
            get { return _StartSleepTime; }
            set { _StartSleepTime = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 EndSleepTime
        {
            get { return _EndSleepTime; }
            set { _EndSleepTime = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string TimeZone
        {
            get { return _TimeZone; }
            set { _TimeZone = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string Lang
        {
            get { return _Lang; }
            set { _Lang = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["trend_location_woeid"] = this.TrendLocationWoeId.ToString();
            d["sleep_time_enabled"] = this.SleepTimeEnabled.ToString().ToLower();
            d["start_sleep_time"] = this.StartSleepTime.ToString();
            d["end_sleep_time"] = this.EndSleepTime.ToString();
            d["time_zone"] = this.TimeZone;
            d["lang"] = this.Lang;
            return d;
        }
    }
}
