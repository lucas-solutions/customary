﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateProfileBackgroundImageCommand : TwitterCommand
    {
        private String _Image;
        private Boolean _Tile = false;
        private Boolean _IncludeEntities = false;
        private Boolean _SkipStatus = false;
        private Boolean _Use = false;
        /// <summary>
        /// 
        /// </summary>
        public String Image
        {
            get { return _Image; }
            set { _Image = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean Tile
        {
            get { return _Tile; }
            set { _Tile = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean SkipStatus
        {
            get { return _SkipStatus; }
            set { _SkipStatus = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean Use
        {
            get { return _Use; }
            set { _Use = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<String, String> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["image"] = this.Image;
            d["title"] = this.Tile.ToString().ToLower();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            d["skip_status"] = this.SkipStatus.ToString().ToLower();
            d["use"] = this.Use.ToString().ToLower();

            return d;
        }
    }
}
