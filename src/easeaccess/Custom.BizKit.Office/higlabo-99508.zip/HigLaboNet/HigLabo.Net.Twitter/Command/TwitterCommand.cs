﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public abstract class TwitterCommand
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IDictionary<String, String> GetParameters()
        {
            var d = this.CreateParameters();
            this.RemoveEmptyEntry(d);
            return d;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        private void RemoveEmptyEntry(IDictionary<String, String> data)
        {
            List<String> keys = new List<string>();
            foreach (var key in data.Keys)
            {
                if (String.IsNullOrEmpty(data[key]) == true)
                {
                    keys.Add(key);
                }
            }
            for (int i = 0; i < keys.Count; i++)
            {
                data.Remove(keys[i]);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected abstract IDictionary<String, String> CreateParameters();
    }
}
