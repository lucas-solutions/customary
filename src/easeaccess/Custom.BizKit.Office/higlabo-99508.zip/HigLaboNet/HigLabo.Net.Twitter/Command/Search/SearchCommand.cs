﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class SearchCommand : TwitterCommand
    {
        private static readonly Int32 MaxRetweetCount = 100;
        private String _Query = "";
        private String _Callback = "";
        private GeoCode _GeoCode = null;
        private String _Language = "";
        private String _Locale = "";
        private Int32? _Page = null;
        private SearchResultType _ResultType = SearchResultType.Mixed;
        private Int32? _RetweetCount = null;
        private Boolean _ShowUser = false;
        private DateTime? _UntilDate = null;
        private String _SinceID = "";
        /// <summary>
        /// 
        /// </summary>
        public String Query
        {
            get { return _Query; }
            set { _Query = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Callback
        {
            get { return _Callback; }
            set { _Callback = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public GeoCode GeoCode
        {
            get { return _GeoCode; }
            set { _GeoCode = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Language
        {
            get { return _Language; }
            set { _Language = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Locale
        {
            get { return _Locale; }
            set { _Locale = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32? Page
        {
            get { return _Page; }
            set { _Page = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public SearchResultType ResultType
        {
            get { return _ResultType; }
            set { _ResultType = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32? RetweetCount
        {
            get { return _RetweetCount; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException();
                }
                if (value > MaxRetweetCount)
                {
                    _RetweetCount = MaxRetweetCount;
                }
                _RetweetCount = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean ShowUser
        {
            get { return _ShowUser; }
            set { _ShowUser = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? UntilDate
        {
            get { return _UntilDate; }
            set { _UntilDate = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String SinceID
        {
            get { return _SinceID; }
            set { _SinceID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["q"] = this.Query;
            d["callback"] = this.Callback;
            if (this.GeoCode != null)
            {
                d["geocode"] = this.GeoCode.ToString();
            }
            d["lang"] = this.Language;
            d["locale"] = this.Locale;
            d["page"] = this.Page.ToString();
            d["result_type"] = this.ResultType.ToString().ToLower();
            d["rpp"] = this.RetweetCount.ToString();
            d["show_user"] = this.ShowUser.ToString().ToLower();
            if (this.UntilDate.HasValue == true)
            {
                d["until"] = this.UntilDate.Value.ToString("yyyy-MM-dd");
            }
            d["since_id"] = this.SinceID;
            return d;
        }
    }
}
