﻿namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public enum SearchResultType
    {
        /// <summary>
        /// 
        /// </summary>
        Mixed, 
        /// <summary>
        /// 
        /// </summary>
        Recent,
        /// <summary>
        /// 
        /// </summary>
        Popular,
    }
}
