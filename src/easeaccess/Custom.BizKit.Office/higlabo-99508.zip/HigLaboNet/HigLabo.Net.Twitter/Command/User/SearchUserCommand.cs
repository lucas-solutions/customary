﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class SearchUserCommand : TwitterCommand
    {
        private String _Query = "";
        private Int32? _Page = null;
        private Int32? _PerPage = null;
        private Boolean _IncludeEntities = false;
        /// <summary>
        /// 
        /// </summary>
        public String Query
        {
            get { return _Query; }
            set { _Query = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32? Page
        {
            get { return _Page; }
            set { _Page = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32? PerPage
        {
            get { return _PerPage; }
            set { _PerPage = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["q"] = this.Query;
            d["page"] = this.Page.ToString();
            d["per_page"] = this.PerPage.ToString();
            d["include_entities"] = this.IncludeEntities.ToString();
            return d;
        }
    }
}
