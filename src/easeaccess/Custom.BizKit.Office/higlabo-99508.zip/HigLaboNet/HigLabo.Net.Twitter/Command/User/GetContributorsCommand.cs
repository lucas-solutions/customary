﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetContributorsCommand : TwitterCommand
    {
        private Int64 _UserID = 0;
        private String _ScreenName = "";
        private Boolean _IncludeEntities = false;
        private Boolean _SkipStatus = false;
        /// <summary>
        /// 
        /// </summary>
        public Int64 UserID
        {
            get { return _UserID; }
            set { _UserID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ScreenName
        {
            get { return _ScreenName; }
            set { _ScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean SkipStatus
        {
            get { return _SkipStatus; }
            set { _SkipStatus = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["user_id"] = this.UserID.ToString();
            d["screen_name"] = this.ScreenName;
            d["include_entities"] = this.IncludeEntities.ToString();
            d["skip_status"] = this.SkipStatus.ToString();
            return d;
        }
    }
}
