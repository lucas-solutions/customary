﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetDirectMessageListSentCommand : TwitterCommand
    {
        private static readonly Int32 MaxCount = 200;
        private Int32 _Count = 20;
        private String _SinceID = "";
        private String _MaxID = "";
        private Int32 _Page = 1;
        private Boolean _IncludeEntities = false;
        /// <summary>
        /// 
        /// </summary>
        public Int32 Count
        {
            get { return _Count; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentException();
                }
                if (value > MaxCount)
                {
                    _Count = MaxCount;
                }
                _Count = value;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public String SinceID
        {
            get { return _SinceID; }
            set { _SinceID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String MaxID
        {
            get { return _MaxID; }
            set { _MaxID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Page
        {
            get { return _Page; }
            set { _Page = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["count"] = this.Count.ToString();
            d["since_id"] = this.SinceID;
            d["max_id"] = this.MaxID;
            d["page"] = this.Page.ToString();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            return d;
        }
    }
}
