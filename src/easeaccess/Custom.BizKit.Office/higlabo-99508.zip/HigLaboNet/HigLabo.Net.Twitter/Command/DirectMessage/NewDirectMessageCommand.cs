﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class NewDirectMessageCommand : TwitterCommand
    {
        private String _UserID = "";
        private String _ScreenName = "";
        private String _Text = "";
        /// <summary>
        /// 
        /// </summary>
        public String UserID
        {
            get { return _UserID; }
            set { _UserID = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ScreenName
        {
            get { return _ScreenName; }
            set { _ScreenName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Text
        {
            get { return _Text; }
            set { _Text = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["user_id"] = this.UserID;
            d["screen_name"] = this.ScreenName;
            d["text"] = this.Text;
            return d;
        }
    }
}
