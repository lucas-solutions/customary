﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class DestroyDirectMessageCommand : TwitterCommand
    {
        private String _ID = "";
        private Boolean _IncludeEntities = false;
        /// <summary>
        /// 
        /// </summary>
        public String ID
        {
            get { return _ID; }
            set { _ID= value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IncludeEntities
        {
            get { return _IncludeEntities; }
            set { _IncludeEntities = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            d["id"] = this.ID;
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            return d;
        }
    }
}
