﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetDirectMessageListCommand : GetDirectMessageListSentCommand
    {
        private Boolean _SkipStatus = false;
        /// <summary>
        /// 
        /// </summary>
        public Boolean SkipStatus
        {
            get { return _SkipStatus; }
            set { _SkipStatus = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["count"] = this.Count.ToString();
            d["since_id"] = this.SinceID;
            d["max_id"] = this.MaxID;
            d["page"] = this.Page.ToString();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            d["skip_status"] = this.SkipStatus.ToString().ToLower();
            return d;
        }
    }
}
