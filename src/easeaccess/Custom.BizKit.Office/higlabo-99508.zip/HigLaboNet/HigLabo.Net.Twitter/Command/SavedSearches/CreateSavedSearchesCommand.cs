﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class CreateSavedSearchesCommand:TwitterCommand
    {
        private String _Query = null;

        /// <summary>
        /// 
        /// </summary>
        public String Query
        {
            get { return _Query; }
            set { _Query = value; }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<String, String> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["query"] = this.Query;
            return d;
        }
    }
}
