﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class CreateListsCommnad : TwitterCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Mode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Description { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<String, String> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["name"] = this.Name;
            d["mode"] = this.Mode;
            d["description"] = this.Description;
            return d;

        }

    }
}
