﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetListsStatusesCommand : GetTimelineCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public Int64? ListID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Slug { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String OwnerScreenName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int64 OwnerID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32? PerPage { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<String, String> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["list_id"] = this.ListID.ToString();
            d["slug"] = this.Slug;
            d["owner_screen_name"] = this.OwnerScreenName;
            d["owner_id"] = this.OwnerID.ToString();
            d["since_id"] = this.SinceID;
            d["max_id"] = this.MaxID;
            d["per_page"] = this.PerPage.ToString();
            d["page"] = this.Page.ToString();
            d["include_entities"] = this.IncludeEntities.ToString().ToLower();
            return d;
        }
    }
}
