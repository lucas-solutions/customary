﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class CreateAllListsMembersCommand : TwitterCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public Int64? ListID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Slug { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String UserID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ScreenName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String OwnerScreenName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int64? OwnerID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<String, String> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["list_id"] = this.ListID.ToString();
            d["slug"] = this.Slug;
            d["user_id"] = this.UserID.ToString();
            d["screen_name"] = this.ScreenName;
            d["owner_screen_name"] = this.OwnerScreenName;
            d["owner_id"] = this.OwnerID.ToString();
            return d;
        }
    }
}
