﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetListsMembershipsCommand : TwitterCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public Int64? UserID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ScreenName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int64? Cursor { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean FilterToOwnedLists { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<String, String> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            if (this.UserID > 0)
            {
                d["user_id"] = this.UserID.ToString();
            }
            d["screen_name"] = this.ScreenName;
            d["cursor"] = this.Cursor.ToString();
            d["filter_to_owned_lists"] = this.FilterToOwnedLists.ToString().ToLower();
            return d;
        }
    }
}
