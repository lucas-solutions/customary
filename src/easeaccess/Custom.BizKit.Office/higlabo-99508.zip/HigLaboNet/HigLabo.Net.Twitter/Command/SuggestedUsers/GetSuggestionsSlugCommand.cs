﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetSuggestionsSlugCommand : TwitterCommand
    {
        private String _Slug = null;
        private String _Lang = null;
        /// <summary>
        /// 
        /// </summary>
        public String Slug
        {
            get { return this._Slug; }
            set { this._Slug = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Lang
        {
            get { return this._Lang; }
            set { this._Lang = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<String, String> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["slug"] = this.Slug;
            d["lang"] = this.Lang;
            return d;
        }
    }
}
