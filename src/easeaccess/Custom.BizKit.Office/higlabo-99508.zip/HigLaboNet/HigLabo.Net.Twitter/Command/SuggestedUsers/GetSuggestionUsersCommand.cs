﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class GetSuggestionUsersCommand : TwitterCommand
    {
        private String _Slug = null;
        /// <summary>
        /// 
        /// </summary>
        public String Slug
        {
            get { return this._Slug; }
            set { this._Slug = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<String, String> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["slug"] = this.Slug;
            return d;
        }
    }
}
