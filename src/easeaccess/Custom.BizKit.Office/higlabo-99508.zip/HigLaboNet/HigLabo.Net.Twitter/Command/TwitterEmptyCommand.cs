﻿using System;
using System.Collections.Generic;

namespace HigLabo.Net.Twitter
{
    /// <summary>
    /// 
    /// </summary>
    public class TwitterEmptyCommand : TwitterCommand
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<String, String> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();
            return d;
        }
    }
}
