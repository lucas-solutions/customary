﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Ftp
{
    public enum FtpConnectionState
    {
		/// <summary>
		/// 
		/// </summary>
        Disconnected, 
		/// <summary>
		/// 
		/// </summary>
		Connected, 
		/// <summary>
		/// 
		/// </summary>
		Authenticated
    }
}
