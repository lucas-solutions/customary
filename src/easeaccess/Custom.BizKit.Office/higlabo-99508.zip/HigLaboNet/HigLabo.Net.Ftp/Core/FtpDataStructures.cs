﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Ftp
{
    /// <summary>
    /// 
    /// </summary>
    public enum FtpDataStructures
    {
        /// <summary>
        /// 
        /// </summary>
        FileStructure,
        /// <summary>
        /// 
        /// </summary>
        RecordStructure,
        /// <summary>
        /// 
        /// </summary>
        PageStructure,
    }
}
