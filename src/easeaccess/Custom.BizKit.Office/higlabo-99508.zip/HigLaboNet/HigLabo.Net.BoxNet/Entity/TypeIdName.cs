﻿using System;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class Item : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Item(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.Type = d.ToString("type");
            this.ID = d.ToString("id");
            this.Name = d.ToString("name");
        }
    }
}
