﻿using System;
using System.Collections.ObjectModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class CommentCollection : ResponseObjectCollection<Comment>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public CommentCollection(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public void SetProperty(String jsonText)
        {
            var d = this.CreateDictionary(jsonText);
            var cc = JsonConvert.DeserializeObject(d.ToString("entries")) as JContainer;
            if (cc != null)
            {
                foreach (var i in cc)
                {
                    this.Add(new Comment(i.ToString()));
                }
            }
        }
    }
}

