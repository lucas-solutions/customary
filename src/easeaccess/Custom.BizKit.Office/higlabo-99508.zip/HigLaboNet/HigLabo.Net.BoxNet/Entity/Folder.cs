﻿using System;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class Folder : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset CreatedAt { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset ModifiedAt { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Description { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Size { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean Trashed { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Item CreatedBy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Item ModifiedBy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Item OwnedBy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Item ParentFolder { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public ItemCollection Items { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Folder(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.Type = d.ToString("type");
            this.ID = d.ToString("id");
            this.Name = d.ToString("name");
            this.CreatedAt = d.ToDateTimeOffset("created_at") ?? DateTimeOffset.MinValue;
            this.ModifiedAt = d.ToDateTimeOffset("modified_at") ?? DateTimeOffset.MinValue;
            this.Description = d.ToString("description");
            this.Size = d.ToString("size");
            this.CreatedBy = new Item(d.ToString("created_by"));
            this.ModifiedBy = new Item(d.ToString("modified_by"));
            this.OwnedBy = new Item(d.ToString("owned_by"));
            this.ParentFolder = new Item(d.ToString("parent"));
            this.Items = new ItemCollection(d.ToString("item_collection"));
        }
    }
}

