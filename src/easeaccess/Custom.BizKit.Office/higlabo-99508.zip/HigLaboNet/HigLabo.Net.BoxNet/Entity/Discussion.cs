﻿using System;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class Discussion : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ParentFolderID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String CreatorUserID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Created { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String UpdaterUserID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Updated { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Discussion(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.Type = "discussion";
            this.ID = d.ToString("id");
            this.Name = d.ToString("name");

            this.ParentFolderID = d.ToString("folder_id");
            this.CreatorUserID = d.ToString("creator_user_id");
            this.Created = d.ToString("created");
            this.UpdaterUserID = d.ToString("updater_user_id");
            this.Updated = d.ToString("updated");

            // Discussion Object is different!!!
            // Response Result
            //{
            //    "discussion_id":431157,
            //    "name":"disZXCDSA",
            //    "description":"ASDFG",
            //    "folder_id":"274725961",
            //    "user_id":"180485942",
            //    "creator_user_id":"180485942",
            //    "updater_user_id":null,
            //    "deleter_user_id":null,
            //    "shared":null,
            //    "shared_name":null,
            //    "password":null,
            //    "show_comments":null,
            //    "created":1337568766,
            //    "updated":1337568766,
            //    "trashed":null,
            //    "deleted":null,
            //    "deleted_from_trash":null,
            //    "id":431157,
            //    "typed_id":"t_431157"
            //}
        }
    }
}

