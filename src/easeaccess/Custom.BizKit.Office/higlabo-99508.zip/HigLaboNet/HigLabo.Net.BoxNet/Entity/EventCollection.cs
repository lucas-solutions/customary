﻿using System;
using System.Collections.ObjectModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class EventCollection : ResponseObjectCollection<Event>
    {
        /// <summary>
        /// 
        /// </summary>
        public Int32 ChunkSize { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public Int64 NextStreamPosition { set; get; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public EventCollection(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public void SetProperty(String jsonText)
        {
            var d = this.CreateDictionary(jsonText);
            this.ChunkSize = d.ToInt32("chunk_size") ?? 0;
            this.NextStreamPosition = d.ToInt64("next_stream_position") ?? 0;
            var cc = JsonConvert.DeserializeObject(d.ToString("entries")) as JContainer;
            if (cc != null)
            {
                foreach (var i in cc)
                {
                    this.Add(new Event(i.ToString()));
                }
            }
        }
    }
}

