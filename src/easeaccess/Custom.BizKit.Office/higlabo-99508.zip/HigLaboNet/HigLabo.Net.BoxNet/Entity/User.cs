﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class User : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Login { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Email { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 AccessID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 UserID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int64 SpaceAmount { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 SpaceUsed { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int64 MaxUploadSize { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public User(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ele"></param>
        public override void SetProperty(XElement ele)
        {
            var d = this.SetElements(ele);

            Login = d.ToString("login");
            Email = d.ToString("email");
            AccessID = d.ToInt32("access_id") ?? 0;
            UserID = d.ToInt32("user_id") ?? 0;
            SpaceAmount = d.ToInt64("space_amount") ?? 0;
            SpaceUsed = d.ToInt32("space_used") ?? 0;
            MaxUploadSize = d.ToInt64("max_upload_size") ?? 0;
        }
    }
}
