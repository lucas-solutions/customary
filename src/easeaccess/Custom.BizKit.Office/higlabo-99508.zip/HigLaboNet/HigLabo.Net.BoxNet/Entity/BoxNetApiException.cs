﻿using System;
using System.Collections.Generic;
using HigLabo.Net.Extensions;
using Newtonsoft.Json;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class BoxNetApiException : BoxNetClientException
    {
        /// <summary>
        /// 
        /// </summary>
        public String Type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Code { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String HelpUrl { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ErrorMessage { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String RequestID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public BoxNetApiException(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        private void SetProperty(String jsonText)
        {
            var d = JsonConvert.DeserializeObject<Dictionary<String, Object>>(jsonText);

            this.Type = d.ToString("type");
            this.Status = d.ToString("status");
            this.Code = d.ToString("code");
            this.HelpUrl = d.ToString("help_url");
            this.ErrorMessage = d.ToString("message");
            this.RequestID = d.ToString("request_id");
        }
    }
}
