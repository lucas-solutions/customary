﻿using System;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public enum EventType
    {
        /// <summary>
        /// 
        /// </summary>
        ITEM_CREATE,
        /// <summary>
        /// 
        /// </summary>
        ITEM_UPLOAD,
        /// <summary>
        /// 
        /// </summary>
        COMMENT_CREATE,
        /// <summary>
        /// 
        /// </summary>
        ITEM_DOWNLOAD,
        /// <summary>
        /// 
        /// </summary>
        ITEM_PREVIEW,
        /// <summary>
        /// 
        /// </summary>
        ITEM_MOVE,
        /// <summary>
        /// 
        /// </summary>
        ITEM_COPY,
        /// <summary>
        /// 
        /// </summary>
        TASK_ASSIGNMENT_CREATE,
        /// <summary>
        /// 
        /// </summary>
        LOCK_CREATE,
        /// <summary>
        /// 
        /// </summary>
        LOCK_DESTROY,
        /// <summary>
        /// 
        /// </summary>
        ITEM_TRASH,
        /// <summary>
        /// 
        /// </summary>
        ITEM_UNDELETE_VIA_TRASH,
        /// <summary>
        /// 
        /// </summary>
        COLLAB_ADD_COLLABORATOR,
        /// <summary>
        /// 
        /// </summary>
        COLLAB_INVITE_COLLABORATOR,
        /// <summary>
        /// 
        /// </summary>
        ITEM_SYNC,
        /// <summary>
        /// 
        /// </summary>
        ITEM_UNSYNC,
        /// <summary>
        /// 
        /// </summary>
        ITEM_RENAME,
        /// <summary>
        /// 
        /// </summary>
        ITEM_SHARED_CREATE,
        /// <summary>
        /// 
        /// </summary>
        ITEM_SHARED_UNSHARE,
        /// <summary>
        /// 
        /// </summary>
        ITEM_SHARED,
        /// <summary>
        /// 
        /// </summary>
        TAG_ITEM_CREATE
    }
    /// <summary>
    /// 
    /// </summary>
    public class Event : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String EventID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public EventType EventType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String SessionID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Source { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Item CreatedBy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Event(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.Type = d.ToString("type");
            this.EventID = d.ToString("event_id");
            this.EventType = (EventType)Enum.Parse(typeof(EventType), d.ToString("event_type"), true);
            this.SessionID = d.ToString("session_id");
            this.CreatedBy = new Item(d.ToString("created_by"));
            this.Source = d.ToString("source");
            
        }
    }
}

