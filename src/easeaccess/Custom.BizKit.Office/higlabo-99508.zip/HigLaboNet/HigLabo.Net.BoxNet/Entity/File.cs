﻿using System;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class File : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Description { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Size { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Path { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String PathID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset CreatedAt { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset ModifiedAt { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean SharedLinkEnabled { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String SharedLink { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Sha1 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Item ModifiedBy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Item OwnedBy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Item Parent { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public File(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.Type = d.ToString("type");
            this.ID = d.ToString("id");
            this.Name = d.ToString("name");
            this.Description = d.ToString("description");
            this.Size = d.ToInt32("size") ?? 0;
            this.Path = d.ToString("path");
            this.PathID = d.ToString("path_id");
            this.CreatedAt = d.ToDateTimeOffset("created_at") ?? DateTimeOffset.MinValue;
            this.ModifiedAt = d.ToDateTimeOffset("modified_at") ?? DateTimeOffset.MinValue;
            this.SharedLinkEnabled = d.ToBoolean("shared_link_enabled") ?? false;
            this.SharedLink = d.ToString("shared_link");
            this.Sha1 = d.ToString("sha1");
            this.ModifiedBy = new Item(d.ToString("modified_by"));
            this.OwnedBy = new Item(d.ToString("owned_by"));
            this.Parent = new Item(d.ToString("parent"));
        }
    }
}

