﻿using System;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class Comment : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IsReplyComment { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Item CreatedBy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset CreatedAt { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Comment(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.Type = d.ToString("type");
            this.ID = d.ToString("id");
            this.IsReplyComment = d.ToBoolean("is_reply_comment") ?? false;
            this.Message = d.ToString("message");
            this.CreatedBy = new Item(d.ToString("created_by"));
            this.CreatedAt = d.ToDateTimeOffset("created_at") ?? DateTimeOffset.MinValue;
        }
    }
}

