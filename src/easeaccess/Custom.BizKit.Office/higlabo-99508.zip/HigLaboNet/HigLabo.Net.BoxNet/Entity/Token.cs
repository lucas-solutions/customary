﻿using System;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class Token : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String AccessToken { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Item Item { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Token(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.Type = d.ToString("type");
            this.AccessToken = d.ToString("token");
            this.Item = new Item(d.ToString("item"));
        }
    }
}
