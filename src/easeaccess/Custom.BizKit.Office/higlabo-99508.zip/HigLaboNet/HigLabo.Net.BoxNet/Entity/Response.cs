﻿using System;
using System.Xml.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class Response : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public enum ResponseStatus
        {
            /// <summary>
            /// 
            /// </summary>
            NotLoggedIn,
            /// <summary>
            /// 
            /// </summary>
            GetAuthTokenError,
            /// <summary>
            /// 
            /// </summary>
            ApplicationRestricted,
            /// <summary>
            /// 
            /// </summary>
            WrongInput,
            /// <summary>
            /// 
            /// </summary>
            UnknownAction,
            /// <summary>
            /// 
            /// </summary>
            GetTicketOK,
            /// <summary>
            /// 
            /// </summary>
            GetAuthTokenOK,
            /// <summary>
            /// 
            /// </summary>
            UnknowError
        }
        /// <summary>
        /// 
        /// </summary>
        public ResponseStatus Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Ticket { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String AuthToken { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public User User { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="element"></param>
        public Response(XElement element)
        {
            this.SetProperty(element);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ele"></param>
        public override void SetProperty(XElement ele)
        {
            var d = this.SetElements(ele);

            Status = GetResponseStatus(d.ToString("status"));
            Ticket = d.ToString("ticket");
            AuthToken = d.ToString("auth_token");
            if (d.ContainsKey("user"))
            {
                User = new User(ele.Element("user"));
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        private ResponseStatus GetResponseStatus(String str)
        {
            switch (str.ToLower())
            {
                case "application_restricted":
                    return ResponseStatus.ApplicationRestricted;
                case "get_auth_token_error":
                    return ResponseStatus.GetAuthTokenError;
                case "get_ticket_ok":
                    return ResponseStatus.GetTicketOK;
                case "not_logged_in":
                    return ResponseStatus.NotLoggedIn;
                case "unknown_action":
                    return ResponseStatus.UnknownAction;
                case "wrong_input":
                    return ResponseStatus.WrongInput;
                case "get_auth_token_ok":
                    return ResponseStatus.GetAuthTokenOK;
                default:
                    return ResponseStatus.UnknowError;
            }
        }
    }
}
