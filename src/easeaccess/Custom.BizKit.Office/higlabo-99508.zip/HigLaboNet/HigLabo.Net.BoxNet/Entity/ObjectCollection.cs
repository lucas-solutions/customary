﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Collections.ObjectModel;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class ResponseObjectCollection<T> : Collection<T>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="json"></param>
        /// <returns></returns>
        protected Dictionary<String, Object> CreateDictionary(String json)
        {
            Dictionary<String, Object> result = null;
            if (json != null)
            {
                result = JsonConvert.DeserializeObject<Dictionary<String, Object>>(json);
            }
            return result ?? new Dictionary<String, Object>();
        }
    }
}
