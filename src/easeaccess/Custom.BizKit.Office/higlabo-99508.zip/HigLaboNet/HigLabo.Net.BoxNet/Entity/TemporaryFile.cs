﻿using System;
using HigLabo.Net.Extensions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class TemporaryFile : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean Shared { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ParentFolderID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public TemporaryFile(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var s = this.SetData(jsonText).ToString("entries");
            var cc = JsonConvert.DeserializeObject(s) as JContainer;
            if (cc != null)
            {
                var d = this.SetData(cc.First.ToString());
                this.Type = d.ToString("type");
                this.ID = d.ToString("id");
                this.Name = d.ToString("name");
                this.Shared = d.ToBoolean("shared") ?? false;
                this.ParentFolderID = this.SetData(d.ToString("parent_folder")).ToString("id");
            }
        }
    }
}

