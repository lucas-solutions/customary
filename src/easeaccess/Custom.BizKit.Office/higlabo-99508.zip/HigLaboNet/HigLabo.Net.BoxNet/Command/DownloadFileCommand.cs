﻿using System;
using System.Text;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class DownloadFileCommand : BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String FileID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Version { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public override HttpMethodName MethodName
        {
            get
            {
                return HttpMethodName.Get;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return String.Format("/files/{0}/data", FileID);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override byte[] SetData()
        {
            var s = new StringBuilder();
            if (!String.IsNullOrEmpty(Version))
            {
                s.AppendLine("{");
                s.AppendFormat("\"version\": \"{0}\"", Version);
                s.Append("\r\n}");
            }
            return Encoding.UTF8.GetBytes(s.ToString());
        }
    }
}
