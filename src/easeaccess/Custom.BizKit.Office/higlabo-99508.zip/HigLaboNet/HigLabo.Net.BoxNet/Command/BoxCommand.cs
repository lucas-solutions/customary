﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public abstract class BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        protected static readonly string BoxApiUrl = "https://api.box.com/2.0";
        /// <summary>
        /// 
        /// </summary>
        protected static readonly string BoxApiUrlForUpload = "https://upload.box.com/api/2.0";
        /// <summary>
        /// 
        /// </summary>
        public virtual HttpMethodName MethodName
        {
            get { return HttpMethodName.Get; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Byte[] Data
        {
            get { return SetData(); }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IDictionary<String, String> GetParameters()
        {
            var d = this.CreateHParameters();
            return d.Where(a => !String.IsNullOrEmpty(a.Value)).ToDictionary(c => c.Key, c => c.Value);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string GetBaseUrl()
        {
            return GetBaseUrl(BoxApiUrlType.Base);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public string GetBaseUrl(BoxApiUrlType type)
        {
            var baseUrl = "";
            switch (type)
            {
                case BoxApiUrlType.Base:
                    baseUrl = BoxApiUrl;
                    break;
                case BoxApiUrlType.Upload:
                    baseUrl = BoxApiUrlForUpload;
                    break;
            }
            var methodPath = CreateMethodPath();
            if (!methodPath.StartsWith("/"))
                methodPath = "/" + methodPath;
            return (baseUrl + methodPath).ToLower();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected virtual Byte[] SetData()
        {
            return null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected virtual IDictionary<String, String> CreateHParameters()
        {
            return new Dictionary<String, String>();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected abstract String CreateMethodPath();
    }
}
