﻿using System;
using System.Text;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class UpdateDiscussionCommand : BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String DiscussionID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String NewName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String NewDescription { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public override HttpMethodName MethodName
        {
            get
            {
                return HttpMethodName.Put;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return String.Format("/discussions/{0}", DiscussionID);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override byte[] SetData()
        {
            var s = new StringBuilder();
            s.AppendLine("{");
            if (!String.IsNullOrEmpty(NewName))
                s.AppendFormat("\"name\": \"{0}\"", NewName);
            if (!String.IsNullOrEmpty(NewDescription))
            {
                if (!String.IsNullOrEmpty(NewName)) s.AppendFormat(",");
                s.AppendFormat("\"description\": \"{0}\"", NewDescription);
            }
            s.Append("\r\n}");

            return Encoding.UTF8.GetBytes(s.ToString());
        }
    }
}
