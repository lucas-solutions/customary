﻿using System;
using System.Text;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class AddCommentCommand : BoxCommand
    {
        /// <summary>
        /// FileID / DiscussionID
        /// </summary>
        public String ObjectID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        internal CommentType AddType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public override HttpMethodName MethodName
        {
            get
            {
                return HttpMethodName.Post;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override byte[] SetData()
        {
            var s = new StringBuilder();
            s.AppendLine("{");
            s.AppendFormat("\"message\": \"{0}\"", Message);
            s.Append("\r\n}");

            return Encoding.UTF8.GetBytes(s.ToString());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            var str = "";
            switch (AddType)
            {
                case CommentType.Comment:
                    str = "/files/{0}/comments";
                    break;
                case CommentType.Discussion:
                    str = "/discussions/{0}/comments";
                    break;
            }
            return String.Format(str, ObjectID);
        }
    }
}
