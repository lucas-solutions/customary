﻿using System;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class GetCommentCommand : BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String CommentID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return String.Format("/comments/{0}", CommentID);
        }
    }
}
