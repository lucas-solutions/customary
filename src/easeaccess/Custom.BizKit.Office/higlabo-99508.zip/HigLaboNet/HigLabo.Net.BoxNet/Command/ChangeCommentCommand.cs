﻿using System;
using System.Text;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class ChangeCommentCommand : BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String CommentID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public override HttpMethodName MethodName
        {
            get
            {
                return HttpMethodName.Put;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override byte[] SetData()
        {
            var s = new StringBuilder();
            s.AppendLine("{");
            s.AppendFormat("\"message\": \"{0}\"", Message);
            s.Append("\r\n}");

            return Encoding.UTF8.GetBytes(s.ToString());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return String.Format("/comments/{0}", CommentID);
        }
    }
}
