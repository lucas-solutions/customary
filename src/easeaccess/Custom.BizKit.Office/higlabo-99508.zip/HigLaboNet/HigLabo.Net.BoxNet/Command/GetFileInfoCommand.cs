﻿using System;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class GetFileInfoCommand : BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String FileID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return String.Format("/files/{0}", FileID);
        }
    }
}
