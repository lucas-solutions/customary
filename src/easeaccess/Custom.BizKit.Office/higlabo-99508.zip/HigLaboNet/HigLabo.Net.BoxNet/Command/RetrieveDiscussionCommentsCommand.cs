﻿using System;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class RetrieveDiscussionCommentsCommand : BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String DiscussionID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return String.Format("/discussions/{0}/comments", DiscussionID);
        }
    }
}
