﻿using System;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class DeleteCommentCommand : BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String CommentID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public override HttpMethodName MethodName
        {
            get
            {
                return HttpMethodName.Delete;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return String.Format("/comments/{0}", CommentID);
        }
    }
}
