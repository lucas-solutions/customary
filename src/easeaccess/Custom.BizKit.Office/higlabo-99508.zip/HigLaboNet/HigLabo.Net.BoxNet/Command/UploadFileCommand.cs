﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class UploadFileCommand : BoxCommand
    {
        private Byte[] _fileData = new Byte[0];
        /// <summary>
        /// 
        /// </summary>
        public String FolderID { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public String ContentType { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public String FileName { set; get; }
        /// <summary>
        /// 
        /// </summary>
        public UploadFileCommand()
        {
            this.ContentType = "application/octet-stream";
        }
        /// <summary>
        /// 
        /// </summary>
        public override HttpMethodName MethodName
        {
            get
            {
                return HttpMethodName.Post ;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return "/files/data";
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static String GetBoundaryString()
        {
            return "UploadFileCommand_" + DateTime.Now.ToString("yyyyMMddHHmmss");
        }

#if !SILVERLIGHT && !NETFX_CORE
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filePath"></param>
        public void LoadFileData(String filePath)
        {
            _fileData = System.IO.File.ReadAllBytes(filePath);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileInfo"></param>
        public void LoadFileData(FileInfo fileInfo)
        {
            Byte[] bb;
            using (var r = new BinaryReader(fileInfo.OpenRead(), Encoding.UTF8))
            {
                bb = new Byte[fileInfo.Length];
                r.Read(bb, 0, bb.Length);
            }
            _fileData = bb;
        }
#endif
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        public void LoadFileData(Byte[] data)
        {
            _fileData = data;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Byte[] CreatePostData()
        {
            String boundary = GetBoundaryString();
            return this.CreatePostData(boundary);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="boundary"></param>
        /// <returns></returns>
        public Byte[] CreatePostData(String boundary)
        {
            var l = new List<Byte>();
            var sb = new StringBuilder();

            if (!String.IsNullOrEmpty(this.FolderID))
            {
                sb.AppendLine("--" + boundary);
                sb.AppendLine("Content-Disposition: form-data; name=\"folder_id\"");
                sb.AppendLine(Environment.NewLine);
                sb.AppendLine(this.FolderID);
            }

            sb.Append("--");
            sb.AppendLine(boundary);
            sb.AppendFormat("Content-Disposition: form-data; name=\"filename\"; filename=\"{0}\"", this.FileName);
            sb.AppendLine();
            sb.Append("Content-Type: ");
            sb.AppendLine(this.ContentType);
            sb.AppendLine("Content-Transfer-Encoding: binary");
            sb.AppendLine();

            l.AddRange(Encoding.UTF8.GetBytes(sb.ToString()));
            l.AddRange(_fileData);
            l.AddRange(Encoding.UTF8.GetBytes(String.Format("\r\n--{0}--\r\n", boundary)));

            return l.ToArray();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override byte[] SetData()
        {
            return _fileData;
        }
    }
}
