﻿using System;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class GetEventsCommand : BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String StreamPosition { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public StreamType StreamType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Limit { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public GetEventsCommand()
        {
            StreamPosition = "0";
            StreamType = StreamType.All;
            Limit = 100;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return String.Format("/events?stream_position={0}&stream_type={1}&limit={2}", StreamPosition, StreamType, Limit);
        }
    }
}
