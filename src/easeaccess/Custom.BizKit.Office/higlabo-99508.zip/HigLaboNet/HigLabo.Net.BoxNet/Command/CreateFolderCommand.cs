﻿using System;
using System.Text;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class CreateFolderCommand : BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String FolderID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String NewFolderName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public override HttpMethodName MethodName
        {
            get
            {
                return HttpMethodName.Post;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override byte[] SetData()
        {
            var s = new StringBuilder();
            s.AppendLine("{");
            s.AppendFormat("\"name\": \"{0}\"", NewFolderName);
            s.Append("\r\n}");

            return Encoding.UTF8.GetBytes(s.ToString());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return String.Format("/folders/{0}", FolderID);
        }
    }
}
