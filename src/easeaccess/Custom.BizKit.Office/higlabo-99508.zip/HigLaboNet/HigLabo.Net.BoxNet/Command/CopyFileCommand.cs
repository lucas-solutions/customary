﻿using System;
using System.Text;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class CopyFileCommand : BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String FileID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String DestinationFolderID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public override HttpMethodName MethodName
        {
            get
            {
                return HttpMethodName.Post;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return String.Format("/files/{0}/copy", FileID);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override byte[] SetData()
        {
            var s = new StringBuilder();
            s.AppendLine("{");
            s.AppendLine("\"parent_folder\": {");
            s.AppendFormat("\"id\": \"{0}\"", DestinationFolderID);
            s.Append("\r\n}}");

            return Encoding.UTF8.GetBytes(s.ToString());
        }
    }
}
