﻿namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public enum BoxApiUrlType
    {
        /// <summary>
        /// 
        /// </summary>
        Base,
        /// <summary>
        /// 
        /// </summary>
        Upload
    }
}
