﻿namespace HigLabo.Net.BoxNet
{
    internal enum CommentType
    {
        Comment,
        Discussion
    }
}
