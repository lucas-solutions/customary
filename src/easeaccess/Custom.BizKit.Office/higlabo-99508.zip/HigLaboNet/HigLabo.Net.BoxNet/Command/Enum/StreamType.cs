﻿namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public enum StreamType
    {
        /// <summary>
        /// 
        /// </summary>
        All,
        /// <summary>
        /// 
        /// </summary>
        Changes,
        /// <summary>
        /// 
        /// </summary>
        Sync
    }
}
