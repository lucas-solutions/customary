﻿using System;
using System.Text;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class GetTokenCommand : BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String ApiKey { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Email { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public override HttpMethodName MethodName
        {
            get
            {
                return HttpMethodName.Post;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return "/tokens";
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override byte[] SetData()
        {
            var s = new StringBuilder();
            s.AppendLine("{");
            s.AppendFormat("\"email\": \"{0}\"", Email);
            s.Append("\r\n}");

            return Encoding.UTF8.GetBytes(s.ToString());
        }
    }
}
