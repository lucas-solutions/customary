﻿using System;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class GetFolderInfoCommand : BoxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public String FolderID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override string CreateMethodPath()
        {
            return String.Format("/folders/{0}", FolderID);
        }
    }
}
