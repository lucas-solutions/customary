﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class BoxNetClientException : Exception
    {
        /// <summary>
        /// 
        /// </summary>
        public BoxNetClientException()
            : base()
        {
        }
    }
}
