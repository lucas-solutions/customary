﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using System.IO;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public partial class BoxClient 
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="accessToken"></param>
        public BoxClient(AccessToken accessToken)
        {
            if (accessToken == null) throw new ArgumentNullException("accessToken");
            AccessToken = accessToken;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="clientID"></param>
        /// <param name="clientSecret"></param>
        /// <param name="redirectUri"></param>
        /// <param name="code"></param>
        /// <returns></returns>
        public static AccessToken GetAccessToken(String clientID, String clientSecret, String redirectUri, String code)
        {
            String url = "https://api.box.com/oauth2/token";
            var cl = new HttpClient();
            cl.ResponseEncoding = Encoding.UTF8;

            var cm = new HttpRequestCommand(url);
            cm.MethodName = HttpMethodName.Post;
            var d = new Dictionary<String, String>();
            d["grant_type"] = "authorization_code";
            d["code"] = code;
            d["client_id"] = clientID;
            d["client_secret"] = clientSecret;
            d["redirect_uri"] = redirectUri;
            cm.SetBodyStream(new HttpBodyFormUrlEncodedData(Encoding.UTF8, d));

            var text = cl.GetBodyText(cm);
            var t = CreateAccessToken(clientID, text);
            return t;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        private String GetResponseBodyText(BoxCommand command)
        {
            var cm = this.CreateHttpRequestCommand(command.MethodName, command.GetBaseUrl(), AccessToken, command.GetParameters());
            if (command.MethodName == HttpMethodName.Post
             || command.MethodName == HttpMethodName.Put
             || command.MethodName == HttpMethodName.Move
             || command.MethodName == HttpMethodName.Copy)
            {
                cm.SetBodyStream(command.Data);
            }
            var res = this.GetResponse(cm);
            this.IsThrowException(res.BodyText);
            return res.BodyText;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        private Stream GetHttpWebResponse(BoxCommand command)
        {
            var cm = this.CreateHttpRequestCommand(command.MethodName, command.GetBaseUrl(), AccessToken, command.GetParameters());
            if (command.MethodName == HttpMethodName.Post
             || command.MethodName == HttpMethodName.Put
             || command.MethodName == HttpMethodName.Move
             || command.MethodName == HttpMethodName.Copy)
            {
                cm.SetBodyStream(command.Data);
            }
            var res = this.GetHttpWebResponse(cm);
            return res.GetResponseStream();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        private String Post(UploadNewVersionFileCommand command)
        {
            var d = command.GetParameters();
            var cm = this.CreateHttpRequestCommand(command.MethodName, command.GetBaseUrl(BoxApiUrlType.Upload), AccessToken, d);
            String boundary = UploadFileCommand.GetBoundaryString();
            cm.ContentType = "multipart/form-data; boundary=\"" + boundary + "\"";
            cm.SetBodyStream(command.CreatePostData(boundary));

            return this.GetBodyText(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        private String Post(UploadFileCommand command)
        {
            var d = command.GetParameters();
            var cm = this.CreateHttpRequestCommand(command.MethodName, command.GetBaseUrl(BoxApiUrlType.Upload), AccessToken, d);
            String boundary = UploadFileCommand.GetBoundaryString();
            cm.ContentType = "multipart/form-data; boundary=\"" + boundary + "\"";
            cm.SetBodyStream(command.CreatePostData(boundary));

            return this.GetBodyText(cm);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Folder CreateFolder(CreateFolderCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new Folder(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Folder GetFolderInfo(GetFolderInfoCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new Folder(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public ItemCollection RetrieveFolderItems(RetrieveFolderItemsCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new ItemCollection(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Folder UpdateFolderInfo(UpdateFolderInfoCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new Folder(text);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public File GetFileInfo(GetFileInfoCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new File(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public File UpdateFileInfo(UpdateFileInfoCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new File(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public File CopyFile(CopyFileCommand command)
        {
            if (String.IsNullOrEmpty(command.DestinationFolderID)) throw new ArgumentNullException("CopyFileCommand.DestinationFolderID");
            String text = this.GetResponseBodyText(command);
            return new File(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        public void DeleteFile(DeleteFileCommand command)
        {
            this.GetResponseBodyText(command);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Byte[] DownloadFile(DownloadFileCommand command)
        {
            var rep = this.GetHttpWebResponse(command);
            return rep.ToByteArray();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public CommentCollection GetCommentsOnFile(GetCommentsOnFileCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new CommentCollection(text);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public TemporaryFile UploadNewVersion(UploadNewVersionFileCommand command)
        {
            String text = Post(command);
            return new TemporaryFile(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Comment AddCommentToFile(AddCommentCommand command)
        {
            command.AddType = CommentType.Comment;
            String text = this.GetResponseBodyText(command);
            return new Comment(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Comment AddCommentToDiscussion(AddCommentCommand command)
        {
            command.AddType = CommentType.Discussion;
            String text = this.GetResponseBodyText(command);
            return new Comment(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Comment ChangeCommentMessage(ChangeCommentCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new Comment(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Comment GetCommentInfo(GetCommentCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new Comment(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        public void DeleteComment(DeleteCommentCommand command)
        {
            this.GetResponseBodyText(command);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Discussion CreateDiscussion(CreatediscussionCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new Discussion(text);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public CommentCollection RetrieveDiscussionComments(RetrieveDiscussionCommentsCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new CommentCollection(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Discussion UpdateDiscussion(UpdateDiscussionCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new Discussion(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public EventCollection GetEvents(GetEventsCommand command)
        {
            String text = this.GetResponseBodyText(command);
            return new EventCollection(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public TemporaryFile UploadFile(UploadFileCommand command)
        {
            String text = Post(command);
            return new TemporaryFile(text);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public String GetFileVersions(GetFileVersionsCommand command)
        {
            return this.GetResponseBodyText(command);
        }
    }
}
