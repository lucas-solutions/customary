﻿using System;
using System.Xml.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;
using System.Net;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public partial class BoxClient : HttpClient
    {
        /// <summary>
        /// 
        /// </summary>
        public AccessToken AccessToken { get; private set; }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="callbackUrl"></param>
        /// <returns></returns>
        public static String CreateAuthorizeUrl(String consumerKey, String callbackUrl)
        {
            return CreateAuthorizeUrl(consumerKey, callbackUrl, HttpClient.UrlEncode);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="callbackUrl"></param>
        /// <param name="urlEncodingFunction"></param>
        /// <returns></returns>
        public static String CreateAuthorizeUrl(String consumerKey, String callbackUrl, Func<String, String> urlEncodingFunction)
        {
            var f = urlEncodingFunction;
            return String.Format("https://api.box.com/oauth2/authorize?response_type=code&client_id={0}&state=authenticated&redirect_uri={1}"
                , f(consumerKey), f(callbackUrl));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="clientID"></param>
        /// <param name="clientSecret"></param>
        /// <param name="redirectUri"></param>
        /// <param name="code"></param>
        /// <param name="callback"></param>
        public static void GetAccessToken(String clientID, String clientSecret, String redirectUri, String code
            , Action<AccessToken> callback)
        {
            String url = "https://api.box.com/oauth2/token";
            var cl = new HttpClient();
            cl.ResponseEncoding = Encoding.UTF8;

            var cm = new HttpRequestCommand(url);
            cm.MethodName = HttpMethodName.Post;
            var d = new Dictionary<String, String>();
            d["grant_type"] = "authorization_code";
            d["code"] = code;
            d["client_id"] = clientID;
            d["client_secret"] = clientSecret;
            d["redirect_uri"] = redirectUri;
            cm.SetBodyStream(new HttpBodyFormUrlEncodedData(Encoding.UTF8, d));

            cl.GetBodyText(cm, text =>
            {
                var t = CreateAccessToken(clientID, text);
                callback(t);
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        private void GetResponseBodyText(BoxCommand command, Action<String> callback)
        {
            this.GetHttpWebResponse(command, res =>
            {
                IsThrowException(res.BodyText);
                callback(res.BodyText);
            });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        private void GetResponseBodyData(BoxCommand command, Action<Byte[]> callback)
        {
            this.GetHttpWebResponse(command, res => callback(res.BodyData));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        private void GetHttpWebResponse(BoxCommand command, Action<HttpResponse> callback)
        {
            var cm = this.CreateHttpRequestCommand(command.MethodName, command.GetBaseUrl(), this.AccessToken, command.GetParameters());
            if (command.MethodName == HttpMethodName.Post
             || command.MethodName == HttpMethodName.Put
             || command.MethodName == HttpMethodName.Move
             || command.MethodName == HttpMethodName.Copy)
            {
                cm.SetBodyStream(command.Data);
            }
            this.GetResponse(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        private void IsThrowException(String response)
        {
            String result = response;

            if (Regex.IsMatch(result, @"{""type"":""error""", RegexOptions.IgnoreCase))
            {
                throw new BoxNetApiException(response);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="clientID"></param>
        /// <param name="jsonText"></param>
        /// <returns></returns>
        public static AccessToken CreateAccessToken(String clientID, String jsonText)
        {
            AccessToken t = new AccessToken();
            var d = JsonConvert.DeserializeObject<Dictionary<String, Object>>(jsonText);
            t.Value = d.ToString("access_token");
            t.ExpiresIn = d.ToInt32("expired_in") ?? 0;
            t.TokenType = d.ToString("token_type");
            t.RefreshToken = d.ToString("refresh_token");

            return t;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="url"></param>
        /// <param name="token"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private HttpRequestCommand CreateHttpRequestCommand(HttpMethodName methodName, String url, AccessToken token, IEnumerable<KeyValuePair<string, string>> parameters)
        {
            var cm = new HttpRequestCommand(url);
            cm.MethodName = methodName;
            cm.Headers[HttpRequestHeader.Authorization] = String.Format("Bearer {0}", token.Value);
            foreach (var item in parameters)
            {
                cm.Headers[item.Key] = item.Value;
            }
            return cm;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void CreateFolder(CreateFolderCommand command, Action<Folder> callback)
        {
            this.GetResponseBodyText(command, s => callback(new Folder(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetFolderInfo(GetFolderInfoCommand command, Action<Folder> callback)
        {
            this.GetResponseBodyText(command, s => callback(new Folder(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void RetrieveFolderItems(RetrieveFolderItemsCommand command, Action<ItemCollection> callback)
        {
            this.GetResponseBodyText(command, s => callback(new ItemCollection(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UpdateFolderInfo(UpdateFolderInfoCommand command, Action<Folder> callback)
        {
            this.GetResponseBodyText(command, s => callback(new Folder(s)));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetFileInfo(GetFileInfoCommand command, Action<File> callback)
        {
            this.GetResponseBodyText(command, s => callback(new File(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UpdateFileInfo(UpdateFileInfoCommand command, Action<File> callback)
        {
            this.GetResponseBodyText(command, s => callback(new File(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void CopyFile(CopyFileCommand command, Action<File> callback)
        {
            if (String.IsNullOrEmpty(command.DestinationFolderID)) throw new ArgumentNullException("CopyFileCommand.DestinationFolderID");
            this.GetResponseBodyText(command, s => callback(new File(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void DeleteFile(DeleteFileCommand command, Action<String> callback)
        {
            this.GetResponseBodyText(command, s => callback(s));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void DownloadFile(DownloadFileCommand command, Action<Byte[]> callback)
        {
            this.GetResponseBodyData(command, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetCommentsOnFile(GetCommentsOnFileCommand command, Action<CommentCollection> callback)
        {
            this.GetResponseBodyText(command, s => callback(new CommentCollection(s)));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"> </param>
        /// <returns></returns>
        public void UploadNewVersion(UploadNewVersionFileCommand command, Action<TemporaryFile> callback)
        {
            this.GetResponseBodyText(command, s => callback(new TemporaryFile(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void AddCommentToFile(AddCommentCommand command, Action<Comment> callback)
        {
            command.AddType = CommentType.Comment;
            this.GetResponseBodyText(command, s => callback(new Comment(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void AddCommentToDiscussion(AddCommentCommand command, Action<Comment> callback)
        {
            command.AddType = CommentType.Discussion;
            this.GetResponseBodyText(command, s => callback(new Comment(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void ChangeCommentMessage(ChangeCommentCommand command, Action<Comment> callback)
        {
            this.GetResponseBodyText(command, s => callback(new Comment(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetCommentInfo(GetCommentCommand command, Action<Comment> callback)
        {
            this.GetResponseBodyText(command, s => callback(new Comment(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void DeleteComment(DeleteCommentCommand command, Action<String> callback)
        {
            this.GetResponseBodyText(command, s => callback(s));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void CreateDiscussion(CreatediscussionCommand command, Action<Discussion> callback)
        {
            this.GetResponseBodyText(command, s => callback(new Discussion(s)));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void RetrieveDiscussionComments(RetrieveDiscussionCommentsCommand command, Action<CommentCollection> callback)
        {
            this.GetResponseBodyText(command, s => callback(new CommentCollection(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UpdateDiscussion(UpdateDiscussionCommand command, Action<Discussion> callback)
        {
            this.GetResponseBodyText(command, s => callback(new Discussion(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetEvents(GetEventsCommand command, Action<EventCollection> callback)
        {
            this.GetResponseBodyText(command, s => callback(new EventCollection(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UploadFile(UploadFileCommand command, Action<TemporaryFile> callback)
        {
            this.GetResponseBodyText(command, s => callback(new TemporaryFile(s)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetFileVersions(GetFileVersionsCommand command, Action<String> callback)
        {
            this.GetResponseBodyText(command, s => callback(s));
        }
    }
}
