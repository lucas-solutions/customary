﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class Func
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsons"></param>
        /// <returns></returns>
        public static Dictionary<String, Object> SetData(String jsons)
        {
            Dictionary<String, Object> result = null;
            if (jsons != null)
                result = JsonConvert.DeserializeObject<Dictionary<String, Object>>(jsons);
            return result ?? new Dictionary<String, Object>();
        }
    }
}
