﻿using System;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public class AccessToken
    {
        /// <summary>
        /// 
        /// </summary>
        public String Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 ExpiresIn { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String TokenType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String RefreshToken { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public AccessToken()
        {
        }
    }
}
