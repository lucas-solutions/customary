﻿using System;
using System.Xml.Linq;
using System.Threading.Tasks;

namespace HigLabo.Net.BoxNet
{
    /// <summary>
    /// 
    /// </summary>
    public partial class BoxClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="func"></param>
        /// <returns></returns>
        protected new static Task<T> CreateNewTask<T>(Func<T> func)
        {
            return Task.Factory.StartNew<T>(func);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="action"></param>
        /// <returns></returns>
        protected static Task CreateNewTask(Action action)
        {
            return Task.Factory.StartNew(action);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Folder> CreateFolderAsync(CreateFolderCommand command)
        {
            return CreateNewTask<Folder>(() => CreateFolder(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Folder> GetFolderInfoAsync(GetFolderInfoCommand command)
        {
            return CreateNewTask<Folder>(() => GetFolderInfo(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<ItemCollection> RetrieveFolderItemsAsync(RetrieveFolderItemsCommand command)
        {
            return CreateNewTask<ItemCollection>(() => RetrieveFolderItems(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Folder> UpdateFolderInfoAsync(UpdateFolderInfoCommand command)
        {
            return CreateNewTask<Folder>(() => UpdateFolderInfo(command));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<File> GetFileInfoAsync(GetFileInfoCommand command)
        {
            return CreateNewTask<File>(() => GetFileInfo(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<File> UpdateFileInfoAsync(UpdateFileInfoCommand command)
        {
            return CreateNewTask<File>(() => UpdateFileInfo(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<File> CopyFileAsync(CopyFileCommand command)
        {
            return CreateNewTask<File>(() => CopyFile(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        public Task DeleteFileAsync(DeleteFileCommand command)
        {
            return CreateNewTask(() => DeleteFile(command));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Byte[]> DownloadFileAsync(DownloadFileCommand command)
        {
            return CreateNewTask<Byte[]>(() => DownloadFile(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<CommentCollection> GetCommentsOnFileAsync(GetCommentsOnFileCommand command)
        {
            return CreateNewTask<CommentCollection>(() => GetCommentsOnFile(command));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<TemporaryFile> UploadNewVersionAsync(UploadNewVersionFileCommand command)
        {
            return CreateNewTask<TemporaryFile>(() => UploadNewVersion(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Comment> AddCommentToFileAsync(AddCommentCommand command)
        {
            return CreateNewTask<Comment>(() => AddCommentToFile(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Comment> AddCommentToDiscussionAsync(AddCommentCommand command)
        {
            return CreateNewTask<Comment>(() => AddCommentToDiscussion(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Comment> ChangeCommentMessageAsync(ChangeCommentCommand command)
        {
            return CreateNewTask<Comment>(() => ChangeCommentMessage(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Comment> GetCommentInfoAsync(GetCommentCommand command)
        {
            return CreateNewTask<Comment>(() => GetCommentInfo(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        public Task DeleteCommentAsync(DeleteCommentCommand command)
        {
            return CreateNewTask(() => DeleteComment(command));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Discussion> CreateDiscussionAsync(CreatediscussionCommand command)
        {
            return CreateNewTask<Discussion>(() => CreateDiscussion(command));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<CommentCollection> RetrieveDiscussionCommentsAsync(RetrieveDiscussionCommentsCommand command)
        {
            return CreateNewTask<CommentCollection>(() => RetrieveDiscussionComments(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Discussion> UpdateDiscussionAsync(UpdateDiscussionCommand command)
        {
            return CreateNewTask<Discussion>(() => UpdateDiscussion(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<EventCollection> GetEventsAsync(GetEventsCommand command)
        {
            return CreateNewTask<EventCollection>(() => GetEvents(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<TemporaryFile> UploadFileAsync(UploadFileCommand command)
        {
            return CreateNewTask<TemporaryFile>(() => UploadFile(command));
        }
    }
}
