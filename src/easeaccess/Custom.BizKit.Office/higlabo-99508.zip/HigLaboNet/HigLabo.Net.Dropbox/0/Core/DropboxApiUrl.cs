﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public class DropboxApiUrl
    {
        /// <summary>
        /// 
        /// </summary>
        public class Version0
        {
            /// <summary>
            /// 
            /// </summary>
            public class OAuth
            {
                /// <summary>
                /// 
                /// </summary>
                public static readonly String RequestToken = "api.dropbox.com/0/oauth/request_token";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String AuthorizeToken = "www.dropbox.com/0/oauth/authorize";
                /// <summary>
                /// 
                /// </summary>
                public static readonly String AccessToken = "api.dropbox.com/0/oauth/access_token";
            }
            /// <summary>
            /// 
            /// </summary>
            public static readonly String Token = "api.dropbox.com/0/token";
            /// <summary>
            /// 
            /// </summary>
            public static readonly String GetAccount = "api.dropbox.com/0/account/info";
            /// <summary>
            /// 
            /// </summary>
            public static readonly String CreateAccount = "api.dropbox.com/0/account";
            /// <summary>
            /// 
            /// </summary>
            public static readonly String Files = "api-content.dropbox.com/0/files/dropbox";
            /// <summary>
            /// 
            /// </summary>
            public static readonly String Metadata = "api.dropbox.com/0/metadata/dropbox";
            /// <summary>
            /// 
            /// </summary>
            public static readonly String Thumbnail = "api-content.dropbox.com/0/thumbnails/dropbox";
            /// <summary>
            /// 
            /// </summary>
            public static readonly String CopyFile = "api.dropbox.com/0/fileops/copy";
            /// <summary>
            /// 
            /// </summary>
            public static readonly String MoveFile = "api.dropbox.com/0/fileops/move";
            /// <summary>
            /// 
            /// </summary>
            public static readonly String CreateFolder = "api.dropbox.com/0/fileops/create_folder";
            /// <summary>
            /// 
            /// </summary>
            public static readonly String Delete = "api.dropbox.com/0/fileops/delete";
        }
    }
}
