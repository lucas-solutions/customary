﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using Newtonsoft.Json;
using HigLabo.Net;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public partial class DropboxClient : OAuthClient
    {
        private HttpProtocolType _Protocol = HttpProtocolType.Https;
        private String _AccessToken = "";
        private String _AccessTokenSecret = "";
        /// <summary>
        /// 
        /// </summary>
        public HttpProtocolType Protocol
        {
            get { return _Protocol; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String AccessToken
        {
            get { return _AccessToken; }
            set { _AccessToken = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String AccessTokenSecret
        {
            get { return _AccessTokenSecret; }
            set { _AccessTokenSecret = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <param name="accessToken"></param>
        /// <param name="accessTokenSecret"></param>
        public DropboxClient(String consumerKey, String consumerSecret, String accessToken, String accessTokenSecret)
            : base(consumerKey, consumerSecret
                , "https://" + DropboxApiUrl.Version0.OAuth.RequestToken
                , "https://" + DropboxApiUrl.Version0.OAuth.AuthorizeToken
                , "https://" + DropboxApiUrl.Version0.OAuth.AccessToken)
        {
            _AccessToken = accessToken;
            _AccessTokenSecret = accessTokenSecret;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <returns></returns>
        public static OAuthClient CreateOAuthClient(String consumerKey, String consumerSecret)
        {
            var cl = new OAuthClient(consumerKey, consumerSecret
                , "https://" + DropboxApiUrl.Version0.OAuth.RequestToken
                , "https://" + DropboxApiUrl.Version0.OAuth.AuthorizeToken
                , "https://" + DropboxApiUrl.Version0.OAuth.AccessToken);
            return cl;
        }
        private void GetResponseBodyText(String url, DropboxCommand command, Action<String> callback)
        {
            this.GetResponseBodyText(HttpMethodName.Get, url, command, callback);
        }
        private void GetResponseBodyText(HttpMethodName methodName, String url, DropboxCommand command, Action<String> callback)
        {
            this.GetHttpWebResponse(methodName, url, command, res => callback(res.BodyText));
        }
        private void GetHttpWebResponse(HttpMethodName methodName, String url, DropboxCommand command, Action<Byte[]> callback)
        {
            this.GetHttpWebResponse(methodName, url, command, res => callback(res.BodyData));
        }
        private void GetHttpWebResponse(HttpMethodName methodName, String url, DropboxCommand command, Action<HttpResponse> callback)
        {
            String u = _Protocol.ToString().ToLower() + "://" + url;
            IDictionary<String, String> d = new Dictionary<String, String>();

            if (methodName == HttpMethodName.Put ||
                methodName == HttpMethodName.Delete)
            { throw new ArgumentException(); }

            if (command != null)
            {
                d = command.GetParameters();
            }
            this.GetHttpWebResponse(methodName, u, this._AccessToken, this._AccessTokenSecret, d
                , res => this.GetHttpWebResponseCallback(res, callback));
        }
        private void GetHttpWebResponseCallback(HttpWebResponse response, Action<HttpResponse> callback)
        {
            var res = new HttpResponse(response, this.ResponseEncoding);
            callback(res);
        }
        private void Post(String url, UploadFileCommand command, Action<HttpResponse> callback)
        {
            String u = _Protocol.ToString().ToLower() + "://" + url;
            var d = new Dictionary<String, String>();
            d["file"] = command.FileName;
            var cm = this.CreateHttpRequestCommand(HttpMethodName.Post, u, this.AccessToken, this.AccessTokenSecret, d);
            String boundary = UploadFileCommand.GetBoundaryString();
            cm.ContentType = "multipart/form-data; boundary=\"" + boundary + "\"";
            cm.SetBodyStream(command.CreatePostData(boundary));

            this.GetResponse(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <param name="callback"></param>
        public static void GetAccessTokenInfo(String consumerKey, String email, String password, Action<AccessTokenInfo> callback)
        {
            GetAccessTokenInfo(consumerKey, email, password, callback, null);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <param name="callback"></param>
        /// <param name="errorCallback"></param>
        public static void GetAccessTokenInfo(String consumerKey, String email, String password
            , Action<AccessTokenInfo> callback, EventHandler<AsyncHttpCallErrorEventArgs> errorCallback)
        {
            HttpClient cl = new HttpClient();
            if (errorCallback != null)
            {
                cl.Error += errorCallback;
            }
            String url = String.Format("https://{0}?oauth_consumer_key={1}&email={2}&password={3}"
                , DropboxApiUrl.Version0.Token, consumerKey, email, password);
            cl.GetBodyText(url, res =>
            {
                var d = JsonConvert.DeserializeObject<Dictionary<String, Object>>(res);
                callback(new AccessTokenInfo(d["token"].ToString(), d["secret"].ToString()));
            });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        /// <param name="command"></param>
        public void GetAccountInfo(GetAccountCommand command, Action<AccountInfo> callback)
        {
            this.GetResponseBodyText(DropboxApiUrl.Version0.GetAccount, command, text => callback(new AccountInfo(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void CreateAccount(CreateAccountCommand command, Action<String> callback)
        {
            this.GetResponseBodyText(DropboxApiUrl.Version0.CreateAccount, command, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetMetadata(GetMetadataCommand command, Action<Metadata> callback)
        {
            String url = "";

            if (command.Path.StartsWith("/") == true)
            {
                url = DropboxApiUrl.Version0.Metadata + command.Path;
            }
            else
            {
                url = DropboxApiUrl.Version0.Metadata + "/" + command.Path;
            }
            this.GetResponseBodyText(url, command, text => callback(new Metadata(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="path"></param>
        /// <param name="callback"></param>
        public void GetFile(String path, Action<Byte[]> callback)
        {
            String url = "";
            if (path.StartsWith("/") == true)
            {
                url = DropboxApiUrl.Version0.Files + path;
            }
            else
            {
                url = DropboxApiUrl.Version0.Files + "/" + path;
            }
            this.GetHttpWebResponse(HttpMethodName.Get, url, null, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void UploadFile(UploadFileCommand command, Action<HttpResponse> callback)
        {
            String url = "";
            if (String.IsNullOrEmpty(command.FolderPath) == true) { throw new ArgumentException(); }
            if (command.FolderPath.StartsWith("/") == true)
            {
                url = DropboxApiUrl.Version0.Files + command.FolderPath;
            }
            else
            {
                url = DropboxApiUrl.Version0.Files + "/" + command.FolderPath;
            }
            this.Post(url, command, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetThumbnails(GetThumbnailsCommand command, Action<Byte[]> callback)
        {
            String url = "";
            if (command.Path.StartsWith("/") == true)
            {
                url = DropboxApiUrl.Version0.Thumbnail + command.Path;
            }
            else
            {
                url = DropboxApiUrl.Version0.Thumbnail + "/" + command.Path;
            }
            this.GetHttpWebResponse(HttpMethodName.Get, url, command, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void CopyFile(MoveFileCommand command, Action<Metadata> callback)
        {
            this.GetResponseBodyText(DropboxApiUrl.Version0.CopyFile, command, text => callback(new Metadata(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void MoveFile(MoveFileCommand command, Action<Metadata> callback)
        {
            this.GetResponseBodyText(DropboxApiUrl.Version0.MoveFile, command, text => callback(new Metadata(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void CreateFolder(CreateFolderCommand command, Action<Metadata> callback)
        {
            this.GetResponseBodyText(DropboxApiUrl.Version0.CreateFolder, command, text => callback(new Metadata(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void Delete(DeleteCommand command, Action<String> callback)
        {
            this.GetResponseBodyText(DropboxApiUrl.Version0.Delete, command, callback);
        }
    }
}
