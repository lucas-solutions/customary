﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public class CreateAccountCommand : DropboxCommand
    {
        private String _EMail = "";
        private String _FirstName = "";
        private String _LastName = "";
        private String _Password = "";
        private Boolean _StatusInResponse = false;
        /// <summary>
        /// 
        /// </summary>
        public String EMail
        {
            get { return _EMail; }
            set { _EMail = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String FirstName
        {
            get { return _FirstName; }
            set { _FirstName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String LastName
        {
            get { return _LastName; }
            set { _LastName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Password
        {
            get { return _Password; }
            set { _Password = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean StatusInResponse
        {
            get { return _StatusInResponse; }
            set { _StatusInResponse = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public CreateAccountCommand()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["email"] = this.EMail;
            d["first_name"] = this.FirstName;
            d["last_name"] = this.LastName;
            d["password"] = this.Password;
            d["status_in_response"] = this.StatusInResponse.ToString().ToLower();
            return d;
        }
    }
}
