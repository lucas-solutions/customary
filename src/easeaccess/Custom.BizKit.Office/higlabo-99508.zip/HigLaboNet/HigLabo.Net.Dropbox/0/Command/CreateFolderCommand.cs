﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public class CreateFolderCommand : DropboxCommand
    {
        private RootFolder _Root = RootFolder.Dropbox;
        private String _Path = "";
        private String _Callback = "";
        /// <summary>
        /// 
        /// </summary>
        public RootFolder Root
        {
            get { return _Root; }
            set { _Root = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Path
        {
            get { return _Path; }
            set { _Path = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Callback
        {
            get { return _Callback; }
            set { _Callback = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["root"] = this.Root.ToString().ToLower();
            d["path"] = this.Path;
            d["callback"] = this.Callback;
            return d;
        }
    }
}
