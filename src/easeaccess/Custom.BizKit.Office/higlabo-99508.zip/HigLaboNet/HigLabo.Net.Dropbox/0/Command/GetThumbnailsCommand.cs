﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public class GetThumbnailsCommand : DropboxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public enum ThumbnailSize
        {
            /// <summary>
            /// 
            /// </summary>
            Small, 
            /// <summary>
            /// 
            /// </summary>
            Medium, 
            /// <summary>
            /// 
            /// </summary>
            Large
        }
        private String _Path = "/";
        private ThumbnailSize _Size = ThumbnailSize.Small;
        private String _Format = "JPEG";
        /// <summary>
        /// 
        /// </summary>
        public String Path
        {
            get { return _Path; }
            set { _Path = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Format
        {
            get { return _Format; }
            set { _Format = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public ThumbnailSize Size
        {
            get { return _Size; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["size"] = this.Size.ToString().ToLower();
            d["format"] = this.Format;
            return d;
        }
    }
}
