﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public class MoveFileCommand : DropboxCommand
    {
        private RootFolder _Root = RootFolder.Dropbox;
        private String _FromPath = "";
        private String _ToPath = "";
        private String _Callback = "";
        /// <summary>
        /// 
        /// </summary>
        public RootFolder Root
        {
            get { return _Root; }
            set { _Root = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String FromPath
        {
            get { return _FromPath; }
            set { _FromPath = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ToPath
        {
            get { return _ToPath; }
            set { _ToPath = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Callback
        {
            get { return _Callback; }
            set { _Callback = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["root"] = this.Root.ToString().ToLower();
            d["from_path"] = this.FromPath;
            d["to_path"] = this.ToPath;
            d["callback"] = this.Callback;
            return d;
        }
    }
}
