﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public abstract class DropboxCommand
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IDictionary<String, String> GetParameters()
        {
            var d = this.CreateParameters();
            this.RemoveEmptyEntry(d);
            return d;
        }
        private void RemoveEmptyEntry(IDictionary<String, String> data)
        {
            List<String> keys = new List<string>();
            foreach (var key in data.Keys)
            {
                if (String.IsNullOrEmpty(data[key]) == true)
                {
                    keys.Add(key);
                }
            }
            for (int i = 0; i < keys.Count; i++)
            {
                data.Remove(keys[i]);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected abstract IDictionary<String, String> CreateParameters();
    }
}
