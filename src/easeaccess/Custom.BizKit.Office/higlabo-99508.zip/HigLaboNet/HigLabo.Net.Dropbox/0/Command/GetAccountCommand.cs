﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public class GetAccountCommand : DropboxCommand
    {
        private Boolean _StatusInResponse = false;
        /// <summary>
        /// 
        /// </summary>
        public Boolean StatusInResponse
        {
            get { return _StatusInResponse; }
            set { _StatusInResponse = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public GetAccountCommand()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["status_in_response"] = this.StatusInResponse.ToString().ToLower();
            return d;
        }
    }
}
