﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public class UploadFileCommand : DropboxCommand
    {
        private String _FolderPath = "/";
        private Byte[] _FileData = new Byte[0];
        private String _ContentType = "application/octet-stream";
        private String _FileName = "";
        private Boolean _StatusInResponse = false;
        /// <summary>
        /// 
        /// </summary>
        public String FolderPath
        {
            get { return _FolderPath; }
            set { _FolderPath = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ContentType
        {
            get { return _ContentType; }
            set { _ContentType = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String FileName
        {
            get { return _FileName; }
            set { _FileName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean StatusInResponse
        {
            get { return _StatusInResponse; }
            set { _StatusInResponse = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public UploadFileCommand()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            return d;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static String GetBoundaryString()
        {
            return "UploadFileCommand_" + DateTime.Now.ToString("yyyyMMddHHmmss");
        }
#if !SILVERLIGHT
        /// <summary>
        /// 
        /// </summary>
        /// <param name="filePath"></param>
        public void LoadFileData(String filePath)
        {
            _FileData = File.ReadAllBytes(filePath);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="fileInfo"></param>
        public void LoadFileData(FileInfo fileInfo)
        {
            Byte[] bb = null;
            using (var r = new BinaryReader(fileInfo.OpenRead(), Encoding.UTF8))
            {
                bb = new Byte[fileInfo.Length];
                r.Read(bb, 0, bb.Length);
            }
            _FileData = bb;
        }
#endif
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        public void LoadFileData(Byte[] data)
        {
            _FileData = data;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Byte[] CreatePostData()
        {
            String boundary = UploadFileCommand.GetBoundaryString();
            return this.CreatePostData(boundary);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="boundary"></param>
        /// <returns></returns>
        public Byte[] CreatePostData(String boundary)
        {
            List<Byte> l = new List<Byte>();
            StringBuilder sb = new StringBuilder(1024);
            Encoding enc = Encoding.UTF8;

            sb.Append("--");
            sb.AppendLine(boundary);
            sb.AppendFormat("Content-Disposition: form-data; name=\"file\"; filename=\"{0}\"", this.FileName);
            sb.AppendLine();
            sb.Append("Content-Type: ");
            sb.AppendLine(this.ContentType);
            sb.AppendLine("Content-Transfer-Encoding: binary");
            sb.AppendLine();

            l.AddRange(enc.GetBytes(sb.ToString()));
            l.AddRange(_FileData);

            return l.ToArray();
        }
    }
}
