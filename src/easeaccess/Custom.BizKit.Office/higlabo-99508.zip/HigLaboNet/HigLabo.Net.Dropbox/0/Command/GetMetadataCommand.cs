﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public class GetMetadataCommand : DropboxCommand
    {
        private String _Path = "/";
        private String _Callback = "";
        private Int32 _FileLimit = 10000;
        private Boolean _List = true;
        private Boolean _StatusInResponse = false;
        /// <summary>
        /// 
        /// </summary>
        public String Path
        {
            get { return _Path; }
            set { _Path = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Callback
        {
            get { return _Callback; }
            set { _Callback = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 FileLimit
        {
            get { return _FileLimit; }
            set { _FileLimit = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean List
        {
            get { return _List; }
            set { _List = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean StatusInResponse
        {
            get { return _StatusInResponse; }
            set { _StatusInResponse = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public GetMetadataCommand()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected override IDictionary<string, string> CreateParameters()
        {
            Dictionary<String, String> d = new Dictionary<String, String>();
            d["callback"] = this.Callback;
            d["file_limit"] = this.FileLimit.ToString();
            d["list"] = this.List.ToString().ToLower();
            d["status_in_response"] = this.StatusInResponse.ToString().ToLower();
            return d;
        }
    }
}
