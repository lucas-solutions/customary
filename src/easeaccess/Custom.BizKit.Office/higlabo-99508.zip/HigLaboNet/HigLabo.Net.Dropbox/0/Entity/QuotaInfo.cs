﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public class QuotaInfo : ResponseObject
    {
        private Boolean _Shared = false;
        private Int32 _Quota = 0;
        private Int32 _Normal = 0;
        /// <summary>
        /// 
        /// </summary>
        public Boolean Shared
        {
            get { return _Shared; }
            set { _Shared = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Quota
        {
            get { return _Quota; }
            set { _Quota = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Normal
        {
            get { return _Normal; }
            set { _Normal = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public QuotaInfo(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);
            this.Shared = d.ToBoolean("shared") ?? this.Shared;
            this.Quota = d.ToInt32("quota") ?? this.Quota;
            this.Normal = d.ToInt32("normal") ?? this.Normal;
        }
    }
}
