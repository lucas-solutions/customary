﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public class Metadata : ResponseObject
    {
        private Boolean _ThumbExists = false;
        private Int32 _Bytes = 0;
        private DateTimeOffset _Modified = DateTimeOffset.MinValue;
        private String _Path = "";
        private String _Hash = "";
        private String _Revision = "";
        private Boolean _IsDirectory = false;
        private String _Size = "";
        private String _Root = "";
        private String _Icon = "";
        private List<Metadata> _Contents = new List<Metadata>();
        /// <summary>
        /// 
        /// </summary>
        public Boolean ThumbExists
        {
            get { return _ThumbExists; }
            set { _ThumbExists = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Bytes
        {
            get { return _Bytes; }
            set { _Bytes = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset Modified
        {
            get { return _Modified; }
            set { _Modified = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Path
        {
            get { return _Path; }
            set { _Path = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Hash
        {
            get { return _Hash; }
            set { _Hash = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Revision
        {
            get { return _Revision; }
            set { _Revision = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IsDirectory
        {
            get { return _IsDirectory; }
            set { _IsDirectory = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Size
        {
            get { return _Size; }
            set { _Size = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Root
        {
            get { return _Root; }
            set { _Root = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Icon
        {
            get { return _Icon; }
            set { _Icon = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<Metadata> Contents
        {
            get { return _Contents; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Metadata()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Metadata(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);
            this.ThumbExists = d.ToBoolean("thumb_exists") ?? this.ThumbExists;
            this.Bytes = d.ToInt32("bytes") ?? this.Bytes;
            this.Modified = d.ToDateTimeOffset("modified") ?? this.Modified;
            this.Path = d.ToString("path");
            this.Hash = d.ToString("hash");
            this.Revision = d.ToString("revision");
            this.IsDirectory = d.ToBoolean("is_dir") ?? this.IsDirectory;
            this.Size = d.ToString("size");
            this.Root = d.ToString("root");
            this.Icon = d.ToString("icon");

            if (d.ContainsKey("contents") == true)
            {
                foreach (var rs in d["contents"] as JContainer)
                {
                    _Contents.Add(new Metadata(rs.ToString()));
                }
            }
        }
    }
}
