﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public class AccountInfo : ResponseObject
    {
        private String _ReferralLink = "";
        private String _DisplayName = "";
        private Int64 _Uid = 0;
        private String _Country = "";
        private String _EMail = "";
        private QuotaInfo _QuotaInfo = null;
        /// <summary>
        /// 
        /// </summary>
        public String ReferralLink
        {
            get { return _ReferralLink; }
            set { _ReferralLink = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String DisplayName
        {
            get { return _DisplayName; }
            set { _DisplayName = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int64 Uid
        {
            get { return _Uid; }
            set { _Uid = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Country
        {
            get { return _Country; }
            set { _Country = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String EMail
        {
            get { return _EMail; }
            set { _EMail = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public QuotaInfo QuotaInfo
        {
            get { return _QuotaInfo; }
            set { _QuotaInfo = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public AccountInfo(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);
            this.ReferralLink = d.ToString("referral_link");
            this.DisplayName = d.ToString("display_name");
            this.Uid = d.ToInt64("uid") ?? this.Uid;
            this.Country = d.ToString("country");
            this.EMail = d.ToString("email");
            this.QuotaInfo = new QuotaInfo(d.ToString("quota_info"));
        }
    }
}
