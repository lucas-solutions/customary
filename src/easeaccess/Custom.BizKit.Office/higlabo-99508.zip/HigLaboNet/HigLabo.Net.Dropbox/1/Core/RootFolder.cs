﻿
namespace HigLabo.Net.Dropbox
{
    /// <summary>
    /// 
    /// </summary>
    public enum RootFolder
    {
        /// <summary>
        /// 
        /// </summary>
        Dropbox, 
        /// <summary>
        /// 
        /// </summary>
        Sandbox
    }
}
