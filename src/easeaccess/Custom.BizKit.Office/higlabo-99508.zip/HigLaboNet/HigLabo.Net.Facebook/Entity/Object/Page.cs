﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Page : ResponseObject
    {
        private List<UserSports> _UserSports = new List<UserSports>();
        private List<IdName> _FavoriteTeams = new List<IdName>();
        private List<IdName> _FavoriteAthletes = new List<IdName>();
        private List<String> _InterestedIn = new List<String>();
        private List<IdName> _Languages = new List<IdName>();
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Link { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Category { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Likes { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Location Location { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Phone { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Checkins { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Picture { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Website { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 TalkingAboutCount { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String AccessToken { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IsPublished { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean IsCommunityPage { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Page()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Page(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);
            this.ID = d.ToString("id");
            this.Name = d.ToString("name");
            this.Link = d.ToString("link");
            this.Category = d.ToString("category");
            this.Likes = d.ToInt32("likes") ?? 0;
            if (d.ContainsKey("location") == true)
            {
                this.Location = new Location(d.ToString("location"));
            }
            this.Phone = d.ToString("phone");
            this.Checkins = d.ToInt32("checkins") ?? 0;
            this.Picture = d.ToString("picture");
            this.Website = d.ToString("website");
            this.TalkingAboutCount = d.ToInt32("talking_about_count") ?? 0;
            this.AccessToken = d.ToString("access_token");
            this.IsPublished = d.ToBoolean("is_published") ?? false;
            this.IsCommunityPage = d.ToBoolean("is_community_page") ?? false;
        }
    }
}
