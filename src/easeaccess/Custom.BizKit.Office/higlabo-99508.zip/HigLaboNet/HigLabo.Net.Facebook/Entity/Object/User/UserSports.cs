﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class UserSports : ResponseObject
    {
        private List<IdName> _With = new List<IdName>();
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<IdName> With
        {
            get { return _With; }
        }
        /// <summary>
        /// 
        /// </summary>
        public UserSports()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public UserSports(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.ID = d.ToString("id");
            this.Name = d.ToString("name");
            if (d.ContainsKey("with") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "with"))
                {
                    this.With.Add(new IdName(s));
                }
            }
        }
    }
}
