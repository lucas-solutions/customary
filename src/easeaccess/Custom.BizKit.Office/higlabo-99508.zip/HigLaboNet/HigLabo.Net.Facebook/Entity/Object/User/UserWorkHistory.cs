﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class UserWorkHistory : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public IdName Employer { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName Location { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName Position { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? StartDate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? EndDate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public UserWorkHistory()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public UserWorkHistory(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            if (d.ContainsKey("employer") == true)
            {
                this.Employer = new IdName(d["employer"].ToString());
            }
            if (d.ContainsKey("location") == true)
            {
                this.Location = new IdName(d["location"].ToString());
            }
            if (d.ContainsKey("position") == true)
            {
                this.Position = new IdName(d["position"].ToString());
            }
            if (d.ContainsKey("start_date") == true)
            {
                this.StartDate = d.ParseYearMonth("start_date");
            }
            if (d.ContainsKey("end_date") == true)
            {
                this.EndDate = d.ParseYearMonth("end_date");
            }
        }
    }
}
