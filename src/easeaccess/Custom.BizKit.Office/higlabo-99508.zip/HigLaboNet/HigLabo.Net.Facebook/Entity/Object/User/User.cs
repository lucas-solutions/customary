﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class User : ResponseObject
    {
        private List<UserSports> _UserSports = new List<UserSports>();
        private List<IdName> _FavoriteTeams = new List<IdName>();
        private List<IdName> _FavoriteAthletes = new List<IdName>();
        private List<String> _InterestedIn = new List<String>();
        private List<IdName> _Languages = new List<IdName>();
        private List<IdName> _InspirationalPeople = new List<IdName>();
        private List<User> _Friends = new List<User>();
        private List<Book> _Books = new List<Book>();
        private List<Album> _Albums = new List<Album>();
        private List<Movie> _Movies = new List<Movie>();
        private List<Music> _Musics = new List<Music>();
        private List<Television> _Televisions = new List<Television>();
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String FirstName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String MiddleName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String LastName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Gender { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Locale { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Link { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String UserName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName HomeTown { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName Location { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<IdName> FavoriteTeams
        {
            get { return _FavoriteTeams; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<IdName> FavoriteAthletes
        {
            get { return _FavoriteAthletes; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<UserSports> Sports
        {
            get { return _UserSports; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<IdName> Languages
        {
            get { return _Languages; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<IdName> InspirationalPeople
        {
            get { return _InspirationalPeople; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<String> InterestedIn
        {
            get { return _InterestedIn; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ThirdPartyID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Double? TimeZone { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset? UpdatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean? Verified { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Bio { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTime? Birthday { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String EMail { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public UserWork Work { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public UserEducation Education { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<User> Friends
        {
            get { return _Friends; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<Album> Albums
        {
            get { return _Albums; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<Book> Books
        {
            get { return _Books; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<Movie> Movies
        {
            get { return _Movies; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<Music> Musics
        {
            get { return _Musics; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<Television> Televisions
        {
            get { return _Televisions; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ProfileImageUrl
        {
            get { return GetProfileImageUrl(this.ID); }
        }
        /// <summary>
        /// 
        /// </summary>
        public User()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public User(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public static String GetProfileImageUrl(String userID)
        {
            return String.Format("http://graph.facebook.com/{0}/picture", userID);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);
            this.ID = d.ToString("id");
            this.Name = d.ToString("name");
            this.FirstName = d.ToString("first_name");
            this.MiddleName = d.ToString("middle_name");
            this.LastName = d.ToString("last_name");
            this.Gender = d.ToString("gender");
            this.Locale = d.ToString("locale");
            this.Link = d.ToString("link");
            this.UserName = d.ToString("username");
            this.ThirdPartyID = d.ToString("third_party_id");
            this.TimeZone = d.ToDouble("timezone");
            this.UpdatedTime = d.ToDateTimeOffset("updated_time");
            this.Verified = d.ToBoolean("verified");
            this.Bio = d.ToString("bio");
            this.Birthday = d.ToDateTime("birthday");
            this.EMail = d.ToString("email");
            
            if (d.ContainsKey("hometown") == true)
            {
                this.HomeTown = new IdName(d["hometown"].ToString());
            }
            if (d.ContainsKey("location") == true)
            {
                this.Location = new IdName(d["location"].ToString());
            }

            if (d.ContainsKey("friends") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "friends"))
                {
                    this.Friends.Add(new User(s));
                }
            }
            if (d.ContainsKey("albums") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "albums", "data"))
                {
                    this.Albums.Add(new Album(s));
                }
            }
            if (d.ContainsKey("books") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "books"))
                {
                    this.Books.Add(new Book(s));
                }
            }
            if (d.ContainsKey("movies") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "movies"))
                {
                    this.Movies.Add(new Movie(s));
                }
            }
            if (d.ContainsKey("music") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "music"))
                {
                    this.Musics.Add(new Music(s));
                }
            }
            if (d.ContainsKey("television") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "television"))
                {
                    this.Televisions.Add(new Television(s));
                }
            }

            if (d.ContainsKey("sports") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "sports"))
                {
                    this.Sports.Add(new UserSports(s));
                }
            }
            if (d.ContainsKey("favorite_teams") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "favorite_teams"))
                {
                    this.FavoriteTeams.Add(new IdName(s));
                }
            }
            if (d.ContainsKey("favorite_athletes") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "favorite_athletes"))
                {
                    this.FavoriteAthletes.Add(new IdName(s));
                }
            }
            if (d.ContainsKey("interested_in") == true)
            {
                foreach (var s in FacebookClient.CreateTextList(d, "interested_in"))
                {
                    this.InterestedIn.Add(s);
                }
            }
            if (d.ContainsKey("languages") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "languages"))
                {
                    this.Languages.Add(new IdName(s));
                }
            }
            if (d.ContainsKey("inspirational_people") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "inspirational_people"))
                {
                    this.InspirationalPeople.Add(new IdName(s));
                }
            }
        
            if (d.ContainsKey("work") == true)
            {
                this.Work = new UserWork(d["work"].ToString());
            }
            else
            {
                this.Work = new UserWork();
            }
            if (d.ContainsKey("education") == true)
            {
                this.Education = new UserEducation(d["education"].ToString());
            }
            else
            {
                this.Education = new UserEducation();
            }
        }
    }
}
