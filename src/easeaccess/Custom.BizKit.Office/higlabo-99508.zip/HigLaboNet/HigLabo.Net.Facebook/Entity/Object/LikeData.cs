﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class LikeData : ResponseObject
    {
        private List<IdName> _Users = new List<IdName>();
        /// <summary>
        /// 
        /// </summary>
        public List<IdName> Users
        {
            get { return _Users; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Paging Paging { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Count { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public LikeData()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public LikeData(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            foreach (var s in FacebookClient.CreateJsonTextList(d, "data"))
            {
                this.Users.Add(new IdName(s));
            }
            if (d.ContainsKey("paging") == true)
            {
                this.Paging = new Paging(d.ToString("paging"));
            }
            else
            {
                this.Paging = new Paging();
            }
            this.Count = d.ToInt32("count") ?? 0;
        }
    }
}
