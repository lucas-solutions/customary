﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Cover : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String CoverID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Source { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 OffsetY { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Cover()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Cover(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.CoverID = d.ToString("cover_id");
            this.Source = d.ToString("source");
            this.OffsetY = d.ToInt32("offset_y") ?? this.OffsetY;
        }
   }
}
