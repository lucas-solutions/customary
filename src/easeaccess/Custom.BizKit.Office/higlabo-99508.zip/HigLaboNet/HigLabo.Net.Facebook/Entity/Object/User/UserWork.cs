﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class UserWork : ResponseObject
    {
        private List<UserWorkHistory> _UserWorkHistory= new List<UserWorkHistory>();
        /// <summary>
        /// 
        /// </summary>
        public List<UserWorkHistory> UserWorkHistory
        {
            get { return _UserWorkHistory; }
        }
        /// <summary>
        /// 
        /// </summary>
        public UserWork()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public UserWork(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var cc = JsonConvert.DeserializeObject(jsonText) as JContainer;

            foreach (var s in FacebookClient.CreateJsonTextList(cc))
            {
                _UserWorkHistory.Add(new UserWorkHistory(s));
            }
        }
    }
}
