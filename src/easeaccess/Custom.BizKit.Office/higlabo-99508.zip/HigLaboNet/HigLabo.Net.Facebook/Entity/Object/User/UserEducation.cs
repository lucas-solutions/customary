﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class UserEducation : ResponseObject
    {
        private List<UserEducationHistory> _UserHistory = new List<UserEducationHistory>();
        /// <summary>
        /// 
        /// </summary>
        public List<UserEducationHistory> UserHistory
        {
            get { return _UserHistory; }
        }
        /// <summary>
        /// 
        /// </summary>
        public UserEducation()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public UserEducation(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var cc = JsonConvert.DeserializeObject(jsonText) as JContainer;

            foreach (var s in FacebookClient.CreateJsonTextList(cc))
            {
                _UserHistory.Add(new UserEducationHistory(s));
            }
        }
    }
}
