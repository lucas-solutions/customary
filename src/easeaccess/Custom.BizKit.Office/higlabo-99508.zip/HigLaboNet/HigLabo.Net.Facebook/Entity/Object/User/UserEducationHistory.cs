﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class UserEducationHistory : ResponseObject
    {
        private List<IdName> _Concentration = new List<IdName>();
        private List<IdName> _Classes = new List<IdName>();
        private List<IdName> _With = new List<IdName>();
        /// <summary>
        /// 
        /// </summary>
        public IdName School { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName Year { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Type { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<IdName> Concentration
        {
            get { return _Concentration; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<IdName> Classes
        {
            get { return _Classes; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<IdName> With
        {
            get { return _With; }
        }
        /// <summary>
        /// 
        /// </summary>
        public UserEducationHistory()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public UserEducationHistory(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            if (d.ContainsKey("school") == true)
            {
                this.School = new IdName(d["school"].ToString());
            }
            if (d.ContainsKey("year") == true)
            {
                this.Year = new IdName(d["year"].ToString());
            }
            this.Type = d["type"].ToString();

            if (d.ContainsKey("concentration") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "concentration"))
                {
                    this.Concentration.Add(new IdName(s));
                }
            }
            if (d.ContainsKey("classes") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "classes"))
                {
                    this.Classes.Add(new IdName(s));
                }
            }
            if (d.ContainsKey("with") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "with"))
                {
                    this.Classes.Add(new IdName(s));
                }
            }

        }
    }
}
