﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Paging : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Previous { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Next { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Paging()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Paging(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.Previous = d.ToString("previous");
            this.Next = d.ToString("next");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="mode"></param>
        /// <returns></returns>
        public String GetUrl(PagingMode mode)
        {
            switch (mode)
            {
                case PagingMode.Previous: return this.Previous;
                case PagingMode.Next: return this.Next;
                default: throw new InvalidOperationException();
            }
        }
    }
}
