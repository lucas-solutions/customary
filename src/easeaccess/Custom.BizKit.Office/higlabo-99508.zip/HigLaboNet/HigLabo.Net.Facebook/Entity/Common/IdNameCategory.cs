﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class IdNameCategory : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Category { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdNameCategory()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public IdNameCategory(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.ID = d.ToString("id");
            this.Name = d.ToString("name");
            this.Category = d.ToString("category");
        }
    }
}
