﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Tag : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32? Offset { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32? Length { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ObjectType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Tag()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Tag(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.ID = d.ToString("id");
            this.Name = d.ToString("name");
            this.Offset = d.ToInt32("offset");
            this.Length = d.ToInt32("length");
            this.ObjectType = d.ToString("type");
        }
    }
}
