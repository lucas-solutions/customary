﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class FqlResultRecord : Dictionary<String, Object>
    {
        /// <summary>
        /// 
        /// </summary>
        public String JsonText { get; private set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public FqlResultRecord(String jsonText)
        {
            this.JsonText = jsonText;
            var d = JsonConvert.DeserializeObject<Dictionary<String, Object>>(jsonText);
            foreach (var key in d.Keys)
            {
                this[key] = d[key];
            }
        }
    }
}
