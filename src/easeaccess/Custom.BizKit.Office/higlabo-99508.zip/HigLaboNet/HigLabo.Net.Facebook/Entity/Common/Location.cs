﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Location : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Country { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String State { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String City { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Street { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Zip { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Double? Latitude { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Double? Longitude { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Location()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Location(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.Country = d.ToString("country");
            this.State = d.ToString("state");
            this.City = d.ToString("city");
            this.Street = d.ToString("street");
            this.Zip = d.ToString("zip");
            this.Latitude = d.ToDouble("latitude");
            this.Longitude = d.ToDouble("longitude");
        }
    }
}
