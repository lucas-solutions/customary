﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class FqlResult
    {
        private List<FqlResultRecord> _Records = new List<FqlResultRecord>();
        /// <summary>
        /// 
        /// </summary>
        public String JsonText { get; private set; }
        /// <summary>
        /// 
        /// </summary>
        public List<FqlResultRecord> Records
        {
            get { return _Records; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public FqlResult(String jsonText)
        {
            this.JsonText = jsonText;
            var d = JsonConvert.DeserializeObject<Dictionary<String, Object>>(jsonText);
            foreach (var s in FacebookClient.CreateJsonTextList(d, "data"))
            {
                this._Records.Add(new FqlResultRecord(s));
            }
        }
    }
}
