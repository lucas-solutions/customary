﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Privacy : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Description { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Privacy()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Privacy(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.Description = d.ToString("description");
            this.Value = d.ToString("value");
        }
    }
}
