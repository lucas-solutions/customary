﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public enum FacebookConnetionType
    {
        /// <summary>
        /// 
        /// </summary>
        Accounts,
        /// <summary>
        /// 
        /// </summary>
        Albums,
        /// <summary>
        /// 
        /// </summary>
        Activities,
        /// <summary>
        /// 
        /// </summary>
        AdAccounts,
        /// <summary>
        /// 
        /// </summary>
        AppRequests,
        /// <summary>
        /// 
        /// </summary>
        Books,
        /// <summary>
        /// 
        /// </summary>
        Checkins,
        /// <summary>
        /// 
        /// </summary>
        Comments,
        /// <summary>
        /// 
        /// </summary>
        Coupons,
        /// <summary>
        /// 
        /// </summary>
        Events,
        /// <summary>
        /// 
        /// </summary>
        Family,
        /// <summary>
        /// 
        /// </summary>
        Feed,
        /// <summary>
        /// 
        /// </summary>
        FriendLists,
        /// <summary>
        /// 
        /// </summary>
        FriendRequests,
        /// <summary>
        /// 
        /// </summary>
        Friends,
        /// <summary>
        /// 
        /// </summary>
        Games,
        /// <summary>
        /// 
        /// </summary>
        Groups,
        /// <summary>
        /// 
        /// </summary>
        Home,
        /// <summary>
        /// 
        /// </summary>
        Inbox,
        /// <summary>
        /// 
        /// </summary>
        Interests,
        /// <summary>
        /// 
        /// </summary>
        LifeEvents,
        /// <summary>
        /// 
        /// </summary>
        Likes,
        /// <summary>
        /// 
        /// </summary>
        Links,
        /// <summary>
        /// 
        /// </summary>
        Movies,
        /// <summary>
        /// 
        /// </summary>
        Music,
        /// <summary>
        /// 
        /// </summary>
        MutualFriends,
        /// <summary>
        /// 
        /// </summary>
        Notes,
        /// <summary>
        /// 
        /// </summary>
        Notifications,
        /// <summary>
        /// 
        /// </summary>
        Outbox,
        /// <summary>
        /// 
        /// </summary>
        Payments,
        /// <summary>
        /// 
        /// </summary>
        Permissions,
        /// <summary>
        /// 
        /// </summary>
        Photos,
        /// <summary>
        /// 
        /// </summary>
        Picture,
        /// <summary>
        /// 
        /// </summary>
        Questions,
        /// <summary>
        /// 
        /// </summary>
        Scores,
        /// <summary>
        /// 
        /// </summary>
        Statuses,
        /// <summary>
        /// 
        /// </summary>
        Tagged,
        /// <summary>
        /// 
        /// </summary>
        Television,
        /// <summary>
        /// 
        /// </summary>
        Updates,
        /// <summary>
        /// 
        /// </summary>
        Videos,
    }
}
