﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Music : IdNameCategory
    {
        /// <summary>
        /// 
        /// </summary>
        public String Description { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean? IsCommunityPage { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean? IsPublished { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32? TalkingAboutCount { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32? WereHereCount { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String WebSite { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Link { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32? Likes { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset? CreatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Music()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Music(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.ID = d.ToString("id");
            this.Name = d.ToString("name");
            this.Description = d.ToString("description");
            this.IsCommunityPage = d.ToBoolean("is_community_page");
            this.IsPublished = d.ToBoolean("is_published");
            this.TalkingAboutCount = d.ToInt32("talking_about_count");
            this.WereHereCount = d.ToInt32("were_here_count");
            this.Category = d.ToString("category");
            this.Link = d.ToString("link");
            this.WebSite = d.ToString("website");
            this.Likes = d.ToInt32("likes");
            this.CreatedTime = d.ToDateTimeOffset("created_time");
        }
   }
}
