﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class TelevisionData : ResponseObject
    {
        private List<Television> _Televisions = new List<Television>();
        /// <summary>
        /// 
        /// </summary>
        public List<Television> Televisions
        {
            get { return _Televisions; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Paging Paging { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Count { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public TelevisionData()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public TelevisionData(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            foreach (var s in FacebookClient.CreateJsonTextList(d, "data"))
            {
                this.Televisions.Add(new Television(s));
            }
            if (d.ContainsKey("paging") == true)
            {
                this.Paging = new Paging(d.ToString("paging"));
            }
            else
            {
                this.Paging = new Paging();
            }
            this.Count = d.ToInt32("count") ?? 0;
        }
    }
}
