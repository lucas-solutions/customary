﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HigLabo.Net.Extensions;
using Newtonsoft.Json;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Post : ResponseObject
    {
        private List<PostAction> _Actions = new List<PostAction>();
        private List<IdName> _To = new List<IdName>();
        private List<IdName> _WithTags = new List<IdName>();
        private List<Tag> _StoryTags = new List<Tag>();
        /// <summary>
        /// 
        /// </summary>
        public String ObjectType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int64 ObjectID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName From { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String StatusType { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Picture { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Link { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Caption { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Description { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Source { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Icon { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<PostAction> Actions
        {
            get { return _Actions; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<IdName> To
        {
            get { return _To; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<IdName> WithTags
        {
            get { return _WithTags; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<Tag> StoryTags
        {
            get { return _StoryTags; }
        }
        /// <summary>
        /// 
        /// </summary>
        public LikeData Likes { get; private set; }
        /// <summary>
        /// 
        /// </summary>
        public CommentData Comments { get; private set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName Application { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Privacy Privacy { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset CreatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset UpdatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Targeting { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Story { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Place Place { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Post()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Post(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.ID = d.ToString("id");
            this.ObjectID = d.ToInt64("object_id") ?? 0;
            if (d.ContainsKey("from") == true)
            {
                this.From = new IdName(d.ToString("from"));
            }
            this.Message = d.ToString("message");
            this.Status = d.ToString("status");
            this.StatusType = d.ToString("status_type");
            this.Picture = d.ToString("picture");
            this.Link = d.ToString("link");
            this.Name = d.ToString("name");
            this.Caption = d.ToString("caption");
            this.Description = d.ToString("description");
            this.Source = d.ToString("source");
            //this.Properties = d.ToString("properties");
            this.Icon = d.ToString("icon");
            this.Story = d.ToString("story");
            if (d.ContainsKey("to") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "to", "data"))
                {
                    this.To.Add(new IdName(s));
                }
            }
            if (d.ContainsKey("with_tags") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "with_tags", "data"))
                {
                    this.WithTags.Add(new IdName(s));
                }
            }
            if (d.ContainsKey("actions") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "actions"))
                {
                    this.Actions.Add(new PostAction(s));
                }
            }
            if (d.ContainsKey("story_tags") == true)
            {
                foreach (var s in FacebookClient.CreateTagJsonTextList(d, "story_tags"))
                {
                    this.StoryTags.Add(new Tag(s));
                }
            }
            if (d.ContainsKey("likes") == true)
            {
                this.Likes = new LikeData(d["likes"].ToString());
            }
            else
            {
                this.Likes = new LikeData();
            }
            if (d.ContainsKey("comments") == true)
            {
                this.Comments = new CommentData(d["comments"].ToString());
            }
            else
            {
                this.Comments = new CommentData();
            }
            if (d.ContainsKey("application") == true)
            {
                this.Application = new IdName(d.ToString("application"));
            }
            if (d.ContainsKey("privacy") == true)
            {
                this.Privacy = new Privacy(d.ToString("privacy"));
            }
            if (d.ContainsKey("place") == true)
            {
                this.Place = new Place(d.ToString("place"));
            }
            this.CreatedTime = d.ToDateTimeOffset("created_time") ?? DateTimeOffset.Now;
            this.UpdatedTime = d.ToDateTimeOffset("updated_time") ?? DateTimeOffset.Now;
            this.Targeting = d.ToString("targeting");

            this.ObjectType = d.ToString("type");
        }
    }
}
