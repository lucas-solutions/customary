﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class MusicData : ResponseObject
    {
        private List<Music> _Musics = new List<Music>();
        /// <summary>
        /// 
        /// </summary>
        public List<Music> Musics
        {
            get { return _Musics; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Paging Paging { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Count { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public MusicData()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public MusicData(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            foreach (var s in FacebookClient.CreateJsonTextList(d, "data"))
            {
                this.Musics.Add(new Music(s));
            }
            if (d.ContainsKey("paging") == true)
            {
                this.Paging = new Paging(d.ToString("paging"));
            }
            else
            {
                this.Paging = new Paging();
            }
            this.Count = d.ToInt32("count") ?? 0;
        }
    }
}
