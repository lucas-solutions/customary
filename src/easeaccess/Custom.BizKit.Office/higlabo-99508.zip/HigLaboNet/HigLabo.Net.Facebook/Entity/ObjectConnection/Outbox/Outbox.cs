﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HigLabo.Net.Extensions;
using Newtonsoft.Json;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Outbox : ResponseObject
    {
        private List<IdName> _SendTo = new List<IdName>();
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName From { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<IdName> SendTo
        {
            get { return _SendTo; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset UpdatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean UnRead { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean UnSeen { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public CommentData Comments { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Outbox()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Outbox(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.ID = d.ToString("id");
            if (d.ContainsKey("from") == true)
            {
                this.From = new IdName(d.ToString("from"));
            }
            this.Message = d.ToString("message");
            this.UpdatedTime = d.ToDateTimeOffset("updated_time") ?? DateTimeOffset.Now;
            if (d.ContainsKey("to") == true)
            {
                var dd = JsonConvert.DeserializeObject<Dictionary<String, Object>>(d.ToString("to"));
                foreach (var s in FacebookClient.CreateJsonTextList(dd, "data"))
                {
                    this.SendTo.Add(new IdName(s));
                }
            }
            if (d.ContainsKey("comments") == true)
            {
                this.Comments = new CommentData(d.ToString("comments"));
            }
            this.UnRead = d.ToString("unread") == "1";
            this.UnSeen = d.ToString("unseen") == "1";
        }
    }
}
