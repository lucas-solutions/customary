﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class NotificationData : GraphApiResponseData
    {
        private List<Notification> _NotificationList = new List<Notification>();
        /// <summary>
        /// 
        /// </summary>
        public List<Notification> NotificationList
        {
            get { return _NotificationList; }
        }
        /// <summary>
        /// 
        /// </summary>
        public NotificationData()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public NotificationData(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            foreach (String s in FacebookClient.CreateJsonTextList(d, "data"))
            {
                this.NotificationList.Add(new Notification(s));
            }
            this.Paging = new Paging(d.ToString("paging"));
        }
    }
}
