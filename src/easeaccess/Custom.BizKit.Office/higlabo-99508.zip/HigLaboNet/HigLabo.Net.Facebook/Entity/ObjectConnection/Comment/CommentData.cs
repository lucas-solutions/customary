﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class CommentData : ResponseObject
    {
        private List<Comment> _Comments = new List<Comment>();
        /// <summary>
        /// 
        /// </summary>
        public List<Comment> Comments
        {
            get { return _Comments; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Paging Paging { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Count { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public CommentData()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public CommentData(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            if (d.ContainsKey("data") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "data"))
                {
                    this.Comments.Add(new Comment(s));
                }
            }
            if (d.ContainsKey("paging") == true)
            {
                this.Paging = new Paging(d.ToString("paging"));
            }
            else
            {
                this.Paging = new Paging();
            }
            this.Count = d.ToInt32("count") ?? 0;
        }
    }
}
