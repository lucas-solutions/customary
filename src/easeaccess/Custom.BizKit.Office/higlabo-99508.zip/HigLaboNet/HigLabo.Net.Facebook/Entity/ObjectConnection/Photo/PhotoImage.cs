﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class PhotoImage : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String Source { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Height { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Width { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public PhotoImage()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public PhotoImage(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.Source = d.ToString("source");
            this.Height = d.ToInt32("height", new ResponseObjectParseException("height"));
            this.Width = d.ToInt32("width", new ResponseObjectParseException("width"));
        }
    }
}
