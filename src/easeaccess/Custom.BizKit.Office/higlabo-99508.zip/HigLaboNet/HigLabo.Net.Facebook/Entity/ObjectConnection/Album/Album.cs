﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Album : ResponseObject
    {
        private List<Photo> _Photos = new List<Photo>();
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName From { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Picture { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Source { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32? Height { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32? Width { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Photo> Photos
        {
            get { return _Photos; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String Link { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Icon { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset? CreatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset? UpdatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Album()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Album(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.ID = d.ToString("id");
            this.From = new IdName(d.ToString("from"));
            this.Name = d.ToString("name");
            this.Picture = d.ToString("picture");
            this.Source = d.ToString("source");
            this.Height = d.ToInt32("height");
            this.Width = d.ToInt32("width");
            this.Link = d.ToString("link");
            this.Icon = d.ToString("icon");
            this.CreatedTime = d.ToDateTimeOffset("created_time");
            this.UpdatedTime = d.ToDateTimeOffset("updated_time");

            if (d.ContainsKey("photos") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "photos", "data"))
                {
                    this.Photos.Add(new Photo(s));
                }
            }
        }
    }
}
