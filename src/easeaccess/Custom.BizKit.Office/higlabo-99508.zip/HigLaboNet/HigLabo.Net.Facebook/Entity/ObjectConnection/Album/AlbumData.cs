﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class AlbumData : ResponseObject
    {
        private List<Album> _Albums = new List<Album>();
        /// <summary>
        /// 
        /// </summary>
        public List<Album> Albums
        {
            get { return _Albums; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Paging Paging { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32 Count { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public AlbumData()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public AlbumData(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            foreach (var s in FacebookClient.CreateJsonTextList(d, "data"))
            {
                this.Albums.Add(new Album(s));
            }
            if (d.ContainsKey("paging") == true)
            {
                this.Paging = new Paging(d.ToString("paging"));
            }
            else
            {
                this.Paging = new Paging();
            }
            this.Count = d.ToInt32("count") ?? 0;
        }
    }
}
