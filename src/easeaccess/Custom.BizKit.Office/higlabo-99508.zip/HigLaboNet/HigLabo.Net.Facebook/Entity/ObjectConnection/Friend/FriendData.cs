﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class FriendData : GraphApiResponseData
    {
        private List<User> _FirendList = new List<User>();
        /// <summary>
        /// 
        /// </summary>
        public List<User> FirendList
        {
            get { return _FirendList; }
        }
        /// <summary>
        /// 
        /// </summary>
        public FriendData()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public FriendData(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            foreach (String s in FacebookClient.CreateJsonTextList(d, "data"))
            {
                this.FirendList.Add(new User(s));
            }
            this.Paging = new Paging(d.ToString("paging"));
        }
    }
}
