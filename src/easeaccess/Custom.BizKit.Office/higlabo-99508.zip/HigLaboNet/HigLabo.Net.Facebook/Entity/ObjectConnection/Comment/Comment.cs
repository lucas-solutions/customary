﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Comment : ResponseObject
    {
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName From { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset? CreatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32? Likes { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean? CanRemove { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean? UserLikes { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Comment()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Comment(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.ID = d.ToString("id");
            this.From = new IdName(d.ToString("from"));
            this.Message = d.ToString("message");
            this.CanRemove = d.ToBoolean("can_remove");
            this.CreatedTime = d.ToDateTimeOffset("created_time");
            this.Likes = d.ToInt32("likes");
            this.UserLikes = d.ToBoolean("user_likes");
        }
    }
}
