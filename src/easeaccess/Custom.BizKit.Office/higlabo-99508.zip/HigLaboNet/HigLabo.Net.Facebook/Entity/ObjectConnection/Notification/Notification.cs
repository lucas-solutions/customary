﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HigLabo.Net.Extensions;
using Newtonsoft.Json;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Notification : ResponseObject
    {
        private List<IdName> _SendTo = new List<IdName>();
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName From { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName SendTo { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName Application { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Title { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Link { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset CreatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset UpdatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Boolean UnRead { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Notification()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Notification(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.ID = d.ToString("id");
            if (d.ContainsKey("from") == true)
            {
                this.From = new IdName(d.ToString("from"));
            }
            if (d.ContainsKey("to") == true)
            {
                this.SendTo = new IdName(d.ToString("to"));
            }
            this.CreatedTime = d.ToDateTimeOffset("created_time", new ResponseObjectParseException("created_time"));
            this.UpdatedTime = d.ToDateTimeOffset("updated_time", new ResponseObjectParseException("updated_time"));
            this.Title = d.ToString("title");
            this.Message = d.ToString("message");
            this.Link = d.ToString("link");
            if (d.ContainsKey("application") == true)
            {
                this.Application = new IdName(d.ToString("application"));
            }
            this.UnRead = d.ToString("unread") == "1";
        }
    }
}
