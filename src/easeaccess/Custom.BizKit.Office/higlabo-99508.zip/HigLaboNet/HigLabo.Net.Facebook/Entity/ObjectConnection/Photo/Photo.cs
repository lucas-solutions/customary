﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Photo : ResponseObject
    {
        private List<PhotoImage> _Images = new List<PhotoImage>();
        private List<Tag> _NameTags = new List<Tag>();
        /// <summary>
        /// 
        /// </summary>
        public String ID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public IdName From { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Icon { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Link { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<Tag> NameTags
        {
            get { return _NameTags; }
        }
        /// <summary>
        /// 
        /// </summary>
        public List<PhotoImage> Images
        {
            get { return _Images; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String PageStoryID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Picture { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Place Place { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Source { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32? Height { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32? Width { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset? CreatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DateTimeOffset? UpdatedTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Photo()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public Photo(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            this.ID = d.ToString("id");
            this.From = new IdName(d.ToString("from"));
            this.Icon = d.ToString("icon");
            this.Link = d.ToString("link");
            this.Name = d.ToString("name");
            this.PageStoryID = d.ToString("page_story_id");
            this.Picture = d.ToString("picture");
            this.Source = d.ToString("source");
            this.Height = d.ToInt32("height");
            this.Width = d.ToInt32("width");
            if (d.ContainsKey("name_tags") == true)
            {
                foreach (var s in FacebookClient.CreateTagJsonTextList(d, "name_tags"))
                {
                    this.NameTags.Add(new Tag(s));
                }
            }
            if (d.ContainsKey("images") == true)
            {
                foreach (var s in FacebookClient.CreateJsonTextList(d, "images"))
                {
                    this.Images.Add(new PhotoImage(s));
                }
            }

            if (d.ContainsKey("place") == true)
            {
                this.Place = new Place(d.ToString("plage"));
            }
            else
            {
                this.Place = new Place();
            }
        }
    }
}
