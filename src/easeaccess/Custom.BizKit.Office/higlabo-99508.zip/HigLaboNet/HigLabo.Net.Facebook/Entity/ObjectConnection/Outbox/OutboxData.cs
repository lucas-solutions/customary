﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class OutboxData : GraphApiResponseData
    {
        private List<Outbox> _OutboxList = new List<Outbox>();
        /// <summary>
        /// 
        /// </summary>
        public List<Outbox> OutboxList
        {
            get { return _OutboxList; }
        }
        /// <summary>
        /// 
        /// </summary>
        public OutboxData()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public OutboxData(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            foreach (String s in FacebookClient.CreateJsonTextList(d, "data"))
            {
                this.OutboxList.Add(new Outbox(s));
            }
            this.Paging = new Paging(d.ToString("paging"));
        }
    }
}
