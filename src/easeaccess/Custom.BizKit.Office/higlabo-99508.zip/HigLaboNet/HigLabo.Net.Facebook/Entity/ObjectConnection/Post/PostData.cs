﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class PostData : GraphApiResponseData
    {
        private List<Post> _PostList = new List<Post>();
        /// <summary>
        /// 
        /// </summary>
        public List<Post> PostList
        {
            get { return _PostList; }
        }
        /// <summary>
        /// 
        /// </summary>
        public PostData()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public PostData(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            foreach (String s in FacebookClient.CreateJsonTextList(d, "data"))
            {
                this.PostList.Add(new Post(s));
            }
            this.Paging = new Paging(d.ToString("paging"));
        }
    }
}
