﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class InboxData : GraphApiResponseData
    {
        private List<Inbox> _InboxList = new List<Inbox>();
        /// <summary>
        /// 
        /// </summary>
        public List<Inbox> InboxList
        {
            get { return _InboxList; }
        }
        /// <summary>
        /// 
        /// </summary>
        public InboxData()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public InboxData(String jsonText)
        {
            this.SetProperty(jsonText);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="jsonText"></param>
        public override void SetProperty(String jsonText)
        {
            var d = this.SetData(jsonText);

            foreach (String s in FacebookClient.CreateJsonTextList(d, "data"))
            {
                this.InboxList.Add(new Inbox(s));
            }
            this.Paging = new Paging(d.ToString("paging"));
        }
    }
}
