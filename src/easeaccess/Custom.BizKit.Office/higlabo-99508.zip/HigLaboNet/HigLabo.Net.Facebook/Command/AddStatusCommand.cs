﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class AddStatusCommand : FacebookCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public override string GraphApiPath
        {
            get { return this.ObjectID + "/feed"; }
        }
        /// <summary>
        /// 
        /// </summary>
        public override bool HasData
        {
            get { return true; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ObjectID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public AddStatusCommand()
        {
            this.ObjectID = "me";
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        public AddStatusCommand(String id)
        {
            this.ObjectID = id;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override Dictionary<String, String> CreateDictionary()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();

            d["message"] = this.Message;

            return d;
        }
    }
}
