﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class FacebookCommand
    {
        private String _GraphApiPath = "";
        private Dictionary<String, String> _Data = null;
        private FieldCollection _Fields = new FieldCollection();
        /// <summary>
        /// 
        /// </summary>
        public virtual String GraphApiPath
        {
            get { return _GraphApiPath; }
            set { _GraphApiPath = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public virtual Boolean HasData
        {
            get { return false; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Dictionary<String, String> Data
        {
            get { return null; }
            protected set { _Data = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public FieldCollection Fields
        {
            get { return _Fields; }
        }
        /// <summary>
        /// 
        /// </summary>
        public Int32? Limit { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public FacebookCommand()
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="graphApiPath"></param>
        public FacebookCommand(String graphApiPath)
        {
            this.GraphApiPath = graphApiPath;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public virtual Dictionary<String, String> CreateDictionary()
        {
            return null;
        }
    }
}
