﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class Field
    {
        private FieldCollection _Fields = new FieldCollection();
        /// <summary>
        /// 
        /// </summary>
        public String Value { get; private set; }
        /// <summary>
        /// 
        /// </summary>
        public Int32? Limit { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public FieldCollection Fields
        {
            get { return _Fields; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        public Field(String value)
        {
            this.Value = value;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <param name="limit"></param>
        /// <param name="fields"></param>
        public Field(String value, Int32? limit, params String[] fields)
        {
            this.Value = value;
            this.Limit = limit;
            for (int i = 0; i < fields.Length; i++)
            {
                this.Fields.Add(fields[i]);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public String CreateQueryStringValue()
        {
            if (this.Fields.Count == 0) { return this.Value; }
            StringBuilder sb = new StringBuilder(256);
            sb.Append(this.Value);
            if (this.Limit.HasValue == true)
            {
                sb.AppendFormat(".limit({0})", this.Limit);
            }
            sb.Append(".fields(");
            for (int i = 0; i < this.Fields.Count; i++)
            {
                sb.Append(this.Fields[i].CreateQueryStringValue());
                if (i < this.Fields.Count - 1)
                {
                    sb.Append(",");
                }
            }
            sb.Append(")");

            return sb.ToString();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return this.CreateQueryStringValue();
        }
    }
}
