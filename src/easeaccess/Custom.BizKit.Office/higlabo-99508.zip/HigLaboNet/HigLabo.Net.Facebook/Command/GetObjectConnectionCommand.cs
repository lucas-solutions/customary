﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Facebook
{
    public partial class FacebookClient
    {
        /// <summary>
        /// 
        /// </summary>
        private class GetObjectConnectionCommand : FacebookCommand
        {
            /// <summary>
            /// 
            /// </summary>
            public override string GraphApiPath
            {
                get { return String.Format("{0}/{1}", this.ObjectID, this.ConnectionType.ToString().ToLower()); }
            }
            /// <summary>
            /// 
            /// </summary>
            public String ObjectID { get; set; }
            /// <summary>
            /// 
            /// </summary>
            public FacebookConnetionType ConnectionType { get; set; }
            public GetObjectConnectionCommand(GetObjectCommand command, FacebookConnetionType connectionType)
            {
                this.ObjectID = command.ObjectID;
                this.ConnectionType = connectionType;
                this.Limit = command.Limit;
                for (int i = 0; i < command.Fields.Count; i++)
                {
                    this.Fields.Add(command.Fields[i]);
                }
            }
            /// <summary>
            /// 
            /// </summary>
            /// <param name="id"></param>
            /// <param name="connectionType"></param>
            public GetObjectConnectionCommand(String id, FacebookConnetionType connectionType)
            {
                this.ObjectID = id;
                this.ConnectionType = connectionType;
            }
        }
    }
}
