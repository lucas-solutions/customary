﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class AddCommentCommand : FacebookCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public override string GraphApiPath
        {
            get { return this.ObjectID + "/comments"; }
        }
        /// <summary>
        /// 
        /// </summary>
        public override bool HasData
        {
            get { return true; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ObjectID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public String Message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        public AddCommentCommand(String id)
        {
            this.ObjectID = id;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override Dictionary<String, String> CreateDictionary()
        {
            Dictionary<String, String> d = new Dictionary<string, string>();

            d["message"] = this.Message;

            return d;
        }
    }
}
