﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class FieldCollection : List<Field>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        public void Add(String value)
        {
            this.Add(new Field(value));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <param name="limit"></param>
        /// <param name="fields"></param>
        public void Add(String value, Int32? limit, params String[] fields)
        {
            this.Add(new Field(value, limit, fields));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < this.Count; i++)
            {
                sb.Append(this[i].CreateQueryStringValue());
                if (i < this.Count - 1)
                {
                    sb.Append(",");
                }
            }
            return sb.ToString();
        }
    }
}
