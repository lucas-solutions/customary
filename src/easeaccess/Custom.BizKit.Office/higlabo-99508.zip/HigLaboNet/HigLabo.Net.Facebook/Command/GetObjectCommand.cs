﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class GetObjectCommand : FacebookCommand
    {
        /// <summary>
        /// 
        /// </summary>
        public override string GraphApiPath
        {
            get { return this.ObjectID; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String ObjectID { get; set; }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        public GetObjectCommand(String id)
        {
            this.ObjectID = id;
        }
    }
}
