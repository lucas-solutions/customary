﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public class FacebookApiUrl
    {
        /// <summary>
        /// 
        /// </summary>
        public class OAuth
        {
            /// <summary>
            /// 
            /// </summary>
            public static readonly String RequestToken = "graph.facebook.com/oauth/request_token";
            /// <summary>
            /// 
            /// </summary>
            public static readonly String AuthorizeToken = "graph.facebook.com/oauth/authorize";
            /// <summary>
            /// 
            /// </summary>
            public static readonly String AccessToken = "graph.facebook.com/oauth/access_token";
        }
    }
}
