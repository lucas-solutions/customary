﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using HigLabo.Net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net;
using HigLabo.Net.Extensions;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public partial class FacebookClient : HttpClient
    {
        /// <summary>
        /// 
        /// </summary>
        public class RegexList
        {
            ///<summary>
            /// 
            ///</summary>
            public static readonly Regex OAuthToken = new Regex(@"code=([^&]*)");
        }
        private HttpProtocolType _Protocol = HttpProtocolType.Https;
        private String _AccessToken = "";
        /// <summary>
        /// 
        /// </summary>
        public HttpProtocolType Protocol
        {
            get { return _Protocol; }
        }
        /// <summary>
        /// 
        /// </summary>
        public String AccessToken
        {
            get { return _AccessToken; }
            set { _AccessToken = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="accessToken"></param>
        public FacebookClient(String accessToken)
        {
            _AccessToken = accessToken;
            this.ResponseEncoding = Encoding.UTF8;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="consumerSecret"></param>
        /// <returns></returns>
        public static OAuthClient CreateOAuthClient(String consumerKey, String consumerSecret)
        {
            var cl = new OAuthClient(consumerKey, consumerSecret
                , "https://" + FacebookApiUrl.OAuth.RequestToken
                , "https://" + FacebookApiUrl.OAuth.AuthorizeToken
                , "https://" + FacebookApiUrl.OAuth.AccessToken);
            return cl;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="redirectUrl"></param>
        /// <returns></returns>
        public static String CreateAuthorizeUrl(String consumerKey, String redirectUrl)
        {
            return CreateAuthorizeUrl(consumerKey, redirectUrl, new List<string>(), HttpClient.UrlEncode);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="callbackUrl"></param>
        /// <param name="scopes"></param>
        /// <returns></returns>
        public static String CreateAuthorizeUrl(String consumerKey, String callbackUrl, List<String> scopes)
        {
            return CreateAuthorizeUrl(consumerKey, callbackUrl, scopes, HttpClient.UrlEncode);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="callbackUrl"></param>
        /// <param name="scopes"></param>
        /// <param name="urlEncodingFunction"></param>
        /// <returns></returns>
        public static String CreateAuthorizeUrl(String consumerKey, String callbackUrl, List<String> scopes, Func<String, String> urlEncodingFunction)
        {
            var f = urlEncodingFunction;
            String baseUrl = String.Format("https://www.facebook.com/dialog/oauth?client_id={0}&redirect_uri={1}"
                , f(consumerKey), f(callbackUrl));
            if (scopes.Count == 0)
            {
                return baseUrl;
            }
            else
            {
                StringBuilder sb = new StringBuilder(256);
                sb.Append(baseUrl);
                sb.Append("&scope=");
                for (int i = 0; i < scopes.Count; i++)
                {
                    sb.Append(f(scopes[i]));
                    if (i < scopes.Count - 1)
                    {
                        sb.Append(",");
                    }
                }
                return sb.ToString();
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="consumerKeySecret"></param>
        /// <param name="redirectUri"></param>
        /// <param name="code"></param>
        /// <returns></returns>
        public static String CreateAccessTokenUrl(String consumerKey, String consumerKeySecret, String redirectUri, String code)
        {
            return CreateAccessTokenUrl(consumerKey, consumerKeySecret, redirectUri, code, HttpClient.UrlEncode);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="consumerKeySecret"></param>
        /// <param name="redirectUri"></param>
        /// <param name="code"></param>
        /// <param name="urlEncodingFunction"></param>
        /// <returns></returns>
        public static String CreateAccessTokenUrl(String consumerKey, String consumerKeySecret, String redirectUri, String code
            , Func<String, String> urlEncodingFunction)
        {
            var f = urlEncodingFunction;
            return String.Format("https://graph.facebook.com/oauth/access_token?client_id={0}&client_secret={1}&redirect_uri={2}&code={3}"
                , f(consumerKey), f(consumerKeySecret), f(redirectUri), f(code));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="consumerKeySecret"></param>
        /// <param name="redirectUri"></param>
        /// <param name="code"></param>
        /// <param name="callback"></param>
        public static void GetAccessToken(String consumerKey, String consumerKeySecret, String redirectUri, String code
            , Action<AccessTokenInfo> callback)
        {
            String url = CreateAccessTokenUrl(consumerKey, consumerKeySecret, redirectUri, code);
            var cl = new HttpClient();
            cl.ResponseEncoding = Encoding.UTF8;

            var cm = new HttpRequestCommand(url);
            cl.GetBodyText(cm, text =>
            {
                var t = AccessTokenInfo.Create(text, "access_token", "");
                callback(t);
            });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public HttpRequestCommand CreateCommand(HttpMethodName methodName, FacebookCommand command)
        {
            StringBuilder sb = new StringBuilder(256);
            String url = String.Format("https://graph.facebook.com/{0}?access_token={1}&limit={2}&fields=", command.GraphApiPath, this.AccessToken, command.Limit);

            if (command.Fields.Count > 0)
            {
                for (int i = 0; i < command.Fields.Count; i++)
                {
                    sb.Append(command.Fields[i].CreateQueryStringValue());
                    if (i < command.Fields.Count - 1)
                    {
                        sb.Append(",");
                    }
                }
            }
            url = url + HttpClient.UrlEncode(sb.ToString());
            if (command.HasData == true)
            {
                return this.CreateCommand(methodName, url, command.CreateDictionary());
            }
            else
            {
                return this.CreateCommand(methodName, url);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="url"></param>
        /// <returns></returns>
        public HttpRequestCommand CreateCommand(HttpMethodName methodName, String url)
        {
            return this.CreateCommand(methodName, url, null);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="url"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public HttpRequestCommand CreateCommand(HttpMethodName methodName, String url, Dictionary<String, String> data)
        {
            var cm = new HttpRequestCommand(url);
            cm.MethodName = methodName;
            if (data != null)
            {
                cm.SetBodyStream(new HttpBodyFormUrlEncodedData(Encoding.UTF8, data));
            }
            if (cm.MethodName != HttpMethodName.Get)
            {
                cm.IsSendBodyStream = true;
            }
            return cm;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static List<String> CreateJsonTextList(Dictionary<String, Object> data, String key)
        {
            if (data.ContainsKey(key) == false) { return new List<String>(); }
            var c = data[key] as JContainer;
            if (c == null) { return new List<string>(); }
            return CreateJsonTextList(c);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="key1"></param>
        /// <param name="key2"></param>
        /// <returns></returns>
        public static List<String> CreateJsonTextList(Dictionary<String, Object> data, String key1, String key2)
        {
            if (data.ContainsKey(key1) == false) { return new List<String>(); }
            var d = JsonConvert.DeserializeObject<Dictionary<String, Object>>(data[key1].ToString());
            return CreateJsonTextList(d, key2);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="container"></param>
        /// <returns></returns>
        public static List<String> CreateJsonTextList(JContainer container)
        {
            List<String> l = new List<string>();

            foreach (Object o in container)
            {
                l.Add(o.ToString());
            }
            return l;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static List<String> CreateTextList(Dictionary<String, Object> data, String key)
        {
            if (data.ContainsKey(key) == false) { return new List<String>(); }
            var c = data[key] as JContainer;
            if (c == null) { return new List<string>(); }
            return CreateTextList(c);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="container"></param>
        /// <returns></returns>
        public static List<String> CreateTextList(JContainer container)
        {
            List<String> l = new List<string>();
            JValue v = null;

            foreach (Object o in container)
            {
                v = o as JValue;
                if (v != null && v.Type == JTokenType.String)
                {
                    l.Add(v.Value.ToString());
                }
                else
                {
                    l.Add(o.ToString());
                }
            }
            return l;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static List<String> CreateTagJsonTextList(Dictionary<String, Object> data, String key)
        {
            List<String> l = new List<string>();
            var dd = JsonConvert.DeserializeObject<Dictionary<String, Object>>(data.ToString(key));
            foreach (var tag in dd.Keys)
            {
                if (dd[tag] == null) { continue; }
                foreach (var s in FacebookClient.CreateJsonTextList(dd, tag))
                {
                    l.Add(s);
                }
            }
            return l;
        }
        private void GetBodyText(FacebookCommand command, Action<String> callback)
        {
            this.GetBodyText(HttpMethodName.Get, command, callback);
        }
        private void GetBodyText(HttpMethodName methodName, FacebookCommand command, Action<String> callback)
        {
            var cm = this.CreateCommand(methodName, command);
            this.GetBodyText(cm, callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetUser(Action<User> callback)
        {
            this.GetUser("me", callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetUser(String id, Action<User> callback)
        {
            this.GetBodyText(new GetObjectCommand(id), text => callback(new User(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetUser(GetObjectCommand command, Action<User> callback)
        {
            this.GetBodyText(command, text => callback(new User(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetPage(String id, Action<Page> callback)
        {
            this.GetBodyText(new GetObjectCommand(id), text => callback(new Page(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetPage(GetObjectCommand command, Action<Page> callback)
        {
            this.GetBodyText(command, text => callback(new Page(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetHome(Action<PostData> callback)
        {
            this.GetHome("me", callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetHome(String id, Action<PostData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(id, FacebookConnetionType.Home), text => callback(new PostData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetHome(GetObjectCommand command, Action<PostData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(command, FacebookConnetionType.Home), text => callback(new PostData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetFeed(Action<PostData> callback)
        {
            this.GetFeed("me", callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetFeed(String id, Action<PostData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(id, FacebookConnetionType.Feed), text => callback(new PostData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetFeed(GetObjectCommand command, Action<PostData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(command, FacebookConnetionType.Feed), text => callback(new PostData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetStatuses(Action<PostData> callback)
        {
            this.GetStatuses("me", callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetStatuses(String id, Action<PostData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(id, FacebookConnetionType.Statuses), text => callback(new PostData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetStatuses(GetObjectCommand command, Action<PostData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(command, FacebookConnetionType.Statuses), text => callback(new PostData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <param name="callback"></param>
        public void GetPostData(PostData data, PagingMode mode, Action<PostData> callback)
        {
            var url = data.Paging.GetUrl(mode);
            if (String.IsNullOrEmpty(url) == true) { return; }
            var cm = this.CreateCommand(HttpMethodName.Get, url);
            this.GetBodyText(cm, text => callback(new PostData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetLikes(String id, Action<LikeData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(id, FacebookConnetionType.Likes), text => callback(new LikeData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetLikes(GetObjectCommand command, Action<LikeData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(command, FacebookConnetionType.Likes), text => callback(new LikeData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <param name="callback"></param>
        public void GetLikes(LikeData data, PagingMode mode, Action<LikeData> callback)
        {
            var url = data.Paging.GetUrl(mode);
            if (String.IsNullOrEmpty(url) == true) { return; }
            var cm = this.CreateCommand(HttpMethodName.Get, url);
            this.GetBodyText(cm, text => callback(new LikeData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetComment(String id, Action<Comment> callback)
        {
            this.GetBodyText(new GetObjectCommand(id), text => callback(new Comment(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetComments(String id, Action<CommentData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(id, FacebookConnetionType.Comments), text => callback(new CommentData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetComments(GetObjectCommand command, Action<CommentData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(command, FacebookConnetionType.Comments), text => callback(new CommentData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <param name="callback"></param>
        public void GetComments(CommentData data, PagingMode mode, Action<CommentData> callback)
        {
            var url = data.Paging.GetUrl(mode);
            if (String.IsNullOrEmpty(url) == true) { return; }
            var cm = this.CreateCommand(HttpMethodName.Get, url);
            this.GetBodyText(cm, text => callback(new CommentData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetAlbum(String id, Action<Album> callback)
        {
            this.GetBodyText(new GetObjectCommand(id), text => callback(new Album(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetAlbums(String id, Action<AlbumData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(id, FacebookConnetionType.Albums), text => callback(new AlbumData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetAlbums(GetObjectCommand command, Action<AlbumData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(command, FacebookConnetionType.Albums), text => callback(new AlbumData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <param name="callback"></param>
        public void GetAlbums(AlbumData data, PagingMode mode, Action<AlbumData> callback)
        {
            var url = data.Paging.GetUrl(mode);
            if (String.IsNullOrEmpty(url) == true) { return; }
            var cm = this.CreateCommand(HttpMethodName.Get, url);
            this.GetBodyText(cm, text => callback(new AlbumData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetBook(String id, Action<Book> callback)
        {
            this.GetBodyText(new GetObjectCommand(id), text => callback(new Book(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetBooks(String id, Action<BookData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(id, FacebookConnetionType.Books), text => callback(new BookData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetBooks(GetObjectCommand command, Action<BookData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(command, FacebookConnetionType.Books), text => callback(new BookData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <param name="callback"></param>
        public void GetBooks(BookData data, PagingMode mode, Action<BookData> callback)
        {
            var url = data.Paging.GetUrl(mode);
            if (String.IsNullOrEmpty(url) == true) { return; }
            var cm = this.CreateCommand(HttpMethodName.Get, url);
            this.GetBodyText(cm, text => callback(new BookData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetMovie(String id, Action<Movie> callback)
        {
            this.GetBodyText(new GetObjectCommand(id), text => callback(new Movie(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetMovies(String id, Action<MovieData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(id, FacebookConnetionType.Movies), text => callback(new MovieData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetMovies(GetObjectCommand command, Action<MovieData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(command, FacebookConnetionType.Movies), text => callback(new MovieData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <param name="callback"></param>
        public void GetMovies(MovieData data, PagingMode mode, Action<MovieData> callback)
        {
            var url = data.Paging.GetUrl(mode);
            if (String.IsNullOrEmpty(url) == true) { return; }
            var cm = this.CreateCommand(HttpMethodName.Get, url);
            this.GetBodyText(cm, text => callback(new MovieData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetTelevision(String id, Action<Television> callback)
        {
            this.GetBodyText(new GetObjectCommand(id), text => callback(new Television(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetTelevisions(String id, Action<TelevisionData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(id, FacebookConnetionType.Television), text => callback(new TelevisionData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetTelevisions(GetObjectCommand command, Action<TelevisionData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(command, FacebookConnetionType.Television), text => callback(new TelevisionData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <param name="callback"></param>
        public void GetTelevisions(TelevisionData data, PagingMode mode, Action<TelevisionData> callback)
        {
            var url = data.Paging.GetUrl(mode);
            if (String.IsNullOrEmpty(url) == true) { return; }
            var cm = this.CreateCommand(HttpMethodName.Get, url);
            this.GetBodyText(cm, text => callback(new TelevisionData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetFriend(String id, Action<User> callback)
        {
            this.GetBodyText(new GetObjectCommand(id), text => callback(new User(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetFriends(Action<FriendData> callback)
        {
            this.GetFriends("me", callback);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void GetFriends(String id, Action<FriendData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(id, FacebookConnetionType.Friends), text => callback(new FriendData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void GetFriends(GetObjectCommand command, Action<FriendData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand(command, FacebookConnetionType.Friends), text => callback(new FriendData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <param name="callback"></param>
        public void GetFriends(FriendData data, PagingMode mode, Action<FriendData> callback)
        {
            var url = data.Paging.GetUrl(mode);
            if (String.IsNullOrEmpty(url) == true) { return; }
            var cm = this.CreateCommand(HttpMethodName.Get, url);
            this.GetBodyText(cm, text => callback(new FriendData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetNotifications(Action<NotificationData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand("me", FacebookConnetionType.Notifications), text => callback(new NotificationData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <param name="callback"></param>
        public void GetNotifications(NotificationData data, PagingMode mode, Action<NotificationData> callback)
        {
            var url = data.Paging.GetUrl(mode);
            if (String.IsNullOrEmpty(url) == true) { return; }
            var cm = this.CreateCommand(HttpMethodName.Get, url);
            this.GetBodyText(cm, text => callback(new NotificationData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetInbox(Action<InboxData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand("me", FacebookConnetionType.Inbox), text => callback(new InboxData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <param name="callback"></param>
        public void GetInbox(InboxData data, PagingMode mode, Action<InboxData> callback)
        {
            var url = data.Paging.GetUrl(mode);
            if (String.IsNullOrEmpty(url) == true) { return; }
            var cm = this.CreateCommand(HttpMethodName.Get, url);
            this.GetBodyText(cm, text => callback(new InboxData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="callback"></param>
        public void GetOutbox(Action<OutboxData> callback)
        {
            this.GetBodyText(new GetObjectConnectionCommand("me", FacebookConnetionType.Outbox), text => callback(new OutboxData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <param name="callback"></param>
        public void GetOutbox(OutboxData data, PagingMode mode, Action<OutboxData> callback)
        {
            var url = data.Paging.GetUrl(mode);
            if (String.IsNullOrEmpty(url) == true) { return; }
            var cm = this.CreateCommand(HttpMethodName.Get, url);
            this.GetBodyText(cm, text => callback(new OutboxData(text)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void Like(String id, Action<Boolean> callback)
        {
            var cm = new FacebookCommand(id + "/likes");
            this.GetBodyText(HttpMethodName.Post, cm, text => callback(String.Equals(text, "true", StringComparison.OrdinalIgnoreCase)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void UnLike(String id, Action<Boolean> callback)
        {
            var cm = new FacebookCommand(id + "/likes");
            this.GetBodyText(HttpMethodName.Delete, cm, text => callback(String.Equals(text, "true", StringComparison.OrdinalIgnoreCase)));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void AddComment(AddCommentCommand command, Action<String> callback)
        {
            this.GetBodyText(HttpMethodName.Post, command, text =>
            {
                var d = JsonConvert.DeserializeObject<Dictionary<String, Object>>(text);
                var id = d.ToString("id");
                callback(id);
            });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="callback"></param>
        public void AddStatus(AddStatusCommand command, Action<String> callback)
        {
            this.GetBodyText(HttpMethodName.Post, command, text =>
            {
                var d = JsonConvert.DeserializeObject<Dictionary<String, Object>>(text);
                var id = d.ToString("id");
                callback(id);
            });
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="callback"></param>
        public void DeleteObject(String id, Action<Boolean> callback)
        {
            var cm = new FacebookCommand(id);
            this.GetBodyText(HttpMethodName.Delete, cm, text => callback(String.Equals(text, "true", StringComparison.OrdinalIgnoreCase)));
        }
    }
}
