﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using HigLabo.Net.Extensions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;

namespace HigLabo.Net.Facebook
{
    /// <summary>
    /// 
    /// </summary>
    public partial class FacebookClient
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="func"></param>
        /// <returns></returns>
        protected new static Task<T> CreateNewTask<T>(Func<T> func)
        {
            return Task.Factory.StartNew<T>(func);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="consumerKeySecret"></param>
        /// <param name="redirectUri"></param>
        /// <param name="code"></param>
        /// <returns></returns>
        public static Task<AccessTokenInfo> GetAccessTokenAsync(String consumerKey, String consumerKeySecret, String redirectUri, String code)
        {
            return CreateNewTask<AccessTokenInfo>(() => GetAccessToken(consumerKey, consumerKeySecret, redirectUri, code));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="consumerKey"></param>
        /// <param name="consumerKeySecret"></param>
        /// <param name="redirectUri"></param>
        /// <param name="code"></param>
        /// <param name="urlEncodingFunction"></param>
        /// <returns></returns>
        public static Task<AccessTokenInfo> GetAccessTokenAsync(String consumerKey, String consumerKeySecret, String redirectUri, String code
            , Func<String, String> urlEncodingFunction)
        {
            return CreateNewTask<AccessTokenInfo>(() => GetAccessToken(consumerKey, consumerKeySecret, redirectUri, code, urlEncodingFunction));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<User> GetUserAsync()
        {
            return CreateNewTask<User>(() => GetUser());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<User> GetUserAsync(String id)
        {
            return CreateNewTask<User>(() => GetUser(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<User> GetUserAsync(GetObjectCommand command)
        {
            return CreateNewTask<User>(() => GetUser(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<Page> GetPageAsync(String id)
        {
            return CreateNewTask<Page>(() => GetPage(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Page> GetPageAsync(GetObjectCommand command)
        {
            return CreateNewTask<Page>(() => GetPage(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<PostData> GetHomeAsync()
        {
            return CreateNewTask<PostData>(() => GetHome());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<PostData> GetHomeAsync(String id)
        {
            return CreateNewTask<PostData>(() => GetHome(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<PostData> GetHomeAsync(GetObjectCommand command)
        {
            return CreateNewTask<PostData>(() => GetHome(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<PostData> GetFeedAsyc()
        {
            return CreateNewTask<PostData>(() => GetFeed());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<PostData> GetFeedAsyc(String id)
        {
            return CreateNewTask<PostData>(() => GetFeed(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<PostData> GetFeedAsyc(GetObjectCommand command)
        {
            return CreateNewTask<PostData>(() => GetFeed(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<PostData> GetStatusesAsync()
        {
            return CreateNewTask<PostData>(() => GetStatuses());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<PostData> GetStatusesAsync(String id)
        {
            return CreateNewTask<PostData>(() => GetStatuses(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<PostData> GetStatusesAsync(GetObjectCommand command)
        {
            return CreateNewTask<PostData>(() => GetStatuses(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public Task<PostData> GetPostDataAsync(PostData data, PagingMode mode)
        {
            return CreateNewTask<PostData>(() => GetPostData(data, mode));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<LikeData> GetLikesAsync(String id)
        {
            return CreateNewTask<LikeData>(() => GetLikes(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<LikeData> GetLikesAsync(GetObjectCommand command)
        {
            return CreateNewTask<LikeData>(() => GetLikes(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public Task<LikeData> GetLikesAsync(LikeData data, PagingMode mode)
        {
            return CreateNewTask<LikeData>(() => GetLikes(data, mode));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<Comment> GetCommentAsync(String id)
        {
            return CreateNewTask<Comment>(() => GetComment(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Comment> GetCommentAsync(GetObjectCommand command)
        {
            return CreateNewTask<Comment>(() => GetComment(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<CommentData> GetCommentsAsync(String id)
        {
            return CreateNewTask<CommentData>(() => GetComments(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<CommentData> GetCommentsAsync(GetObjectCommand command)
        {
            return CreateNewTask<CommentData>(() => GetComments(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public Task<CommentData> GetCommentsAsync(CommentData data, PagingMode mode)
        {
            return CreateNewTask<CommentData>(() => GetComments(data, mode));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<Book> GetBookAsync(String id)
        {
            return CreateNewTask<Book>(() => GetBook(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Book> GetBookAsync(GetObjectCommand command)
        {
            return CreateNewTask<Book>(() => GetBook(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<BookData> GetBooksAsync(String id)
        {
            return CreateNewTask<BookData>(() => GetBooks(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<BookData> GetBooksAsync(GetObjectCommand command)
        {
            return CreateNewTask<BookData>(() => GetBooks(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<MusicData> GetMusicAsync(String id)
        {
            return CreateNewTask<MusicData>(() => GetMusics(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<MusicData> GetMusicAsync(GetObjectCommand command)
        {
            return CreateNewTask<MusicData>(() => GetMusics(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<MusicData> GetMusicsAsync(String id)
        {
            return CreateNewTask<MusicData>(() => GetMusics(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<MusicData> GetMusicsAsync(GetObjectCommand command)
        {
            return CreateNewTask<MusicData>(() => GetMusics(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<Movie> GetMovieAsync(String id)
        {
            return CreateNewTask<Movie>(() => GetMovie(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Movie> GetMovieAsync(GetObjectCommand command)
        {
            return CreateNewTask<Movie>(() => GetMovie(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<MovieData> GetMoviesAsync(String id)
        {
            return CreateNewTask<MovieData>(() => GetMovies(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<MovieData> GetMoviesAsync(GetObjectCommand command)
        {
            return CreateNewTask<MovieData>(() => GetMovies(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<Television> GetTelevisionAsync(String id)
        {
            return CreateNewTask<Television>(() => GetTelevision(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<Television> GetTelevisionAsync(GetObjectCommand command)
        {
            return CreateNewTask<Television>(() => GetTelevision(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<TelevisionData> GetTelevisionsAsync(String id)
        {
            return CreateNewTask<TelevisionData>(() => GetTelevisions(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<TelevisionData> GetTelevisionsAsync(GetObjectCommand command)
        {
            return CreateNewTask<TelevisionData>(() => GetTelevisions(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public Task<TelevisionData> GetTelevisionsAsync(TelevisionData data, PagingMode mode)
        {
            return CreateNewTask<TelevisionData>(() => GetTelevisions(data, mode));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<User> GetFriendAsync(String id)
        {
            return CreateNewTask<User>(() => GetFriend(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<User> GetFriendAsync(GetObjectCommand command)
        {
            return CreateNewTask<User>(() => GetFriend(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<FriendData> GetFriendsAsync()
        {
            return this.GetFriendsAsync("me");
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<FriendData> GetFriendsAsync(String id)
        {
            return CreateNewTask<FriendData>(() => GetFriends(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<FriendData> GetFriendsAsync(GetObjectCommand command)
        {
            return CreateNewTask<FriendData>(() => GetFriends(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public Task<FriendData> GetFriendsAsync(FriendData data, PagingMode mode)
        {
            return CreateNewTask<FriendData>(() => GetFriends(data, mode));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<NotificationData> GetNotificationsAsync()
        {
            return CreateNewTask<NotificationData>(() => GetNotifications());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public Task<NotificationData> GetNotificationsAsync(NotificationData data, PagingMode mode)
        {
            return CreateNewTask<NotificationData>(() => GetNotifications(data, mode));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<InboxData> GetInboxAsync()
        {
            return CreateNewTask<InboxData>(() => GetInbox());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public Task<InboxData> GetInboxAsync(InboxData data, PagingMode mode)
        {
            return CreateNewTask<InboxData>(() => GetInbox(data, mode));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Task<OutboxData> GetOutboxAsync()
        {
            return CreateNewTask<OutboxData>(() => GetOutbox());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public Task<OutboxData> GetOutboxAsync(OutboxData data, PagingMode mode)
        {
            return CreateNewTask<OutboxData>(() => GetOutbox(data, mode));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<Boolean> LikeAsync(String id)
        {
            return CreateNewTask<Boolean>(() => Like(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<Boolean> UnLikeAsync(String id)
        {
            return CreateNewTask<Boolean>(() => UnLike(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<String> AddCommentAsync(AddCommentCommand command)
        {
            return CreateNewTask<String>(() => AddComment(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Task<String> AddStatusAsync(AddStatusCommand command)
        {
            return CreateNewTask<String>(() => AddStatus(command));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Task<Boolean> DeleteObjectAsync(String id)
        {
            return CreateNewTask<Boolean>(() => DeleteObject(id));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static Task<List<String>> CreateJsonTextListAsync(Dictionary<String, Object> data, String key)
        {
            return CreateNewTask<List<String>>(() => CreateJsonTextList(data, key));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="container"></param>
        /// <returns></returns>
        public static Task<List<String>> CreateJsonTextListAsync(JContainer container)
        {
            return CreateNewTask<List<String>>(() => CreateJsonTextList(container));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static Task<List<String>> CreateTextListAsync(Dictionary<String, Object> data, String key)
        {
            return CreateNewTask<List<String>>(() => CreateTextList(data, key));
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="container"></param>
        /// <returns></returns>
        public static Task<List<String>> CreateTextListAsync(JContainer container)
        {
            return CreateNewTask<List<String>>(() => CreateTextList(container));
        }
    }
}
