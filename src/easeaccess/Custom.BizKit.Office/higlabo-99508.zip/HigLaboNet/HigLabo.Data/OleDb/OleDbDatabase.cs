﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace HigLabo.Data.RelationalDatabase
{
    /// <summary>
    /// SQLサーバーへの接続及びデータ操作の機能を提供します。
    /// </summary>
    public partial class OleDbDatabase
    {
        private SqlConnection _connection;
        private SqlTransaction _transaction;

        private static SqlConnection CreateConnection(String connectionString)
        {
            return new SqlConnection(connectionString);
        }
        private static SqlCommand CreateCommand(String commandText)
        {
            return new SqlCommand(commandText);
        }
        private static SqlDataAdapter CreateDataAdapter()
        {
            return new SqlDataAdapter();
        }
        private static void SetSelectCommand(IDataAdapter adapter, IDbCommand command)
        {
            (adapter as SqlDataAdapter).SelectCommand = command as SqlCommand;
        }
        private static void FillDataTable(IDataAdapter adapter, DataTable dataTable)
        {
            (adapter as SqlDataAdapter).Fill(dataTable);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        public OleDbDatabase(String connectionString)
        {
            this.ConnectionString = connectionString;
        }
        /// <summary>
        /// 例外オブジェクトを生成します。
        /// </summary>
        /// <param name="exception"></param>
        /// <returns></returns>
        public static Exception CreateException(Exception exception)
        {
            return exception;
        }
    }
}
