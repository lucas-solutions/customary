﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace HigLabo.Data.RelationalDatabase
{
    public partial class OleDbDatabase : IDatabase
    {
        /// <summary>
        /// このオブジェクトが実行する全てのコマンドのタイムアウトの値を取得または設定します。
        /// nullを設定した場合は各コマンドの値を上書きしません。
        /// </summary>
        public int? CommandTimeout { get; set; }
        /// <summary>
        /// コマンドが実行される直前に発生するイベントです。
        /// </summary>
        public static event EventHandler<CommandExecutingEventArgs> CommandExecuting;
        /// <summary>
        /// コマンドが実行された直後に発生するイベントです。
        /// </summary>
        public static event EventHandler<CommandExecutedEventArgs> CommandExecuted;
        /// <summary>
        /// コマンドの実行で例外が発生したときに発生するイベントです。
        /// </summary>
        public static event EventHandler<CommandErrorEventArgs> CommandError;
        /// <summary>
        /// 接続文字列を取得または設定します。
        /// </summary>
        public String ConnectionString { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public ConnectionState ConnectionState
        {
            get
            {
                if (this._connection == null)
                { return ConnectionState.Closed; }
                return this._connection.State;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        protected static CommandExecutingEventArgs OnCommandExecuting(MethodName methodName, String connectionString, IDbCommand command)
        {
            var eh = CommandExecuting;
            if (eh != null)
            {
                var e = new CommandExecutingEventArgs(methodName, connectionString, command);
                eh(null, e);
                return e;
            }
            return null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        protected static void OnCommandExecuted(MethodName methodName, String connectionString, IDbCommand command)
        {
            var eh = CommandExecuted;
            if (eh != null)
            {
                eh(null, new CommandExecutedEventArgs(methodName, connectionString, command));
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="e"></param>
        protected static void OnCommandError(IDbCommand command, CommandErrorEventArgs e)
        {
            var eh = CommandError;
            if (eh != null)
            {
                eh(null, e);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public void Open()
        {
            if (this._connection == null)
            {
                this._connection = CreateConnection(this.ConnectionString);
                this._connection.Open();
            }
            else
            {
                if (this._connection.State == ConnectionState.Closed)
                {
                    this._connection.Open();
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public void Close()
        {
            if (this._connection != null)
            {
                if (this._connection.State == ConnectionState.Open)
                {
                    this._connection.Close();
                }
                this._connection.Dispose();
                this._connection = null;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Boolean CheckAvailable()
        {
            try
            {
                this.Open();
            }
            catch
            {
                return false;
            }
            finally
            {
                this.Close();
            }
            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="isolationLevel"></param>
        public void BeginTransaction(IsolationLevel isolationLevel)
        {
            this.Open();
            this._transaction = this._connection.BeginTransaction(isolationLevel);
        }
        /// <summary>
        /// 
        /// </summary>
        public void CommitTransaction()
        {
            this._transaction.Commit();
            this.Close();
        }
        /// <summary>
        /// 
        /// </summary>
        public void RollBackTransaction()
        {
            this._transaction.Rollback();
            this.Close();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public DataSet GetDataSet(String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return GetDataSet(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        DataSet IDatabase.GetDataSet(IDbCommand command)
        {
            var sqlCommand = command as SqlCommand;
            if (sqlCommand == null) { throw new ArgumentException("Invalid argument type"); }
            return GetDataSet(sqlCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public DataSet GetDataSet(SqlCommand command)
        {
            DataSet ds = new DataSet();
            IDataAdapter da;
            IDbCommand cm = command;

            try
            {
                var e = OnCommandExecuting(MethodName.GetDataSet, this.ConnectionString, cm);
                if (e != null && e.Cancel) { return null; }

                this.Open();
                da = CreateDataAdapter();
                cm.Connection = this._connection;
                cm.Transaction = this._transaction;
                this.SetCommandParameter(cm);
                SetSelectCommand(da, cm);

                da.Fill(ds);
            }
            catch (Exception ex)
            {
                CatchException(MethodName.GetDataSet, this.ConnectionString, cm, ex);
            }
            finally
            {
                if (cm.Transaction == null && this._connection.State == ConnectionState.Closed)
                { this.Close(); }
                OnCommandExecuted(MethodName.GetDataSet, this.ConnectionString, cm);
            }
            return ds;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public DataTable GetDataTable(String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return GetDataTable(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        DataTable IDatabase.GetDataTable(IDbCommand command)
        {
            var sqlCommand = command as SqlCommand;
            if (sqlCommand == null) { throw new ArgumentException("Invalid argument type"); }
            return GetDataTable(sqlCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public DataTable GetDataTable(SqlCommand command)
        {
            DataTable dt = new DataTable();
            IDbCommand cm = command;

            try
            {
                var e = OnCommandExecuting(MethodName.GetDataTable, this.ConnectionString, cm);
                if (e != null && e.Cancel) { return null; }

                this.Open();
                IDataAdapter da = CreateDataAdapter();
                cm.Connection = this._connection;
                cm.Transaction = this._transaction;
                this.SetCommandParameter(cm);
                SetSelectCommand(da, cm);

                FillDataTable(da, dt);
            }
            catch (Exception ex)
            {
                CatchException(MethodName.GetDataTable, this.ConnectionString, cm, ex);
            }
            finally
            {
                if (cm.Transaction == null && this._connection.State == ConnectionState.Closed)
                { this.Close(); }
                OnCommandExecuted(MethodName.GetDataTable, this.ConnectionString, cm);
            }
            return dt;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public IDataReader ExecuteReader(String query)
        {
            return ExecuteReader(query, CommandBehavior.Default);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="commandBehavior"></param>
        /// <returns></returns>
        public IDataReader ExecuteReader(String query, CommandBehavior commandBehavior)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return ExecuteReader(cm, commandBehavior);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        IDataReader IDatabase.ExecuteReader(IDbCommand command)
        {
            return ((IDatabase)this).ExecuteReader(command, CommandBehavior.Default);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="commandBehavior"></param>
        /// <returns></returns>
        IDataReader IDatabase.ExecuteReader(IDbCommand command, CommandBehavior commandBehavior)
        {
            var sqlCommand = command as SqlCommand;
            if (sqlCommand == null) { throw new ArgumentException("Invalid argument type"); }
            return ExecuteReader(sqlCommand, commandBehavior);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="commandBehavior"></param>
        /// <returns></returns>
        public IDataReader ExecuteReader(SqlCommand command, CommandBehavior commandBehavior)
        {
            IDataReader dr = null;
            IDbCommand cm = command;
            try
            {
                var e = OnCommandExecuting(MethodName.ExecuteReader, this.ConnectionString, cm);
                if (e != null && e.Cancel) { return null; }

                this.Open();
                cm.Connection = this._connection;
                cm.Transaction = this._transaction;
                this.SetCommandParameter(cm);

                dr = cm.ExecuteReader(commandBehavior);
            }
            catch (Exception exception)
            {
                this.Close();
                CatchException(MethodName.ExecuteReader, this.ConnectionString, cm, exception);
            }
            finally
            {
                OnCommandExecuted(MethodName.ExecuteReader, this.ConnectionString, cm);
            }
            return dr;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IDataReader ExecuteReader(SqlCommand command)
        {
            return ExecuteReader(command, CommandBehavior.Default);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public Object ExecuteScalar(String query)
        {
            IDbCommand cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return ((IDatabase)this).ExecuteScalar(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        Object IDatabase.ExecuteScalar(IDbCommand command)
        {
            var sqlCommand = command as SqlCommand;
            if (sqlCommand == null) { throw new ArgumentException("Invalid argument type"); }
            return ExecuteScalar(sqlCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Object ExecuteScalar(SqlCommand command)
        {
            Object o = null;
            IDbCommand cm = command;
            try
            {
                var e = OnCommandExecuting(MethodName.ExecuteScalar, this.ConnectionString, cm);
                if (e != null && e.Cancel) { return null; }

                this.Open();
                cm.Connection = this._connection;
                cm.Transaction = this._transaction;
                this.SetCommandParameter(cm);

                o = cm.ExecuteScalar();
            }
            catch (Exception ex)
            {
                CatchException(MethodName.ExecuteScalar, this.ConnectionString, cm, ex);
            }
            finally
            {
                this.Close();
                OnCommandExecuted(MethodName.ExecuteScalar, this.ConnectionString, cm);
            }
            return o;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="connectionAutoClose"></param>
        /// <returns></returns>
        public Int32 ExecuteCommand(String query, Boolean connectionAutoClose)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return ExecuteCommand(cm, connectionAutoClose);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="connectionAutoClose"></param>
        /// <returns></returns>
        Int32 IDatabase.ExecuteCommand(IDbCommand command, Boolean connectionAutoClose)
        {
            var sqlCommand = command as SqlCommand;
            if (sqlCommand == null) { throw new ArgumentException("Invalid argument type"); }
            return ExecuteCommand(sqlCommand, connectionAutoClose);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="connectionAutoClose"></param>
        /// <returns></returns>
        public Int32 ExecuteCommand(SqlCommand command, Boolean connectionAutoClose)
        {
            var affectRecordNumber = Int32.MinValue;
            IDbCommand cm = command;
            try
            {
                var e = OnCommandExecuting(MethodName.ExecuteCommand, this.ConnectionString, cm);
                if (e != null && e.Cancel) { return -1; }

                this.Open();
                cm.Connection = this._connection;
                cm.Transaction = this._transaction;
                this.SetCommandParameter(cm);

                affectRecordNumber = cm.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                CatchException(MethodName.ExecuteCommand, this.ConnectionString, cm, ex);
            }
            finally
            {
                if (connectionAutoClose)
                {
                    this.Close();
                }
                OnCommandExecuted(MethodName.ExecuteCommand, this.ConnectionString, cm);
            }
            return affectRecordNumber;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="isolationLevel"></param>
        /// <param name="connectionAutoClose"></param>
        /// <param name="commands"></param>
        /// <returns></returns>
        public Int32[] ExecuteCommand(IsolationLevel isolationLevel, Boolean connectionAutoClose, params String[] commands)
        {
            return ExecuteCommand(isolationLevel, connectionAutoClose, commands.Select(q =>
                {
                    var cm = CreateCommand(q);
                    cm.CommandType = CommandType.Text;
                    return cm;
                }).ToArray());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="isolationLevel"></param>
        /// <param name="connectionAutoClose"></param>
        /// <param name="commands"></param>
        /// <returns></returns>
        Int32[] IDatabase.ExecuteCommand(IsolationLevel isolationLevel, Boolean connectionAutoClose, params IDbCommand[] commands)
        {
            if (!commands.All(c => c is SqlCommand)) { throw new ArgumentException("Invalid argument type"); }
            return ExecuteCommand(isolationLevel, connectionAutoClose, commands.OfType<SqlCommand>().ToArray());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="isolationLevel"></param>
        /// <param name="connectionAutoClose"></param>
        /// <param name="commands"></param>
        /// <returns></returns>
        public Int32[] ExecuteCommand(IsolationLevel isolationLevel, Boolean connectionAutoClose, params SqlCommand[] commands)
        {
            var affectRecordNumber = new Int32[commands.Length];
            IDbCommand cm = null;
            CommandExecutingEventArgs e;
            try
            {
                this.Open();
                this.BeginTransaction(isolationLevel);
                for (var i = 0; i < commands.Length; i++)
                {
                    cm = commands[i];
                    e = OnCommandExecuting(MethodName.ExecuteCommandList, this.ConnectionString, cm);
                    if (e != null && e.Cancel) { continue; }

                    cm.Connection = this._connection;
                    cm.Transaction = this._transaction;
                    this.SetCommandParameter(cm);

                    affectRecordNumber[i] = cm.ExecuteNonQuery();

                    OnCommandExecuted(MethodName.ExecuteCommandList, this.ConnectionString, cm);
                }
                this._transaction.Commit();
            }
            catch (Exception exception)
            {
                if (this._connection.State == ConnectionState.Open)
                {
                    this._transaction.Rollback();
                }
                CatchException(MethodName.ExecuteCommandList, this.ConnectionString, cm, exception);
            }
            finally
            {
                if (connectionAutoClose)
                {
                    this.Close();
                }
            }
            return affectRecordNumber;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        public static DataSet GetDataSet(String connectionString, String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return GetDataSet(connectionString, cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public static DataSet GetDataSet(String connectionString, SqlCommand command)
        {
            DataSet ds = new DataSet();
            IDbConnection cn = null;
            IDataAdapter da;
            IDbCommand cm = command;
            try
            {
                var e = OnCommandExecuting(MethodName.GetDataSet, connectionString, cm);
                if (e != null && e.Cancel) { return null; }

                cn = CreateConnection(connectionString);
                cm.Connection = cn;
                da = CreateDataAdapter();
                SetSelectCommand(da, cm);

                da.Fill(ds);
            }
            catch (Exception ex)
            {
                CatchException(MethodName.GetDataSet, connectionString, cm, ex);
            }
            finally
            {
                if (cn != null) { cn.Dispose(); }
                OnCommandExecuted(MethodName.GetDataSet, connectionString, cm);
            }
            return ds;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        public static DataTable GetDataTable(String connectionString, String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return GetDataTable(connectionString, cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public static DataTable GetDataTable(String connectionString, SqlCommand command)
        {
            DataTable dt = new DataTable();
            IDbConnection cn = null;
            IDbCommand cm = command;
            CommandExecutingEventArgs e;
            try
            {
                e = OnCommandExecuting(MethodName.GetDataTable, connectionString, cm);
                if (e != null && e.Cancel) { return null; }

                cn = CreateConnection(connectionString);
                cm.Connection = cn;
                IDataAdapter da = CreateDataAdapter();
                SetSelectCommand(da, cm);

                FillDataTable(da, dt);
            }
            catch (Exception ex)
            {
                CatchException(MethodName.GetDataTable, connectionString, cm, ex);
            }
            finally
            {
                if (cn != null) { cn.Dispose(); }
                OnCommandExecuted(MethodName.GetDataTable, connectionString, cm);
            }
            return dt;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        public static Int32 ExecuteCommand(String connectionString, String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return ExecuteCommand(connectionString, cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public static Int32 ExecuteCommand(String connectionString, SqlCommand command)
        {
            Int32 affectRecordNumber = Int32.MinValue;
            IDbConnection cn = null;
            IDbCommand cm = command;
            CommandExecutingEventArgs e;
            try
            {
                e = OnCommandExecuting(MethodName.ExecuteCommand, connectionString, cm);
                if (e != null && e.Cancel) { return -1; }

                cn = CreateConnection(connectionString);
                cn.Open();
                cm.Connection = cn;

                affectRecordNumber = command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                CatchException(MethodName.ExecuteCommand, connectionString, cm, ex);
            }
            finally
            {
                if (cn != null) { cn.Dispose(); }
                OnCommandExecuted(MethodName.ExecuteCommand, connectionString, cm);
            }
            return affectRecordNumber;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        public static Object ExecuteScalar(String connectionString, String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return ExecuteScalar(connectionString, cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public static Object ExecuteScalar(String connectionString, SqlCommand command)
        {
            Object o = null;
            IDbConnection cn = null;
            IDbCommand cm = command;
            CommandExecutingEventArgs e;
            try
            {
                e = OnCommandExecuting(MethodName.ExecuteScalar, connectionString, cm);
                if (e != null && e.Cancel) { return -1; }

                cn = CreateConnection(connectionString);
                cn.Open();
                cm.Connection = cn;

                o = command.ExecuteScalar();
            }
            catch (Exception ex)
            {
                CatchException(MethodName.ExecuteScalar, connectionString, cm, ex);
            }
            finally
            {
                if (cn != null) { cn.Dispose(); }
                OnCommandExecuted(MethodName.ExecuteScalar, connectionString, cm);
            }
            return o;
        }
        /// <summary>
        /// 例外をキャッチしてハンドルします。
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <param name="exception"></param>
        private static void CatchException(MethodName methodName, String connectionString, IDbCommand command, Exception exception)
        {
            CommandErrorEventArgs e = new CommandErrorEventArgs(methodName, connectionString, command, exception);
            OnCommandError(null, e);
            if (e.ThrowException)
            {
                ThrowException(exception);
            }
        }
        /// <summary>
        /// 新しい例外を生成しスローします。
        /// </summary>
        /// <param name="exception"></param>
        public static void ThrowException(Exception exception)
        {
            throw CreateException(exception);
        }
        private void SetCommandParameter(IDbCommand command)
        {
            if (this.CommandTimeout.HasValue)
            {
                command.CommandTimeout = this.CommandTimeout.Value;
            }
        }
        #region デストラクタ
        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            GC.SuppressFinalize(this);
            this.Dispose(true);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected void Dispose(Boolean disposing)
        {
            if (disposing)
            { }
            if (this._transaction != null)
            { this._transaction.Dispose(); }
            if (this._connection != null)
            { this._connection.Dispose(); }
        }
        /// <summary>
        /// 
        /// </summary>
        ~OleDbDatabase()
        {
            this.Dispose(false);
        }
        #endregion
    }
}
