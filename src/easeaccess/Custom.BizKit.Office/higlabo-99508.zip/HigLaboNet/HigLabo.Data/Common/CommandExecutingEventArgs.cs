﻿using System;
using System.Data;
using System.Text;
using HigLabo.Data.RelationalDatabase;

namespace HigLabo.Data
{
    /// <summary>
    /// 
    /// </summary>
    public class CommandExecutingEventArgs : EventArgs
    {
        /// <summary>
        /// エラーが発生したメソッドを示す値を取得します。
        /// </summary>
        public MethodName MethodName { get; private set; }

        /// <summary>
        /// コマンドが実行されるデータベースへの接続文字列を取得します。
        /// </summary>
        public string ConnectionString { get; private set; }

        /// <summary>
        /// 実行されたコマンドを取得します。
        /// </summary>
        public IDbCommand Command { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        public IDbDataAdapter DataAdapter { get; private set; }

        /// <summary>
        /// 実行されたバルクコピーのコンテキストを取得します。
        /// </summary>
        public SqlBulkCopyContext Context { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        public bool Cancel { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        private CommandExecutingEventArgs(MethodName methodName, String connectionString)
        {
            MethodName = methodName;
            ConnectionString = connectionString;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        public CommandExecutingEventArgs(MethodName methodName, String connectionString, IDbCommand command)
            : this(methodName, connectionString)
        {
            Cancel = false;
            Command = command;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="dataAdapter"></param>
        public CommandExecutingEventArgs(MethodName methodName, String connectionString, IDbDataAdapter dataAdapter)
            : this(methodName, connectionString)
        {
            Cancel = false;
            DataAdapter = dataAdapter;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="context"></param>
        public CommandExecutingEventArgs(MethodName methodName, String connectionString, SqlBulkCopyContext context)
            : this(methodName, connectionString)
        {
            Cancel = false;
            Context = context;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(128);
            try
            {
                if (String.IsNullOrEmpty(this.ConnectionString) == false)
                {
                    sb.Append(this.ConnectionString);
                    sb.Append(" ");
                }
                if (this.Command != null)
                {
                    sb.Append(this.Command.CommandText);
                    sb.Append(" ");
                }
                return sb.ToString();
            }
            catch { return base.ToString(); }
        }
    }
}
