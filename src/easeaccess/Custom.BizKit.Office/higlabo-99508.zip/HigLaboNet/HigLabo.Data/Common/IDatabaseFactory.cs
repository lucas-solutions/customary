﻿namespace HigLabo.Data.RelationalDatabase
{
    /// <summary>
    /// 
    /// </summary>
    public interface IDatabaseFactory
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        IDatabase GetDatabase();
    }
}
