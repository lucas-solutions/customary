﻿using System;
using System.Data;
using System.Text;
using HigLabo.Data.RelationalDatabase;

namespace HigLabo.Data
{
    /// <summary>
    /// 
    /// </summary>
    public class CommandExecutedEventArgs : EventArgs
    {
        /// <summary>
        /// エラーが発生したメソッドを示す値を取得します。
        /// </summary>
        public MethodName MethodName { get; private set; }

        /// <summary>
        /// コマンドが実行されるデータベースへの接続文字列を取得します。
        /// </summary>
        public string ConnectionString { get; private set; }

        /// <summary>
        /// 実行されたコマンドを取得します。
        /// </summary>
        public IDbCommand Command { get; private set; }

        /// <summary>
        /// 実行されたデータアダプタを取得します。
        /// </summary>
        public IDbDataAdapter DataAdapter { get; private set; }

        /// <summary>
        /// 実行されたバルクコピーのコンテキストを取得します。
        /// </summary>
        public SqlBulkCopyContext Context { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        public Exception Exception { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        public CommandExecutedEventArgs(MethodName methodName, String connectionString, Exception exception)
        {
            MethodName = methodName;
            ConnectionString = connectionString;
            Exception = exception;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        public CommandExecutedEventArgs(MethodName methodName, String connectionString, IDbCommand command)
            : this(methodName, connectionString, command, null)
        {
            
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <param name="exception"></param>
        public CommandExecutedEventArgs(MethodName methodName, String connectionString, IDbCommand command, Exception exception)
            : this(methodName, connectionString, exception)
        {
            Command = command;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="dataAdapter"></param>
        public CommandExecutedEventArgs(MethodName methodName, String connectionString, IDbDataAdapter dataAdapter)
            : this(methodName, connectionString, (Exception)null)
        {
            DataAdapter = dataAdapter;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="context"></param>
        public CommandExecutedEventArgs(MethodName methodName, String connectionString, SqlBulkCopyContext context)
            : this(methodName, connectionString, (Exception)null)
        {
            Context = context;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            var sb = new StringBuilder(128);
            try
            {
                if (String.IsNullOrEmpty(ConnectionString) == false)
                {
                    sb.Append(ConnectionString);
                    sb.Append(" ");
                }
                if (Command != null)
                {
                    sb.Append(Command.CommandText);
                    sb.Append(" ");
                }
                if (Exception != null)
                {
                    sb.Append(Exception);
                }
                return sb.ToString();
            }
            catch { return base.ToString(); }
        }
    }
}
