﻿using System;
using System.Data;
using System.Text;
using HigLabo.Data.RelationalDatabase;

namespace HigLabo.Data
{
    /// <summary>
    /// 
    /// </summary>
    public class CommandErrorEventArgs : EventArgs
    {
        /// <summary>
        /// エラーが発生したメソッドを示す値を取得します。
        /// </summary>
        public MethodName MethodName { get; private set; }

        /// <summary>
        /// コマンドが実行されるデータベースへの接続文字列を取得します。
        /// </summary>
        public string ConnectionString { get; private set; }

        /// <summary>
        /// 実行されたコマンドを取得します。
        /// </summary>
        public IDbCommand Command { get; private set; }

        /// <summary>
        /// 実行されたデータアダプタを取得します。
        /// </summary>
        public IDbDataAdapter DataAdapter { get; private set; }

        /// <summary>
        /// 実行されたバルクコピーのコンテキストを取得します。
        /// </summary>
        public SqlBulkCopyContext Context { get; private set; }

        /// <summary>
        /// 発生した例外を取得します。
        /// </summary>
        public Exception Exception { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        public bool ThrowException { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="exception"></param>
        private CommandErrorEventArgs(MethodName methodName, String connectionString, Exception exception)
        {
            this.MethodName = methodName;
            this.ConnectionString = connectionString;
            this.Exception = exception;
            this.ThrowException = true;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <param name="exception"></param>
        public CommandErrorEventArgs(MethodName methodName, String connectionString, IDbCommand command, Exception exception)
            : this(methodName, connectionString, exception)
        {
            this.Command = command;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="dataAdapter"></param>
        /// <param name="exception"></param>
        public CommandErrorEventArgs(MethodName methodName, String connectionString, IDbDataAdapter dataAdapter, Exception exception)
            : this(methodName, connectionString, exception)
        {
            this.DataAdapter = dataAdapter;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="context"></param>
        /// <param name="exception"></param>
        public CommandErrorEventArgs(MethodName methodName, String connectionString, SqlBulkCopyContext context, Exception exception)
            : this(methodName, connectionString, exception)
        {
            this.Context = context;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder(128);
            try
            {
                if (String.IsNullOrEmpty(this.ConnectionString) == false)
                {
                    sb.Append(this.ConnectionString);
                    sb.Append(" ");
                }
                if (this.Command != null)
                {
                    sb.Append(this.Command.CommandText);
                    sb.Append(" ");
                }
                if (this.Exception != null)
                {
                    sb.Append(this.Exception.ToString());
                }
                return sb.ToString();
            }
            catch { return base.ToString(); }
        }
    }
}
