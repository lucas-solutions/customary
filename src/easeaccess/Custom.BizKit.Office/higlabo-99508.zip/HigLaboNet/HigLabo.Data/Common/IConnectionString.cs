﻿using System;

namespace HigLabo.Data.RelationalDatabase
{
    /// <summary>
    /// 
    /// </summary>
    public interface IConnectionString
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        String Create();
    }
}
