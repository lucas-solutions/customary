﻿namespace HigLabo.Data
{
    /// <summary>
    /// 
    /// </summary>
    public enum MethodName
    {
        /// <summary>
        /// 
        /// </summary>
        GetDataSet, 
        /// <summary>
        /// 
        /// </summary>
        GetDataTable, 
        /// <summary>
        /// 
        /// </summary>
        ExecuteCommand, 
        /// <summary>
        /// 
        /// </summary>
        ExecuteCommandList, 
        /// <summary>
        /// 
        /// </summary>
        ExecuteScalar, 
        /// <summary>
        /// 
        /// </summary>
        ExecuteReader, 
        /// <summary>
        /// 
        /// </summary>
        BulkCopy,
        /// <summary>
        /// 
        /// </summary>
        Save,
    }
}
