﻿using System;
using System.Data;

namespace HigLabo.Data.RelationalDatabase
{
    /// <summary>
    /// 
    /// </summary>
    public interface IDatabase : IDisposable
    {
        /// <summary>
        /// 接続文字列を取得または設定します。
        /// </summary>
        String ConnectionString { get; set; }
        /// <summary>
        /// データベースへの接続の現在の状態を取得します。
        /// </summary>
        ConnectionState ConnectionState { get; }
        /// <summary>
        /// 接続を開きます。
        /// </summary>
        void Open();
        /// <summary>
        /// 接続を閉じます。
        /// </summary>
        void Close();
        /// <summary>
        /// 接続が有効かどうかを示す値を取得します。
        /// </summary>
        /// <returns></returns>
        Boolean CheckAvailable();
        /// <summary>
        /// 接続を開き指定したトランザクション分離レベルでトランザクションを開始する
        /// </summary>
        /// <param name="isolationLevel"></param>
        void BeginTransaction(IsolationLevel isolationLevel);
        /// <summary>
        /// トランザクションをコミットします。
        /// </summary>
        void CommitTransaction();
        /// <summary>
        /// トランザクションをロールバックします。
        /// </summary>
        void RollBackTransaction();
        /// <summary>
        /// DataSetを取得します。
        /// </summary>
        /// <param name="query">SELECT文字列</param>
        /// <returns></returns>
        DataSet GetDataSet(String query);
        /// <summary>
        /// DataSetを取得します。
        /// </summary>
        /// <param name="command">コマンド</param>
        /// <returns></returns>
        DataSet GetDataSet(IDbCommand command);
        /// <summary>
        /// DataTableを取得します。
        /// </summary>
        /// <param name="query">SELECT文字列</param>
        /// <returns></returns>
        DataTable GetDataTable(String query);
        /// <summary>
        /// DataTableを取得します。
        /// </summary>
        /// <param name="command">コマンド</param>
        /// <returns></returns>
        DataTable GetDataTable(IDbCommand command);
        /// <summary>
        /// IDataReaderを取得します。
        /// </summary>
        /// <param name="query">セレクト文字列</param>
        /// <param name="commandBehavior">コマンドの振る舞いを定義</param>
        /// <returns></returns>
        IDataReader ExecuteReader(String query, CommandBehavior commandBehavior);
        /// <summary>
        /// IDataReaderを取得します。
        /// </summary>
        /// <param name="query">セレクト文字列</param>
        /// <returns></returns>
        IDataReader ExecuteReader(String query);
        /// <summary>
        /// IDataReaderを取得します。
        /// </summary>
        /// <param name="command">コマンド</param>
        /// <param name="commandBehavior">コマンドの振る舞い</param>
        /// <returns></returns>
        IDataReader ExecuteReader(IDbCommand command, CommandBehavior commandBehavior);
        /// <summary>
        /// IDataReaderを取得します。
        /// </summary>
        /// <param name="command">コマンド</param>
        /// <returns></returns>
        IDataReader ExecuteReader(IDbCommand command);
        /// <summary>
        /// スカラ値を取得します。
        /// </summary>
        /// <param name="query">セレクト文字列</param>
        /// <returns></returns>
        Object ExecuteScalar(String query);
        /// <summary>
        /// スカラ値を取得します。
        /// </summary>
        /// <param name="command">コマンド</param>
        /// <returns></returns>
        Object ExecuteScalar(IDbCommand command);
        /// <summary>
        /// コマンドを実行します。
        /// </summary>
        /// <param name="commandString">コマンド文字列</param>
        /// <param name="connectionAutoClose">接続を閉じるならTrue</param>
        /// <returns>ExecuteNonQueryメソッドを実行した時の戻り値を返す。既定値はInt32.MinValue。</returns>
        Int32 ExecuteCommand(String commandString, Boolean connectionAutoClose);
        /// <summary>
        /// コマンドを実行します。
        /// </summary>
        /// <param name="command">コマンド</param>
        /// <param name="connectionAutoClose">接続を閉じるならTrue</param>
        /// <returns>ExecuteNonQueryメソッドを実行した時の戻り値を返します。既定値はInt32.MinValueです。</returns>
        Int32 ExecuteCommand(IDbCommand command, Boolean connectionAutoClose);
        /// <summary>
        /// トランザクションをかけて複数コマンドを実行します。
        /// </summary>
        /// <param name="isolationLevel"></param>
        /// <param name="connectionAutoClose"></param>
        /// <param name="commands">コマンド</param>
        /// <returns>各コマンドに対してExecuteNonQueryメソッドを実行した時の戻り値の配列を返します。既定値はInt32.MinValueです。</returns>
        Int32[] ExecuteCommand(IsolationLevel isolationLevel, Boolean connectionAutoClose, params IDbCommand[] commands);
        /// <summary>
        /// トランザクションをかけて複数コマンドを実行します。
        /// </summary>
        /// <param name="isolationLevel"></param>
        /// <param name="connectionAutoClose"></param>
        /// <param name="commandString">コマンド文字列</param>
        /// <returns>各コマンドに対してExecuteNonQueryメソッドを実行した時の戻り値の配列を返します。既定値はInt32.MinValueです。</returns>
        Int32[] ExecuteCommand(IsolationLevel isolationLevel, Boolean connectionAutoClose, params String[] commandString);
    }
}
