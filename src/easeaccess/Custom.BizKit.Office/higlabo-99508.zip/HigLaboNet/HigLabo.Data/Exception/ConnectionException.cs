﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace HigLabo.Data.RelationalDatabase
{
    /// <summary>
    /// 接続時のエラーを表現するクラスです。
    /// </summary>
    [Serializable]
    public class ConnectionException : DatabaseException
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        public ConnectionException(SqlException ex, MethodName methodName, String connectionString, IDbCommand command)
            : base(ex, methodName, connectionString, command)
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="dataAdapter"></param>
        public ConnectionException(SqlException ex, MethodName methodName, String connectionString, IDbDataAdapter dataAdapter)
            : base(ex, methodName, connectionString, dataAdapter)
        {
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="context"></param>
        public ConnectionException(SqlException ex, MethodName methodName, String connectionString, SqlBulkCopyContext context)
            : base(ex, methodName, connectionString, context)
        {
        }
    }
}
