﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace HigLabo.Data.RelationalDatabase
{
    public partial class SqlServerDatabase : IDatabase
    {
        private String _ConnectionString = "";
        private Int32? _CommandTimeout = null;
        /// <summary>
        /// このオブジェクトが実行する全てのコマンドのタイムアウトの値を取得または設定します。
        /// nullを設定した場合は各コマンドの値を上書きしません。
        /// </summary>
        public Int32? CommandTimeout
        {
            get { return this._CommandTimeout; }
            set { this._CommandTimeout = value; }
        }
        /// <summary>
        /// コマンドが実行される直前に発生するイベントです。
        /// </summary>
        public static event EventHandler<CommandExecutingEventArgs> CommandExecuting;
        /// <summary>
        /// コマンドが実行された直後に発生するイベントです。
        /// </summary>
        public static event EventHandler<CommandExecutedEventArgs> CommandExecuted;
        /// <summary>
        /// コマンドの実行で例外が発生したときに発生するイベントです。
        /// </summary>
        public static event EventHandler<CommandErrorEventArgs> CommandError;
        /// <summary>
        /// 接続文字列を取得または設定します。
        /// </summary>
        public String ConnectionString
        {
            get { return this._ConnectionString; }
            set { this._ConnectionString = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public ConnectionState ConnectionState
        {
            get
            {
                if (this._Connection == null)
                { return ConnectionState.Closed; }
                return this._Connection.State;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        protected static CommandExecutingEventArgs OnCommandExecuting(MethodName methodName, String connectionString, IDbCommand command)
        {
            var eh = SqlServerDatabase.CommandExecuting;
            if (eh != null)
            {
                var e = new CommandExecutingEventArgs(methodName, connectionString, command);
                eh(null, e);
                return e;
            }
            return null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="dataAdapter"></param>
        /// <returns></returns>
        protected static CommandExecutingEventArgs OnCommandExecuting(MethodName methodName, String connectionString, IDbDataAdapter dataAdapter)
        {
            var eh = SqlServerDatabase.CommandExecuting;
            if (eh != null)
            {
                var e = new CommandExecutingEventArgs(methodName, connectionString, dataAdapter);
                eh(null, e);
                return e;
            }
            return null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        protected static CommandExecutingEventArgs OnCommandExecuting(MethodName methodName, String connectionString, SqlBulkCopyContext context)
        {
            var eh = SqlServerDatabase.CommandExecuting;
            if (eh != null)
            {
                var e = new CommandExecutingEventArgs(methodName, connectionString, context);
                eh(null, e);
                return e;
            }
            return null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        protected static void OnCommandExecuted(MethodName methodName, String connectionString, IDbCommand command)
        {
            var eh = SqlServerDatabase.CommandExecuted;
            if (eh != null)
            {
                eh(null, new CommandExecutedEventArgs(methodName, connectionString, command));
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="dataAdapter"></param>
        protected static void OnCommandExecuted(MethodName methodName, String connectionString, IDbDataAdapter dataAdapter)
        {
            var eh = SqlServerDatabase.CommandExecuted;
            if (eh != null)
            {
                eh(null, new CommandExecutedEventArgs(methodName, connectionString, dataAdapter));
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="context"></param>
        protected static void OnCommandExecuted(MethodName methodName, String connectionString, SqlBulkCopyContext context)
        {
            var eh = SqlServerDatabase.CommandExecuted;
            if (eh != null)
            {
                eh(null, new CommandExecutedEventArgs(methodName, connectionString, context));
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="e"></param>
        protected static void OnCommandError(IDbCommand command, CommandErrorEventArgs e)
        {
            var eh = SqlServerDatabase.CommandError;
            if (eh != null)
            {
                eh(null, e);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public void Open()
        {
            if (this._Connection == null)
            {
                this._Connection = SqlServerDatabase.CreateConnection(this._ConnectionString.ToString());
                this._Connection.Open();
            }
            else
            {
                if (this._Connection.State == ConnectionState.Closed)
                {
                    this._Connection.Open();
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public void Close()
        {
            if (this._Connection != null)
            {
                if (this._Connection.State == ConnectionState.Open)
                {
                    this._Connection.Close();
                }
                this._Connection.Dispose();
                this._Connection = null;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public Boolean CheckAvailable()
        {
            try
            {
                this.Open();
            }
            catch
            {
                return false;
            }
            finally
            {
                this.Close();
            }
            return true;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="isolationLevel"></param>
        public void BeginTransaction(IsolationLevel isolationLevel)
        {
            this.Open();
            this._Transaction = this._Connection.BeginTransaction(isolationLevel);
        }
        /// <summary>
        /// 
        /// </summary>
        public void CommitTransaction()
        {
            this._Transaction.Commit();
            this.Close();
        }
        /// <summary>
        /// 
        /// </summary>
        public void RollBackTransaction()
        {
            this._Transaction.Rollback();
            this.Close();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public DataSet GetDataSet(String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return GetDataSet(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        DataSet IDatabase.GetDataSet(IDbCommand command)
        {
            var sqlCommand = command as SqlCommand;
            if (sqlCommand == null) { throw new ArgumentException("Invalid argument type"); }
            return GetDataSet(sqlCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public DataSet GetDataSet(SqlCommand command)
        {
            var ds = new DataSet();
            IDataAdapter da = null;
            IDbCommand cm = command;

            try
            {
                var e = SqlServerDatabase.OnCommandExecuting(MethodName.GetDataSet, this.ConnectionString, cm);
                if (e != null && e.Cancel == true) { return null; }

                this.Open();
                da = SqlServerDatabase.CreateDataAdapter();
                cm.Connection = this._Connection;
                cm.Transaction = this._Transaction;
                this.SetCommandParameter(cm);
                SqlServerDatabase.SetSelectCommand(da, cm);

                da.Fill(ds);
            }
            catch (Exception ex)
            {
                SqlServerDatabase.CatchException(MethodName.GetDataSet, this.ConnectionString, cm, ex);
            }
            finally
            {
                if (cm.Transaction == null && this._Connection.State == ConnectionState.Closed)
                { this.Close(); }
                SqlServerDatabase.OnCommandExecuted(MethodName.GetDataSet, this.ConnectionString, cm);
            }
            return ds;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public DataTable GetDataTable(String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return GetDataTable(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        DataTable IDatabase.GetDataTable(IDbCommand command)
        {
            var sqlCommand = command as SqlCommand;
            if (sqlCommand == null) { throw new ArgumentException("Invalid argument type"); }
            return GetDataTable(sqlCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public DataTable GetDataTable(SqlCommand command)
        {
            var dt = new DataTable();
            IDataAdapter da = null;
            IDbCommand cm = command;

            try
            {
                var e = SqlServerDatabase.OnCommandExecuting(MethodName.GetDataTable, this.ConnectionString, cm);
                if (e != null && e.Cancel == true) { return null; }

                this.Open();
                da = SqlServerDatabase.CreateDataAdapter();
                cm.Connection = this._Connection;
                cm.Transaction = this._Transaction;
                this.SetCommandParameter(cm);
                SqlServerDatabase.SetSelectCommand(da, cm);

                SqlServerDatabase.FillDataTable(da, dt);
            }
            catch (Exception ex)
            {
                SqlServerDatabase.CatchException(MethodName.GetDataTable, this.ConnectionString, cm, ex);
            }
            finally
            {
                if (cm.Transaction == null && this._Connection.State == ConnectionState.Closed)
                { this.Close(); }
                SqlServerDatabase.OnCommandExecuted(MethodName.GetDataTable, this.ConnectionString, cm);
            }
            return dt;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="commandBehavior"></param>
        /// <returns></returns>
        public IDataReader ExecuteReader(String query, CommandBehavior commandBehavior)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return ExecuteReader(cm, commandBehavior);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public IDataReader ExecuteReader(String query)
        {
            return ExecuteReader(query, CommandBehavior.Default);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="commandBehavior"></param>
        /// <returns></returns>
        IDataReader IDatabase.ExecuteReader(IDbCommand command, CommandBehavior commandBehavior)
        {
            var sqlCommand = command as SqlCommand;
            if (sqlCommand == null) { throw new ArgumentException("Invalid argument type"); }
            return ExecuteReader(sqlCommand, commandBehavior);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        IDataReader IDatabase.ExecuteReader(IDbCommand command)
        {
            return ((IDatabase)this).ExecuteReader(command, CommandBehavior.Default);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="commandBehavior"></param>
        /// <returns></returns>
        public IDataReader ExecuteReader(SqlCommand command, CommandBehavior commandBehavior)
        {
            IDataReader dr = null;
            IDbCommand cm = command;

            try
            {
                var e = SqlServerDatabase.OnCommandExecuting(MethodName.ExecuteReader, this.ConnectionString, cm);
                if (e != null && e.Cancel == true) { return null; }

                this.Open();
                cm.Connection = this._Connection;
                cm.Transaction = this._Transaction;
                this.SetCommandParameter(cm);

                dr = cm.ExecuteReader(commandBehavior);
            }
            catch (Exception exception)
            {
                this.Close();
                SqlServerDatabase.CatchException(MethodName.ExecuteReader, this.ConnectionString, cm, exception);
            }
            finally
            {
                SqlServerDatabase.OnCommandExecuted(MethodName.ExecuteReader, this.ConnectionString, cm);
            }
            return dr;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public IDataReader ExecuteReader(SqlCommand command)
        {
            return ExecuteReader(command, CommandBehavior.Default);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public Object ExecuteScalar(String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return this.ExecuteScalar(cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        Object IDatabase.ExecuteScalar(IDbCommand command)
        {
            var sqlCommand = command as SqlCommand;
            if (sqlCommand == null) { throw new ArgumentException("Invalid argument type"); }
            return ExecuteScalar(sqlCommand);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <returns></returns>
        public Object ExecuteScalar(SqlCommand command)
        {
            Object o = null;
            IDbCommand cm = command;
            try
            {
                var e = SqlServerDatabase.OnCommandExecuting(MethodName.ExecuteScalar, this.ConnectionString, cm);
                if (e != null && e.Cancel == true) { return null; }

                this.Open();
                cm.Connection = this._Connection;
                cm.Transaction = this._Transaction;
                this.SetCommandParameter(cm);

                o = cm.ExecuteScalar();
            }
            catch (Exception ex)
            {
                SqlServerDatabase.CatchException(MethodName.ExecuteScalar, this.ConnectionString, cm, ex);
            }
            finally
            {
                this.Close();
                SqlServerDatabase.OnCommandExecuted(MethodName.ExecuteScalar, this.ConnectionString, cm);
            }
            return o;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="connectionAutoClose"></param>
        /// <returns></returns>
        public Int32 ExecuteCommand(String query, Boolean connectionAutoClose)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return ExecuteCommand(cm, connectionAutoClose);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="connectionAutoClose"></param>
        /// <returns></returns>
        Int32 IDatabase.ExecuteCommand(IDbCommand command, Boolean connectionAutoClose)
        {
            var sqlCommand = command as SqlCommand;
            if (sqlCommand == null) { throw new ArgumentException("Invalid argument type"); }
            return ExecuteCommand(sqlCommand, connectionAutoClose);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="command"></param>
        /// <param name="connectionAutoClose"></param>
        /// <returns></returns>
        public Int32 ExecuteCommand(SqlCommand command, Boolean connectionAutoClose)
        {
            var affectRecordNumber = Int32.MinValue;
            IDbCommand cm = command;
            try
            {
                var e = SqlServerDatabase.OnCommandExecuting(MethodName.ExecuteCommand, this.ConnectionString, cm);
                if (e != null && e.Cancel == true) { return -1; }

                this.Open();
                cm.Connection = this._Connection;
                cm.Transaction = this._Transaction;
                this.SetCommandParameter(cm);

                affectRecordNumber = cm.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                SqlServerDatabase.CatchException(MethodName.ExecuteCommand, this.ConnectionString, cm, ex);
            }
            finally
            {
                if (connectionAutoClose == true)
                {
                    this.Close();
                }
                SqlServerDatabase.OnCommandExecuted(MethodName.ExecuteCommand, this.ConnectionString, cm);
            }
            return affectRecordNumber;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="isolationLevel"></param>
        /// <param name="connectionAutoClose"></param>
        /// <param name="commands"></param>
        /// <returns></returns>
        public Int32[] ExecuteCommand(IsolationLevel isolationLevel, Boolean connectionAutoClose, params String[] commands)
        {
            return ExecuteCommand(isolationLevel, connectionAutoClose, commands.Select(q =>
                {
                    var cm = CreateCommand(q);
                    cm.CommandType = CommandType.Text;
                    return cm;
                }).ToArray());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="isolationLevel"></param>
        /// <param name="connectionAutoClose"></param>
        /// <param name="commands"></param>
        /// <returns></returns>
        Int32[] IDatabase.ExecuteCommand(IsolationLevel isolationLevel, Boolean connectionAutoClose, params IDbCommand[] commands)
        {
            if (!commands.All(c => c is SqlCommand)) { throw new ArgumentException("Invalid argument type"); }
            return ExecuteCommand(isolationLevel, connectionAutoClose, commands.OfType<SqlCommand>().ToArray());
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="isolationLevel"></param>
        /// <param name="connectionAutoClose"></param>
        /// <param name="commands"></param>
        /// <returns></returns>
        public Int32[] ExecuteCommand(IsolationLevel isolationLevel, Boolean connectionAutoClose, params SqlCommand[] commands)
        {
            var affectRecordNumber = new Int32[commands.Length];
            IDbCommand cm = null;
            CommandExecutingEventArgs e;
            try
            {
                this.Open();
                this.BeginTransaction(isolationLevel);
                for (Int32 i = 0; i < commands.Length; i++)
                {
                    cm = commands[i];
                    e = SqlServerDatabase.OnCommandExecuting(MethodName.ExecuteCommandList, this.ConnectionString, cm);
                    if (e != null && e.Cancel == true) { continue; }

                    cm.Connection = this._Connection;
                    cm.Transaction = this._Transaction;
                    this.SetCommandParameter(cm);

                    affectRecordNumber[i] = cm.ExecuteNonQuery();

                    SqlServerDatabase.OnCommandExecuted(MethodName.ExecuteCommandList, this.ConnectionString, cm);
                }
                this._Transaction.Commit();
            }
            catch (Exception exception)
            {
                if (this._Connection.State == ConnectionState.Open)
                {
                    this._Transaction.Rollback();
                }
                SqlServerDatabase.CatchException(MethodName.ExecuteCommandList, this.ConnectionString, cm, exception);
            }
            finally
            {
                if (connectionAutoClose == true)
                {
                    this.Close();
                }
            }
            return affectRecordNumber;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        public static DataSet GetDataSet(String connectionString, String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return GetDataSet(connectionString, cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public static DataSet GetDataSet(String connectionString, SqlCommand command)
        {
            DataSet ds = new DataSet();
            IDbConnection cn = null;
            IDataAdapter da = null;
            IDbCommand cm = command;
            try
            {
                var e = SqlServerDatabase.OnCommandExecuting(MethodName.GetDataSet, connectionString, cm);
                if (e != null && e.Cancel == true) { return null; }

                cn = SqlServerDatabase.CreateConnection(connectionString);
                cm.Connection = cn;
                da = SqlServerDatabase.CreateDataAdapter();
                SqlServerDatabase.SetSelectCommand(da, cm);

                da.Fill(ds);
            }
            catch (Exception ex)
            {
                SqlServerDatabase.CatchException(MethodName.GetDataSet, connectionString, cm, ex);
            }
            finally
            {
                if (cn != null) { cn.Dispose(); }
                SqlServerDatabase.OnCommandExecuted(MethodName.GetDataSet, connectionString, cm);
            }
            return ds;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        public static DataTable GetDataTable(String connectionString, String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return GetDataTable(connectionString, cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public static DataTable GetDataTable(String connectionString, SqlCommand command)
        {
            DataTable dt = new DataTable();
            IDbConnection cn = null;
            IDbCommand cm = command;
            IDataAdapter da = null;
            try
            {
                var e = SqlServerDatabase.OnCommandExecuting(MethodName.GetDataTable, connectionString, cm);
                if (e != null && e.Cancel == true) { return null; }

                cn = SqlServerDatabase.CreateConnection(connectionString);
                cm.Connection = cn;
                da = SqlServerDatabase.CreateDataAdapter();
                SqlServerDatabase.SetSelectCommand(da, cm);

                SqlServerDatabase.FillDataTable(da, dt);
            }
            catch (Exception ex)
            {
                SqlServerDatabase.CatchException(MethodName.GetDataTable, connectionString, cm, ex);
            }
            finally
            {
                if (cn != null) { cn.Dispose(); }
                SqlServerDatabase.OnCommandExecuted(MethodName.GetDataTable, connectionString, cm);
            }
            return dt;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        public static Int32 ExecuteCommand(String connectionString, String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return ExecuteCommand(connectionString, cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public static Int32 ExecuteCommand(String connectionString, IDbCommand command)
        {
            var affectRecordNumber = Int32.MinValue;
            IDbConnection cn = null;
            IDbCommand cm = command;
            try
            {
                var e = SqlServerDatabase.OnCommandExecuting(MethodName.ExecuteCommand, connectionString, cm);
                if (e != null && e.Cancel == true) { return -1; }

                cn = SqlServerDatabase.CreateConnection(connectionString);
                cn.Open();
                cm.Connection = cn;

                affectRecordNumber = command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                SqlServerDatabase.CatchException(MethodName.ExecuteCommand, connectionString, cm, ex);
            }
            finally
            {
                if (cn != null) { cn.Dispose(); }
                SqlServerDatabase.OnCommandExecuted(MethodName.ExecuteCommand, connectionString, cm);
            }
            return affectRecordNumber;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="query"></param>
        /// <returns></returns>
        public static Object ExecuteScalar(String connectionString, String query)
        {
            var cm = CreateCommand(query);
            cm.CommandType = CommandType.Text;
            return ExecuteScalar(connectionString, cm);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public static Object ExecuteScalar(String connectionString, IDbCommand command)
        {
            Object o = null;
            IDbConnection cn = null;
            IDbCommand cm = command;
            try
            {
                var e = SqlServerDatabase.OnCommandExecuting(MethodName.ExecuteScalar, connectionString, cm);
                if (e != null && e.Cancel == true) { return -1; }

                cn = SqlServerDatabase.CreateConnection(connectionString);
                cn.Open();
                cm.Connection = cn;

                o = command.ExecuteScalar();
            }
            catch (Exception ex)
            {
                SqlServerDatabase.CatchException(MethodName.ExecuteScalar, connectionString, cm, ex);
            }
            finally
            {
                if (cn != null) { cn.Dispose(); }
                SqlServerDatabase.OnCommandExecuted(MethodName.ExecuteScalar, connectionString, cm);
            }
            return o;
        }
        /// <summary>
        /// 例外をキャッチしてハンドルします。
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <param name="exception"></param>
        private static void CatchException(MethodName methodName, String connectionString, IDbCommand command, Exception exception)
        {
            var e = new CommandErrorEventArgs(methodName, connectionString, command, exception);
            SqlServerDatabase.OnCommandError(null, e);
            if (e.ThrowException == true)
            {
                SqlServerDatabase.ThrowException(methodName, connectionString, command, exception);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="dataAdapter"></param>
        /// <param name="exception"></param>
        private static void CatchException(MethodName methodName, string connectionString, SqlDataAdapter dataAdapter, Exception exception)
        {
            var e = new CommandErrorEventArgs(methodName, connectionString, dataAdapter, exception);
            SqlServerDatabase.OnCommandError(null, e);
            if (e.ThrowException == true)
            {
                SqlServerDatabase.ThrowException(methodName, connectionString, dataAdapter, exception);
            }
        }
        /// <summary>
        /// 例外をキャッチしてハンドルします。
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="context"></param>
        /// <param name="exception"></param>
        private static void CatchException(MethodName methodName, String connectionString, SqlBulkCopyContext context, Exception exception)
        {
            var e = new CommandErrorEventArgs(methodName, connectionString, context, exception);
            SqlServerDatabase.OnCommandError(null, e);
            if (e.ThrowException == true)
            {
                SqlServerDatabase.ThrowException(methodName, connectionString, context, exception);
            }
        }
        /// <summary>
        /// 新しい例外を生成しスローします。
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        public static void ThrowException(MethodName methodName, String connectionString, IDbCommand command, Exception exception)
        {
            throw SqlServerDatabase.CreateException(exception, methodName, connectionString, command);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="dataAdapter"></param>
        /// <param name="exception"></param>
        public static void ThrowException(MethodName methodName, string connectionString, SqlDataAdapter dataAdapter, Exception exception)
        {
            throw SqlServerDatabase.CreateException(exception, methodName, connectionString, dataAdapter);
        }
        /// <summary>
        /// 新しい例外を生成しスローします。
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="context"></param>
        public static void ThrowException(MethodName methodName, String connectionString, SqlBulkCopyContext context, Exception exception)
        {
            throw SqlServerDatabase.CreateException(exception, methodName, connectionString, context);
        }
        private void SetCommandParameter(IDbCommand command)
        {
            if (this._CommandTimeout.HasValue == true)
            {
                command.CommandTimeout = this._CommandTimeout.Value;
            }
        }
        #region デストラクタ
        /// <summary>
        /// 
        /// </summary>
        public void Dispose()
        {
            GC.SuppressFinalize(this);
            this.Dispose(true);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="disposing"></param>
        protected void Dispose(Boolean disposing)
        {
            if (disposing)
            {
                if (this._Transaction != null)
                { this._Transaction.Dispose(); }
                if (this._Connection != null)
                { this._Connection.Dispose(); }
            }
            this._Transaction = null;
            this._Connection = null;
        }
        /// <summary>
        /// 
        /// </summary>
        ~SqlServerDatabase()
        {
            this.Dispose(false);
        }
        #endregion
    }
}
