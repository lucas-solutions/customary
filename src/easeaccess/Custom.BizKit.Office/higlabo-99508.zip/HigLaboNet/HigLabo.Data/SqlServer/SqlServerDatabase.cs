﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace HigLabo.Data.RelationalDatabase
{
    /// <summary>
    /// SQLサーバーへの接続及びデータ操作の機能を提供します。
    /// </summary>
    public partial class SqlServerDatabase 
    {
        private SqlConnection _Connection = null;
        private SqlTransaction _Transaction = null;

        private static SqlConnection CreateConnection(String connectionString)
        {
            return new SqlConnection(connectionString);
        }
        private static SqlCommand CreateCommand(String commandText)
        {
            return new SqlCommand(commandText);
        }
        private static SqlDataAdapter CreateDataAdapter()
        {
            return new SqlDataAdapter();
        }
        private static void SetSelectCommand(IDataAdapter adapter, IDbCommand command)
        {
            (adapter as SqlDataAdapter).SelectCommand = command as SqlCommand;
        }
        private static void FillDataTable(IDataAdapter adapter, DataTable dataTable)
        {
            (adapter as SqlDataAdapter).Fill(dataTable);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        public SqlServerDatabase(String connectionString)
        {
            this._ConnectionString = connectionString;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="serverName"></param>
        /// <param name="databaseName"></param>
        public SqlServerDatabase(String serverName, String databaseName)
        {
            this._ConnectionString = SqlServerDatabaseConnectionString.Create(serverName, databaseName, 100);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="serverName"></param>
        /// <param name="databaseName"></param>
        /// <param name="inUserID"></param>
        /// <param name="inPassword"></param>
        public SqlServerDatabase(String serverName, String databaseName, String inUserID, String inPassword)
        {
            this._ConnectionString = SqlServerDatabaseConnectionString.Create(serverName, databaseName, inUserID, inPassword, 100);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        public SqlServerDatabase(SqlServerDatabaseConnectionString connectionString)
        {
            this._ConnectionString = connectionString.Create();
        }
        /// <summary>
        /// 例外オブジェクトを生成します。
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="command"></param>
        /// <returns></returns>
        public static Exception CreateException(Exception exception, MethodName methodName, String connectionString, IDbCommand command)
        {
            var ex = exception as SqlException;

            if (ex != null)
            {
                switch (ex.Number)
                {
                    case -2:
                        // Timeout. 
                        return new TimeoutException(ex, methodName, connectionString, command);
                    case 17:
                        // SQL Server does not exist or access denied. 
                        return new ConnectionException(ex, methodName, connectionString, command);
                    case 18456:
                        // Login Failed 
                        return new LoginException(ex, methodName, connectionString, command);
                    case 547:
                        // ForeignKey Violation 
                        return new ForeignKeyException(ex, methodName, connectionString, command);
                    case 1205:
                        // DeadLock Victim 
                        return new DeadLockException(ex, methodName, connectionString, command);
                    case 1222:
                        // Lock timeout
                        return new LockTimeoutException(ex, methodName, connectionString, command);
                    case 2627:
                        // Unique Index/Constriant Violation 
                        return new UniqueConstraintException(ex, methodName, connectionString, command);
                    case 2601:
                        // Unique Index/Constriant Violation 
                        return new UniqueConstraintException(ex, methodName, connectionString, command);
                }
                return new DatabaseException(ex, methodName, connectionString, command);
            }
            return exception;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="dataAdapter"></param>
        /// <returns></returns>
        public static Exception CreateException(Exception exception, MethodName methodName, string connectionString, SqlDataAdapter dataAdapter)
        {
            var ex = exception as SqlException;

            if (ex != null)
            {
                switch (ex.Number)
                {
                    case -2:
                        // Timeout. 
                        return new TimeoutException(ex, methodName, connectionString, dataAdapter);
                    case 17:
                        // SQL Server does not exist or access denied. 
                        return new ConnectionException(ex, methodName, connectionString, dataAdapter);
                    case 18456:
                        // Login Failed 
                        return new LoginException(ex, methodName, connectionString, dataAdapter);
                    case 547:
                        // ForeignKey Violation 
                        return new ForeignKeyException(ex, methodName, connectionString, dataAdapter);
                    case 1205:
                        // DeadLock Victim 
                        return new DeadLockException(ex, methodName, connectionString, dataAdapter);
                    case 1222:
                        // Lock timeout
                        return new LockTimeoutException(ex, methodName, connectionString, dataAdapter);
                    case 2627:
                        // Unique Index/Constriant Violation 
                        return new UniqueConstraintException(ex, methodName, connectionString, dataAdapter);
                    case 2601:
                        // Unique Index/Constriant Violation 
                        return new UniqueConstraintException(ex, methodName, connectionString, dataAdapter);
                }
                return new DatabaseException(ex, methodName, connectionString, dataAdapter);
            }
            return exception;
        }
        /// <summary>
        /// 例外オブジェクトを生成します。
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="methodName"></param>
        /// <param name="connectionString"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public static Exception CreateException(Exception exception, MethodName methodName, String connectionString, SqlBulkCopyContext context)
        {
            SqlException ex = exception as SqlException;

            if (ex != null)
            {
                switch (ex.Number)
                {
                    case -2:
                        // Timeout. 
                        return new TimeoutException(ex, methodName, connectionString, context);
                    case 17:
                        // SQL Server does not exist or access denied. 
                        return new ConnectionException(ex, methodName, connectionString, context);
                    case 18456:
                        // Login Failed 
                        return new LoginException(ex, methodName, connectionString, context);
                    case 547:
                        // ForeignKey Violation 
                        return new ForeignKeyException(ex, methodName, connectionString, context);
                    case 1205:
                        // DeadLock Victim 
                        return new DeadLockException(ex, methodName, connectionString, context);
                    case 1222:
                        // Lock timeout
                        return new LockTimeoutException(ex, methodName, connectionString, context);
                    case 2627:
                        // Unique Index/Constriant Violation 
                        return new UniqueConstraintException(ex, methodName, connectionString, context);
                    case 2601:
                        // Unique Index/Constriant Violation 
                        return new UniqueConstraintException(ex, methodName, connectionString, context);
                }
                return new DatabaseException(ex, methodName, connectionString, context);
            }
            return exception;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataAdapter"></param>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        public Int32 Save(SqlDataAdapter dataAdapter, DataTable dataTable)
        {
            var previousState = ConnectionState;
            int affectedRecordCount = -1;

            try
            {
                var e = SqlServerDatabase.OnCommandExecuting(MethodName.Save, ConnectionString, dataAdapter);
                if (e != null && e.Cancel == true) { return -1; }

                Open();
                if (dataAdapter.InsertCommand != null)
                {
                    dataAdapter.InsertCommand.Connection = _Connection;
                    dataAdapter.InsertCommand.Transaction = _Transaction;
                }
                if (dataAdapter.UpdateCommand != null)
                {
                    dataAdapter.UpdateCommand.Connection = _Connection;
                    dataAdapter.UpdateCommand.Transaction = _Transaction;
                }
                if (dataAdapter.DeleteCommand != null)
                {
                    dataAdapter.DeleteCommand.Connection = _Connection;
                    dataAdapter.DeleteCommand.Transaction = _Transaction;
                }
                affectedRecordCount = dataAdapter.Update(dataTable);
            }
            catch (Exception exception)
            {
                SqlServerDatabase.CatchException(MethodName.Save, ConnectionString, dataAdapter, exception);
            }
            finally
            {
                if (previousState == ConnectionState.Closed &&
                    ConnectionState == ConnectionState.Open)
                {
                    Close();
                }
                SqlServerDatabase.OnCommandExecuted(MethodName.Save, ConnectionString, dataAdapter);
            }
            return affectedRecordCount;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public SqlBulkCopyContext CreateSqlBulkCopyContext()
        {
            return CreateSqlBulkCopyContext(SqlBulkCopyOptions.Default);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="copyOptions"></param>
        /// <returns></returns>
        public SqlBulkCopyContext CreateSqlBulkCopyContext(SqlBulkCopyOptions copyOptions)
        {
            if (_Connection == null)
            {
                return new SqlBulkCopyContext(_ConnectionString, copyOptions);
            }
            return new SqlBulkCopyContext(_Connection, copyOptions, _Transaction);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="reader"></param>
        public void BulkCopy(String tableName, IDataReader reader)
        {
            var cx = CreateSqlBulkCopyContext();
            cx.SqlBulkCopy.DestinationTableName = tableName;
            BulkCopy(cx, reader);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="reader"></param>
        public void BulkCopy(SqlBulkCopyContext context, IDataReader reader)
        {
            var dr = reader;
            var state = ConnectionState;

            if (context.Connection == null)
            {
                if (_ConnectionString != context.ConnectionString) { throw new InvalidOperationException(); }
            }
            else
            {
                if (_Connection != context.Connection) { throw new InvalidOperationException(); }
            }
            if (context.Transaction != null && this._Transaction != context.Transaction) { throw new InvalidOperationException(); }

            try
            {
                var e = SqlServerDatabase.OnCommandExecuting(MethodName.BulkCopy, ConnectionString, context);
                if (e != null && e.Cancel == true) { return; }

                Open();
                var bc = context.SqlBulkCopy;
                bc.WriteToServer(dr);
                dr.Close();
            }
            catch (Exception exception)
            {
                SqlServerDatabase.CatchException(MethodName.BulkCopy, this.ConnectionString, context, exception);
            }
            finally
            {
                if (state == ConnectionState.Closed)
                {
                    this.Close();
                }
                SqlServerDatabase.OnCommandExecuted(MethodName.BulkCopy, this.ConnectionString, context);
                ((IDisposable) context.SqlBulkCopy).Dispose();
            }
        }
    }
}
