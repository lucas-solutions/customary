﻿using System;

namespace HigLabo.Data.SqlServer
{
    /// <summary>
    /// 
    /// </summary>
    public enum FileGrowthSizeUnit
    {
        /// <summary>
        /// 
        /// </summary>
        KB,
        /// <summary>
        /// 
        /// </summary>
        MB,
        /// <summary>
        /// 
        /// </summary>
        GB,
        /// <summary>
        /// 
        /// </summary>
        TB,
        /// <summary>
        /// 
        /// </summary>
        Percent
    }
}
