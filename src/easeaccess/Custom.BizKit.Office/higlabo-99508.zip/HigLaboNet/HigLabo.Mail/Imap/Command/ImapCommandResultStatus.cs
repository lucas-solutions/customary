﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Imap
{
    /// <summary>
    /// 
    /// </summary>
    public enum ImapCommandResultStatus
    {
        /// <summary>
        /// 
        /// </summary>
        None = 0,
        /// <summary>
        /// 
        /// </summary>
        Ok = 1,
        /// <summary>
        /// 
        /// </summary>
        Bad = 2,
        /// <summary>
        /// 
        /// </summary>
        No = 3
    }
}
