﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HigLabo.Net.Imap
{
    /// <summary>
    /// 
    /// </summary>
    public enum ImapIdleCommandMessageType
    {
        /// <summary>
        /// 
        /// </summary>
        Idling,
        /// <summary>
        /// 
        /// </summary>
        Exists, 
        /// <summary>
        /// 
        /// </summary>
        Expunge
    }
}
