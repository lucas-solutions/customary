﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HigLabo.Net.Mail
{
	/// <summary>
	/// Specify field parameter encoding
	/// </summary>
    public enum FieldParameterEncoding
    {
		/// <summary>
		/// 
		/// </summary>
        Rfc2047, 
		/// <summary>
		/// 
		/// </summary>
		Rfc2231
    }
}
