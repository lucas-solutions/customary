﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HigLabo.Net.Mail
{
    /// Specify transfer-encoding
    /// <summary>
    /// Specify transfer-encoding
    /// </summary>
    public enum TransferEncoding
    {
		/// <summary>
		/// 
		/// </summary>
        SevenBit, 
		/// <summary>
		/// 
		/// </summary>
		Base64, 
		/// <summary>
		/// 
		/// </summary>
		QuotedPrintable
    }
}
