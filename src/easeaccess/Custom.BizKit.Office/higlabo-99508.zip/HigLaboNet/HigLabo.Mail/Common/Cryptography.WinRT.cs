﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Storage.Streams;
using Windows.Security.Cryptography;
using Windows.Security.Cryptography.Core;

namespace HigLabo.Net
{
    /// <summary>
    /// 
    /// </summary>
    internal class Cryptography
    {
        /// <summary>
        /// MD5ダイジェストに従って文字列を変換します。
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static String ToMd5DigestString(String text)
        {
            HashAlgorithmProvider alg = HashAlgorithmProvider.OpenAlgorithm(HashAlgorithmNames.Md5);
            IBuffer bb = CryptographicBuffer.ConvertStringToBinary(text, BinaryStringEncoding.Utf8);
            IBuffer hashed = alg.HashData(bb);
            return CryptographicBuffer.EncodeToHexString(hashed);
        }
        /// <summary>
        /// Cram-MD5に従って文字列を変換します。
        /// </summary>
        /// <param name="text"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static String ToCramMd5String(String text, String key)
        {
            MacAlgorithmProvider macAlgorithmProvider = MacAlgorithmProvider.OpenAlgorithm(MacAlgorithmNames.HmacMd5);
            IBuffer bb = Convert.FromBase64String(text).AsBuffer();
            IBuffer binaryKeyMaterial = Encoding.UTF8.GetBytes(key).AsBuffer();
            CryptographicKey hmacKey = macAlgorithmProvider.CreateKey(binaryKeyMaterial);
            IBuffer binarySignedMessage = CryptographicEngine.Sign(hmacKey, bb);
            return CryptographicBuffer.EncodeToHexString(binarySignedMessage);
        }
    }
}
