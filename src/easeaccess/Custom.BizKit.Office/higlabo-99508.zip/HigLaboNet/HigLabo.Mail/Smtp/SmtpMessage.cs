﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
#if !NETFX_CORE
using System.Security.Cryptography.X509Certificates;
#endif
using HigLabo.Net.Mail;

namespace HigLabo.Net.Smtp
{
    /// Represent smtp message.
    /// <summary>
    /// Represent smtp message.
    /// </summary>
    public class SmtpMessage : InternetTextMessage
    {
        private List<SmtpContent> _Contents;
        private List<String> _EncodeHeaderKeys = new List<String>();
        private MailAddress _From = null;
        private List<MailAddress> _To = new List<MailAddress>();
        private List<MailAddress> _Cc = new List<MailAddress>();
        private List<MailAddress> _Bcc = new List<MailAddress>();
        private MailPriority _MailPriority = MailPriority.Normal;
        private String _BodyText = "";
        private Encoding _HeaderEncoding = Encoding.UTF8;
        private TransferEncoding _HeaderTransferEncoding = TransferEncoding.SevenBit;
        /// 送信元のメールアドレスを取得します。
        /// <summary>
        /// 送信元のメールアドレスを取得します。
        /// </summary>
        public new MailAddress From
        {
            get { return _From; }
            set { _From = value; }
        }
        /// 宛先のメールアドレスのリストを取得します。
        /// <summary>
        /// 宛先のメールアドレスのリストを取得します。
        /// </summary>
        public List<MailAddress> To
        {
            get { return this._To; }
        }
        /// CCのメールアドレスのリストを取得します。
        /// <summary>
        /// CCのメールアドレスのリストを取得します。
        /// </summary>
        public List<MailAddress> Cc
        {
            get { return this._Cc; }
        }
        /// BCCのメールアドレスのリストを取得します。
        /// <summary>
        /// BCCのメールアドレスのリストを取得します。
        /// </summary>
        public List<MailAddress> Bcc
        {
            get { return this._Bcc; }
        }
        /// <summary>
        /// 
        /// </summary>
        public MailPriority Priority
        {
            get { return _MailPriority; }
            set { _MailPriority = value; }
        }
        /// HeaderのEncodingを取得または設定します。
        /// <summary>
        /// HeaderのEncodingを取得または設定します。
        /// </summary>
        public Encoding HeaderEncoding
        {
            get { return this._HeaderEncoding; }
            set { this._HeaderEncoding = value; }
        }
        /// HeaderのTransferEncodingを取得または設定します。
        /// <summary>
        /// HeaderのTransferEncodingを取得または設定します。
        /// </summary>
        public TransferEncoding HeaderTransferEncoding
        {
            get { return this._HeaderTransferEncoding; }
            set { this._HeaderTransferEncoding = value; }
        }
        /// <summary>
        /// メッセージが署名されるかどうかを示す値を取得または設定します。
        /// </summary>
        public Boolean IsSigned { get; set; }
        /// <summary>
        /// メッセージが暗号化されるかどうかを示す値を取得または設定します。
        /// </summary>
        public Boolean IsEncrypted { get; set; }
        /// ボディ部分のテキスト文字列を取得または設定します。
        /// <summary>
        /// ボディ部分のテキスト文字列を取得または設定します。
        /// </summary>
        public String BodyText
        {
            get { return this._BodyText; }
            set { this._BodyText = value; }
        }
        /// HTML形式のメールかどうかを示す値を取得または設定します。
        /// <summary>
        /// HTML形式のメールかどうかを示す値を取得または設定します。
        /// </summary>
        public new Boolean IsHtml
        {
            get { return base.IsHtml; }
            set { this.ContentType.Value = "text/html"; }
        }
        /// SmtpContentのコレクションを取得します。
        /// <summary>
        /// SmtpContentのコレクションを取得します。
        /// </summary>
        public List<SmtpContent> Contents
        {
            get { return this._Contents; }
        }
		/// <summary>
		/// 
		/// </summary>
        public SmtpMessage()
        {
            this.Initialize();
        }
		/// <summary>
		/// 
		/// </summary>
		/// <param name="mailFrom"></param>
		/// <param name="to"></param>
		/// <param name="cc"></param>
		/// <param name="subject"></param>
		/// <param name="bodyText"></param>
        public SmtpMessage(String mailFrom, String to, String cc, String subject, String bodyText)
        {
            this.Initialize();
            this.From = new MailAddress(mailFrom);
            if (String.IsNullOrEmpty(to) == false)
            {
                this.To.AddRange(MailAddress.CreateMailAddressList(to));
            }
            if (String.IsNullOrEmpty(cc) == false)
            {
                this.Cc.AddRange(MailAddress.CreateMailAddressList(cc));
            }
            this.Subject = subject;
            this.BodyText = bodyText;
        }
        /// 初期化処理を行います。
        /// <summary>
        /// 初期化処理を行います。
        /// </summary>
        private void Initialize()
        {
            this._Contents = new List<SmtpContent>();

            this["MIME-Version"] = "1.0";
            
            if (CultureInfo.CurrentCulture.Name.StartsWith("ja") == true)
            {
                this.HeaderEncoding = Encoding.GetEncoding("iso-2022-jp");
                this.HeaderTransferEncoding = TransferEncoding.Base64;
                this.ContentEncoding = Encoding.GetEncoding("iso-2022-jp");
                this.ContentTransferEncoding = TransferEncoding.Base64;
            }
            this._EncodeHeaderKeys.Add("subject");
        }
        /// 実際に送信される文字列のデータを取得します。
        /// <summary>
        /// 実際に送信される文字列のデータを取得します。
        /// </summary>
        /// <returns></returns>
        public String GetDataText()
        {
            StringBuilder sb = new StringBuilder(1024);
            CultureInfo ci = CultureInfo.CurrentCulture;
            Field f = null;
            String line = "";
            String bodyText = "";
            String signedText = "";
            String encryptedText = "";

            if (this.From != null)
            {
                var from = Field.FindField(this.Header, "From");
                from.Value = this.From.ToString();
            }

            for (int i = 0; i < this.Header.Count; i++)
            {
                f = this.Header[i];
                if (String.IsNullOrEmpty(f.Value) == true) { continue; }
                
                if (this._EncodeHeaderKeys.Contains(f.Key.ToLower()) == true)
                {
                    sb.AppendFormat("{0}: {1}{2}", f.Key
                        , MailParser.EncodeToMailHeaderLine(f.Value, this.HeaderTransferEncoding, this.HeaderEncoding
                        , MailParser.MaxCharCountPerRow - f.Key.Length - 2), MailParser.NewLine);
                }
                else if(f.Key.ToLower() != "content-type")
                {
                    //Content-TypeはCreateBodyTextメソッドでセット
                    sb.AppendFormat("{0}: {1}{2}", f.Key, f.Value, MailParser.NewLine);
                }
            }
            //Headerに設定されていない場合のみセットする
            //Priority
            f = Field.FindField(this.Header, "X-Priority");
            if (f == null)
            {
                sb.AppendFormat("X-Priority: {0}{1}", ((byte)this.Priority).ToString(), MailParser.NewLine);
            }
            //TO
            f = Field.FindField(this.Header, "To");
            if (f == null)
            {
                line = this.CreateMailAddressListText(this._To);
                if (String.IsNullOrEmpty(line) == false)
                {
                    sb.Append("To: ");
                    sb.Append(line);
                }
            }
            //CC
            f = Field.FindField(this.Header, "Cc");
            if (f == null)
            {
                line = this.CreateMailAddressListText(this._Cc);
                if (String.IsNullOrEmpty(line) == false)
                {
                    sb.Append("Cc: ");
                    sb.Append(line);
                }
            }
            //BODY
            bodyText = this.CreateBodyText();

            if (this.IsSigned == false && this.IsEncrypted == false)
            {
                sb.AppendLine(bodyText);
                sb.Append(MailParser.NewLine);
            }
            else
            {
#if NETFX_CORE
                throw new InvalidOperationException("Library does not support S/MIME in WinRT.");
#else
                if (this.IsSigned == true && this.IsEncrypted == true)
                {
                    signedText = this.CreateSignedText(bodyText);
                    encryptedText = this.CreateEncryptedText(signedText);
                    sb.AppendLine(encryptedText);
                }
                else if (this.IsSigned == true)
                {
                    signedText = this.CreateSignedText(bodyText);
                    sb.AppendLine(signedText);
                }
#endif
            }
            sb.Append(MailParser.NewLine);

            return sb.ToString();
        }
        private String CreateBodyText()
        {
            SmtpContent ct = null;
            String bodyText = "";
            StringBuilder body = new StringBuilder(256);
            
            if (this.Contents.Count > 0)
            {
                if (String.IsNullOrEmpty(this.MultiPartBoundary) == true)
                {
                    this.MultiPartBoundary = MailParser.GenerateBoundary();
                }
                //Multipartboundary
                body.AppendFormat("Content-Type: multipart/mixed; boundary=\"{0}\"", this.MultiPartBoundary);
                body.Append(MailParser.NewLine);
                body.AppendFormat("Content-Transfer-Encoding: {0}", this.ContentTransferEncoding);
                body.Append(MailParser.NewLine);
                body.Append(MailParser.NewLine);
                //This is multi-part message in MIME format.
                body.Append(MailParser.ThisIsMultiPartMessageInMimeFormat);
                body.Append(MailParser.NewLine);
                //Add BodyText Content if IsBody contents does not exist
                if (String.IsNullOrEmpty(this.BodyText) == false)
                {
                    ct = new SmtpContent();
                    if (this.IsHtml == true)
                    {
                        ct.LoadHtml(this.BodyText);
                    }
                    else
                    {
                        ct.LoadText(this.BodyText);
                    }
                    ct.ContentEncoding = this.ContentEncoding;
                    ct.ContentTransferEncoding = this.ContentTransferEncoding;

                    body.Append("--");
                    body.Append(this.MultiPartBoundary);
                    body.Append(MailParser.NewLine);
                    body.Append(ct.Data);
                    body.Append(MailParser.NewLine);
                }

                body.Append(this.CreateDataText(this.Contents));
                body.Append(MailParser.NewLine);
                body.AppendFormat("--{0}--", this.MultiPartBoundary);
                body.Append(MailParser.NewLine);
            }
            else
            {
                body.AppendFormat("Content-Type: {0}; charset=\"{1}\"", this.ContentType.Value, this.ContentEncoding.WebName);
                body.Append(MailParser.NewLine);
                body.AppendFormat("Content-Transfer-Encoding: {0}", this.ContentTransferEncoding);
                body.Append(MailParser.NewLine);
                body.Append(MailParser.NewLine);
                bodyText = MailParser.EncodeToMailBody(this.BodyText, this.ContentTransferEncoding, this.ContentEncoding);
                if (this.ContentTransferEncoding == TransferEncoding.SevenBit)
                {
                    body.Append(bodyText);
                }
                else
                {
                    for (int i = 0; i < bodyText.Length; i++)
                    {
                        if (i > 0 && i % 76 == 0)
                        {
                            body.Append(MailParser.NewLine);
                        }
                        //Is current index is first char of line
                        if (i == 0 || (i > 2 && bodyText[i - 2] == '\r' && bodyText[i - 1] == '\n'))
                        {
                            if (bodyText[i] == '.')
                            {
                                body.Append(".");
                            }
                        }
                        body.Append(bodyText[i]);
                    }
                }
                body.Append(MailParser.NewLine);
            }
            return body.ToString();
        }
#if !NETFX_CORE
        private String CreateSignedText(String body)
        {
            StringBuilder sb = new StringBuilder(128);
            if (this.From.SigningCertificate == null)
            {
                throw new InvalidOperationException("Can't sign message unless the From property contains a signing certificate.");
            }
            this.MultiPartBoundary = MailParser.GenerateBoundary();
            sb.AppendFormat("Content-Type: multipart/signed; protocol=\"application/x-pkcs7-signature\"; micalg=SHA1; boundary=\"{0}\"", this.MultiPartBoundary);
            sb.Append(MailParser.NewLine);
            sb.Append(MailParser.NewLine);

            byte[] signature = Cryptography.GetSignature(body.ToString(), this.From.SigningCertificate, this.From.EncryptionCertificate);
            sb.Append(MailParser.NewLine);
            sb.Append("--");
            sb.Append(this.MultiPartBoundary);
            sb.Append("\r\n");
            sb.Append(body);
            sb.Append(MailParser.NewLine);
            sb.Append("--");
            sb.Append(this.MultiPartBoundary);
            sb.Append("\r\n");
            sb.Append("Content-Type: application/x-pkcs7-signature; name=\"smime.p7s\"");
            sb.Append(MailParser.NewLine);
            sb.Append("Content-Transfer-Encoding: base64");
            sb.Append(MailParser.NewLine);
            sb.Append("Content-Disposition: attachment; filename=\"smime.p7s\"");
            sb.Append(MailParser.NewLine);
            sb.Append(MailParser.NewLine);
            sb.Append(MailParser.ToBase64String(signature));
            sb.Append(MailParser.NewLine);
            sb.Append(MailParser.NewLine);
            sb.Append("--");
            sb.Append(this.MultiPartBoundary);
            sb.Append("--");
            sb.Append(MailParser.NewLine);

            return sb.ToString();
        }
        private String CreateEncryptedText(String signedContent)
        {
            StringBuilder sb = new StringBuilder();
            X509Certificate2Collection encryptionCertificates = new X509Certificate2Collection();

            if (this.From.EncryptionCertificate == null)
            {
                throw new InvalidOperationException("To send an encryted message, the sender must have an encryption certificate specified.");
            }
            else
            {
                encryptionCertificates.Add(this.From.EncryptionCertificate);
            }
            foreach (MailAddress address in this.To)
            {
                if (address.EncryptionCertificate == null)
                {
                    throw new InvalidOperationException("To send an encryted message, all receivers( To, CC, and Bcc) must have an encryption certificate specified.");
                }
                else
                {
                    encryptionCertificates.Add(address.EncryptionCertificate);
                }
            }

            sb.Append("Content-Type: application/x-pkcs7-mime; smime-type=enveloped-data; name=\"smime.p7m\"");
            sb.Append(MailParser.NewLine);
            sb.AppendFormat("Content-Transfer-Encoding: {0}", this.ContentTransferEncoding);
            sb.Append(MailParser.NewLine);
            sb.Append("Content-Disposition: attachment; filename=\"smime.p7m\"");
            sb.Append(MailParser.NewLine);
            sb.Append(MailParser.NewLine);
            sb.Append(MailParser.NewLine);

            Byte[] encrypted = Cryptography.EncryptMessage(signedContent, encryptionCertificates);
            sb.Append(MailParser.ToBase64String(encrypted));
            sb.Append(MailParser.NewLine);

            return sb.ToString();
        }
#endif
        private String CreateDataText(List<SmtpContent> contents)
        {
            StringBuilder sb = new StringBuilder(1024);

            foreach (var content in contents)
            {
                //Skip empty SmtpContent instance
                if (content.Contents.Count > 0)
                {
                    sb.Append(this.CreateDataText(content.Contents));
                }
                else
                {
                    sb.Append("--");
                    sb.Append(this.MultiPartBoundary);
                    sb.Append(MailParser.NewLine);
                    sb.Append(content.GetDataText());
                    sb.Append(MailParser.NewLine);
                }
            }
            return sb.ToString();
        }
        /// ユーザー名とメールアドレスを示す文字列を生成します。
        /// <summary>
        /// ユーザー名とメールアドレスを示す文字列を生成します。
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="mailAddress"></param>
        public static String CreateFromMailAddress(String userName, String mailAddress)
        {
            return String.Format("\"{0}\" <{1}>", userName, mailAddress);
        }
        /// メールアドレスの一覧データからメールアドレスの文字列を生成します。
        /// <summary>
        /// メールアドレスの一覧データからメールアドレスの文字列を生成します。
        /// </summary>
        /// <param name="mailAddressList"></param>
        /// <returns></returns>
        private String CreateMailAddressListText(List<MailAddress> mailAddressList)
        {
            StringBuilder sb = new StringBuilder();
            List<MailAddress> l = mailAddressList;
            String s = "";

            for (int i = 0; i < l.Count; i++)
            {
                sb.AppendFormat("{0}{1}", s, l[i].ToEncodeString().Trim());
                sb.Append(MailParser.NewLine);

                s = "\t, ";
            }
            return sb.ToString();
        }
    }
}
